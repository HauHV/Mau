﻿Imports System.Runtime.CompilerServices
Imports Microsoft.VisualBasic
Imports System.Data.Common

Module ObjectEx

    ''' <summary>
    ''' Get PropertyValue By a PropertyName of an Object (e.g: CustomerObject.CustomerName)...
    ''' </summary>
    <Extension()> Public Function GetPropertyValue(ByVal obj As Object, ByVal propertyName As String) As Object
        Dim objType = obj.GetType()
        Dim pInfo = objType.GetProperty(propertyName)
        Return pInfo.GetValue(obj, Nothing)
    End Function

    ''' <summary>
    ''' ''' Set PropertyValue By a PropertyName for an Object (e.g: CustomerObject.CustomerName = "Jonh Kim")...
    ''' </summary>
    <Extension()> Public Sub SetPropertyValue(ByVal obj As Object, ByVal propertyName As String, ByVal propertyValue As Object)
        Dim objType = obj.GetType()
        Dim pInfo = objType.GetProperty(propertyName)
        pInfo.SetValue(obj, propertyValue, Nothing)
    End Sub

    <Extension()> Public Sub Release(ByRef pObject As System.Object)
        Try
            If pObject IsNot Nothing Then
                If pObject.GetType.IsSubclassOf(GetType(System.Data.DataTable)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(Windows.Forms.Form)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(DevExpress.XtraEditors.XtraForm)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(Windows.Forms.UserControl)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(DevExpress.XtraEditors.XtraUserControl)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(DevExpress.XtraReports.UI.XtraReport)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(DevExpress.XtraGrid.GridControl)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(HTLFW.ListKeyValues)) OrElse _
                    pObject.GetType.IsSubclassOf(GetType(HTLFW.UserPermissions)) _
                    Then
                    pObject.Dispose()
                Else
                    If pObject.GetType.Equals(GetType(System.Data.SqlClient.SqlConnection)) Then
                        pObject.Close()
                        SqlClient.SqlConnection.ClearPool(pObject)
                        pObject.Dispose()
                        SqlClient.SqlConnection.ClearAllPools()
                    ElseIf pObject.GetType.Equals(GetType(System.Data.Linq.DataContext)) Then
                        If pObject.Connection IsNot Nothing Then
                            pObject.Connection.Close()
                            SqlClient.SqlConnection.ClearPool(pObject.Connection)
                            pObject.Connection.Dispose()
                            SqlClient.SqlConnection.ClearAllPools()
                        End If
                        pObject.Dispose()
                    End If
                End If
            End If
        Catch ex As Exception
        End Try
        pObject = Nothing
        'GC.Collect()
        'GC.Collect(GC.MaxGeneration)
        'GC.WaitForFullGCComplete()
        'GC.Collect()
    End Sub

End Module
