﻿Imports System.Runtime.CompilerServices
Imports System.Data.Common
Imports System.Data.Linq
Imports HTLFW

Module DataTableEx

    <Extension()> Public Sub RemoveAll(ByVal pRows As System.Data.DataRowCollection, ByVal pDataRow As List(Of DataRow))
        If pRows Is Nothing Then Exit Sub
        If pRows.Count = 0 Then Exit Sub
        For Each mRow As DataRow In pDataRow
            Try
                pRows.Remove(mRow)
            Catch ex As Exception

            End Try
        Next
    End Sub

    <Extension()> Public Sub RemoveAllRows(ByVal pDataTable As DataTable, ByVal pDataRow As List(Of DataRow))
        If pDataTable Is Nothing Then Exit Sub
        If pDataTable.Rows.Count = 0 Then Exit Sub
        For Each mRow As DataRow In pDataRow
            Try
                pDataTable.Rows.Remove(mRow)
            Catch ex As Exception

            End Try
        Next
    End Sub

    <Extension()> Public Function GetRows(ByVal pDataTable As DataTable, ByVal ParamArray pWhereParams() As WhereObjectParam) As List(Of DataRow)
        If pDataTable Is Nothing Then Return Nothing
        If pDataTable.Rows.Count = 0 Then Return Nothing
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return Nothing
                If mFoundRows.Count = 0 Then Return Nothing
            End If
            Return mFoundRows.ToList
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    <Extension()> Public Function IsNoData(ByVal pDataTable As DataTable) As Boolean
        Return (pDataTable Is Nothing OrElse pDataTable.Rows.Count = 0)
    End Function

    <Extension()> Public Function DLookup(ByVal pDataTable As DataTable, ByVal pFieldName As String) As Object
        Return DLookup(pDataTable, pFieldName, Nothing)
    End Function

    <Extension()> Public Function DLookup(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As Object
        If pDataTable Is Nothing Then Return Nothing
        If pDataTable.Rows.Count = 0 Then Return Nothing
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return Nothing
                If mFoundRows.Count = 0 Then Return Nothing
                Return mFoundRows.FirstOrDefault().Item(pFieldName)
            Else
                Return mFoundRows.FirstOrDefault().Item(pFieldName)
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    <Extension()> Public Function DSum(ByVal pDataTable As DataTable, ByVal pFieldName As String) As Double
        Return DSum(pDataTable, pFieldName, Nothing)
    End Function

    <Extension()> Public Function DSum(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As Double
        If pDataTable Is Nothing Then Return 0.0
        If pDataTable.Rows.Count = 0 Then Return 0.0
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return 0.0
                If mFoundRows.Count = 0 Then Return 0.0
            End If
            Return CType(mFoundRows.Sum(Function(pp) CType(pp.Item(pFieldName), Double)), Double)
        Catch ex As Exception
            Return 0.0
        End Try
    End Function

    <Extension()> Public Function DCount(ByVal pDataTable As DataTable, ByVal pFieldName As String) As Integer
        Return DCount(pDataTable, pFieldName, Nothing)
    End Function

    <Extension()> Public Function DCount(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As Integer
        If pDataTable Is Nothing Then Return 0
        If pDataTable.Rows.Count = 0 Then Return 0
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return 0
                If mFoundRows.Count = 0 Then Return 0
            End If
            Return pDataTable.Rows.OfType(Of DataRow)().Count
        Catch ex As Exception
            Return 0
        End Try
    End Function

    <Extension()> Public Function DMax(Of T)(ByVal pDataTable As DataTable, ByVal pFieldName As String) As T
        Dim mResult As Object = DMax(pDataTable, pFieldName, Nothing)
        If Not mResult Is Nothing Then
            Return CType(mResult, T)
        Else
            Return Nothing
        End If
    End Function

    <Extension()> Public Function DMax(Of T)(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As T
        Dim mResult As Object = DMax(pDataTable, pFieldName, pWhereParams)
        If Not mResult Is Nothing Then
            Return CType(mResult, T)
        Else
            Return Nothing
        End If
    End Function

    <Extension()> Public Function DMax(ByVal pDataTable As DataTable, ByVal pFieldName As String) As Object
        Return DMax(pDataTable, pFieldName, Nothing)
    End Function

    <Extension()> Public Function DMax(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As Object
        If pDataTable Is Nothing Then Return Nothing
        If pDataTable.Rows.Count = 0 Then Return Nothing
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return Nothing
                If mFoundRows.Count = 0 Then Return Nothing
            End If
            Return pDataTable.Rows.OfType(Of DataRow)().OrderByDescending(Function(pp) pp.Item(pFieldName)).FirstOrDefault().Item(pFieldName)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    <Extension()> Public Function DMin(Of T)(ByVal pDataTable As DataTable, ByVal pFieldName As String) As T
        Dim mResult As Object = DMin(pDataTable, pFieldName, Nothing)
        If Not mResult Is Nothing Then
            Return CType(mResult, T)
        Else
            Return Nothing
        End If
    End Function

    <Extension()> Public Function DMin(Of T)(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As T
        Dim mResult As Object = DMin(pDataTable, pFieldName, pWhereParams)
        If Not mResult Is Nothing Then
            Return CType(mResult, T)
        Else
            Return Nothing
        End If
    End Function

    <Extension()> Public Function DMin(ByVal pDataTable As DataTable, ByVal pFieldName As String) As Object
        Return DMin(pDataTable, pFieldName, Nothing)
    End Function

    <Extension()> Public Function DMin(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As Object
        If pDataTable Is Nothing Then Return Nothing
        If pDataTable.Rows.Count = 0 Then Return Nothing
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return Nothing
                If mFoundRows.Count = 0 Then Return Nothing
            End If
            Return pDataTable.Rows.OfType(Of DataRow)().OrderBy(Function(pp) pp.Item(pFieldName)).FirstOrDefault().Item(pFieldName)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    <Extension()> Public Function DExists(ByVal pDataTable As DataTable, ByVal pFieldName As String) As Integer
        Return DExists(pDataTable, pFieldName, Nothing)
    End Function

    <Extension()> Public Function DExists(ByVal pDataTable As DataTable, ByVal pFieldName As String, ByVal ParamArray pWhereParams() As WhereObjectParam) As Boolean
        If pDataTable Is Nothing Then Return False
        If pDataTable.Rows.Count = 0 Then Return False
        Try
            Dim mFoundRows As List(Of DataRow) = pDataTable.Rows.OfType(Of DataRow)().ToList
            If Not pWhereParams Is Nothing Then
                For i As Integer = 0 To pWhereParams.Count - 1
                    mFoundRows = mFoundRows.Where(Function(pp) pp.Item(pWhereParams(i).Name).Equals(pWhereParams(i).Value) = True).ToList
                Next
                If mFoundRows Is Nothing Then Return False
                If mFoundRows.Count = 0 Then Return False
            End If
            Return pDataTable.Rows.OfType(Of DataRow)().Count > 0
        Catch ex As Exception
            Return False
        End Try
    End Function

End Module
