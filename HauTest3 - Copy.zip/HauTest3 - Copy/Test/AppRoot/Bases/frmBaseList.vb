﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports System.ComponentModel
Imports DBs

#End Region

Public Class frmBaseList

#Region "Declares"

    Private _DBContext As DBs.AppDbDataContext

#End Region

#Region "Properties"

#End Region

#Region "Constructors"

    Public Sub New()
        InitializeComponent()
        DoubleClickToModify = True
    End Sub

    Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Try
            If _DBContext IsNot Nothing Then
                _DBContext.Release()
            End If
            GC.Collect()
        Catch ex As Exception
        End Try
        MyDataTable.Release()
        ReleaseMemory()
    End Sub

#End Region

#Region "Subs"

    Public Sub ResetDBContext()
        If DesignMode Then Exit Sub
        If IsDisposed OrElse Disposing Then Exit Sub
        If Not AppIsReady Then Exit Sub
        Try
            _DBContext.Release()
        Catch ex As Exception
        End Try

        Dim mConnection As SqlClient.SqlConnection = Nothing
        Try
            mConnection = AppBase.AppConnectionInfor.CreateConnection
        Catch ex As Exception
            Try
                mConnection = AppBase.AppConnectionInfor.CreateConnection
            Catch ex1 As Exception
                Try
                    mConnection = AppBase.AppConnectionInfor.CreateConnection
                Catch ex2 As Exception
                    Try
                        mConnection = AppBase.AppConnectionInfor.CreateConnection
                    Catch ex3 As Exception
                        Try
                            mConnection = AppBase.AppConnectionInfor.CreateConnection
                        Catch ex4 As Exception
                        End Try
                    End Try
                End Try
            End Try
        End Try

        If Not mConnection Is Nothing Then
            Try
                _DBContext = New DBs.AppDbDataContext(mConnection)
                _DBContext.CommandTimeout = 0 'AppBase.AppConnectionInfor.ConnectionTimeOut
            Catch ex As Exception
                System.Threading.Thread.Sleep(100)
                Try
                    _DBContext = New DBs.AppDbDataContext(mConnection)
                    _DBContext.CommandTimeout = 0 'AppBase.AppConnectionInfor.ConnectionTimeOut
                Catch ex1 As Exception
                    System.Threading.Thread.Sleep(100)
                    Try
                        _DBContext = New DBs.AppDbDataContext(mConnection)
                        _DBContext.CommandTimeout = 0 'AppBase.AppConnectionInfor.ConnectionTimeOut
                    Catch ex2 As Exception
                        System.Threading.Thread.Sleep(100)
                        Try
                            _DBContext = New DBs.AppDbDataContext(mConnection)
                            _DBContext.CommandTimeout = 0 'AppBase.AppConnectionInfor.ConnectionTimeOut
                        Catch ex3 As Exception
                            System.Threading.Thread.Sleep(100)
                            Try
                                _DBContext = New DBs.AppDbDataContext(mConnection)
                                _DBContext.CommandTimeout = 0 'AppBase.AppConnectionInfor.ConnectionTimeOut
                            Catch ex4 As Exception
                            End Try
                        End Try
                    End Try
                End Try
            End Try
        Else
            _DBContext = Nothing
        End If
        If _DBContext Is Nothing Then
            AppDevWaitingForm.Hide()
            HTLFW.MsgBox.ShowErrorStop(HTLFW.HTLLib.HTLStringFuncs.TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorRUNTIMECONNECTFAILED, ""))
            RestartAppOnConnectionBroken()
            Exit Sub
        End If
    End Sub

#End Region

#Region "Functions"

    Public Function DBContext() As DBs.AppDbDataContext
        If AppBase.AppStatus <> eAppStatus.None And AppBase.AppStatus <> eAppStatus.RefreshConfig Then
            ResetDBContext()
        End If
        Return _DBContext
    End Function

    Public Function DBContextCreateNew() As DBs.AppDbDataContext
        Try
            Dim mDBContext = New DBs.AppDbDataContext(AppBase.AppConnectionInfor.CreateConnection)
            mDBContext.CommandTimeout = 0 'AppBase.AppConnectionInfor.ConnectionTimeOut
            Return mDBContext
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    '    Public Overridable Function GetAppPermission() As AppRoot.AppUserPermissions.AppUserPermission
    '        Return AppRoot.AppUserPermissions.Instance.GetAppUserPermission(FunctionID)
    '    End Function
    '    Public Overridable Function GetAppPermission(ByVal pFunctionID As String) As AppRoot.AppUserPermissions.AppUserPermission
    '        Return AppRoot.AppUserPermissions.Instance.GetAppUserPermission(pFunctionID)
    '    End Function
    '    Public Overridable Function GetFuncOrder() As String
    '        Return AppRoot.AppUserPermissions.Instance.GetFuncOrder(FunctionID)
    '    End Function
    '    Public Overridable Function GetFuncOrder(ByVal pFunctionID As String) As String
    '        Return AppRoot.AppUserPermissions.Instance.GetFuncOrder(pFunctionID)
    '    End Function

    '    Public Overrides Function NgayBatDau() As Date
    '        Select Case DBs.SystemValues.DATERANGELIMIT()
    '            Case "R", "B"
    '                Select Case DBs.SystemValues.DATERANGETYPE()
    '                    Case "D"
    '                        Return DateAdd(DateInterval.Day, -DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                    Case "W"
    '                        Return DateAdd(DateInterval.Day, -DBs.SystemValues.DATERANGEVAL * 7, NgayGioHeThong.Date)
    '                    Case "M"
    '                        Return DateAdd(DateInterval.Month, -DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                    Case "Q"
    '                        Return DateAdd(DateInterval.Quarter, -DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                    Case "Y"
    '                        Return DateAdd(DateInterval.Year, -DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                End Select
    '            Case "A"
    '                Return NgayGioHeThong.Date
    '            Case "M"
    '                Return DBs.SystemValues.DATERANGEMIN()
    '        End Select
    '    End Function
    '    Public Overrides Function NgayKetThuc() As Date
    '        Select Case DBs.SystemValues.DATERANGELIMIT()
    '            Case "R", "A"
    '                Select Case DBs.SystemValues.DATERANGETYPE()
    '                    Case "D"
    '                        Return DateAdd(DateInterval.Day, DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                    Case "W"
    '                        Return DateAdd(DateInterval.Day, DBs.SystemValues.DATERANGEVAL * 7, NgayGioHeThong.Date)
    '                    Case "M"
    '                        Return DateAdd(DateInterval.Month, DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                    Case "Q"
    '                        Return DateAdd(DateInterval.Quarter, DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                    Case "Y"
    '                        Return DateAdd(DateInterval.Year, DBs.SystemValues.DATERANGEVAL, NgayGioHeThong.Date)
    '                End Select
    '            Case "B"
    '                Return NgayGioHeThong.Date
    '            Case "M"
    '                Return DBs.SystemValues.DATERANGEMAX()
    '        End Select
    '    End Function
    '    Public Overrides Function KyHienHanh() As String
    '        Return DBContext.fGETSTR_CurrPeriod
    '    End Function
    '    Public Function NgayBatDauKyHienHanh() As Date
    '        Return DBContext.fGETDATEBEGIN_FromPeriod(Nothing)
    '    End Function
    '    Public Function NgayKetThucKyHienHanh() As Date
    '        Return DBContext.fGETDATEEND_FromPeriod(Nothing)
    '    End Function
    '    Public Function NgayBatDauKy(ByVal pKy As String) As Date
    '        Return DBContext.fGETDATEBEGIN_FromPeriod(pKy)
    '    End Function
    '    Public Function NgayKetThucKy(ByVal pKy As String) As Date
    '        Return DBContext.fGETDATEEND_FromPeriod(pKy)
    '    End Function

    '#Region "System Values"

    '    Public Function sysval_SOLESOLUONG() As Integer
    '        Return DBs.SystemValues.SOLESOLUONG
    '    End Function
    '    Public Function sysval_SOLEDONGIA() As Integer
    '        Return DBs.SystemValues.SOLEDONGIA
    '    End Function
    '    Public Function sysval_SOLEDONGIANGOAITE() As Integer
    '        Return DBs.SystemValues.SOLEDONGIANGOAITE
    '    End Function
    '    Public Function sysval_SOLESOTIEN() As Integer
    '        Return DBs.SystemValues.SOLESOTIEN
    '    End Function
    '    Public Function sysval_SOLESOTIENNGOAITE() As Integer
    '        Return DBs.SystemValues.SOLESOTIENNGOAITE
    '    End Function
    '    Public Function sysval_SOLETYLE() As Integer
    '        Return DBs.SystemValues.SOLETYLE
    '    End Function
    '    Public Function sysval_CUSCODE() As String
    '        Return DBs.SystemValues.CUSCODE
    '    End Function

    '#End Region

#End Region

#Region "Messages"

    Public Overrides Function ShowDeleteSystemDataError() As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowDeleteSystemDataError()
    End Function

    Public Overrides Function ShowNoData() As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowNoData()
    End Function

    Public Overrides Function ShowInfor(ByVal pMessage As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowInfor(pMessage)
    End Function

    Public Overrides Function ShowInfor(ByVal pMessage As String, ByVal pTitle As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowInfor(pMessage, pTitle)
    End Function

    Public Overrides Function ShowError(ByVal pMessage As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowError(pMessage)
    End Function

    Public Overrides Function ShowError(ByVal pMessage As String, ByVal pTitle As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowError(pMessage, pTitle)
    End Function

    Public Overrides Function ShowErrorStop(ByVal pMessage As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowErrorStop(pMessage)
    End Function

    Public Overrides Function ShowErrorStop(ByVal pMessage As String, ByVal pTitle As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowErrorStop(pMessage, pTitle)
    End Function

    Public Overrides Function ShowSystemError() As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowSystemError()
    End Function

    Public Overrides Function ShowUnknownError(ByVal pErrInfor As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowUnknownError(pErrInfor)
    End Function

    Public Overrides Function ShowConfirm(ByVal pMessage As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirm(pMessage)
    End Function

    Public Overrides Function ShowConfirm(ByVal pMessage As String, ByVal pTitle As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirm(pMessage, pTitle)
    End Function

    Public Overrides Function ShowConfirmDelete(ByVal pMessage As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirmDelete(pMessage)
    End Function

    Public Overrides Function ShowConfirmDelete1(ByVal pDataName1 As String, ByVal pDataValue1 As Object) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirmDelete1(pDataName1, pDataValue1)
    End Function

    Public Overrides Function ShowConfirmDelete2(ByVal pDataName1 As String, ByVal pDataValue1 As Object, ByVal pDataName2 As String, ByVal pDataValue2 As Object) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirmDelete2(pDataName1, pDataValue1, pDataName2, pDataValue2)
    End Function

    Public Overrides Function ShowConfirmDelete3(ByVal pDataName1 As String, ByVal pDataValue1 As Object, ByVal pDataName2 As String, ByVal pDataValue2 As Object, ByVal pDataName3 As String, ByVal pDataValue3 As Object) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirmDelete3(pDataName1, pDataValue1, pDataName2, pDataValue2, pDataName3, pDataValue3)
    End Function

    Public Overrides Function ShowConfirmDelete4(ByVal pDataName1 As String, ByVal pDataValue1 As Object, ByVal pDataName2 As String, ByVal pDataValue2 As Object, ByVal pDataName3 As String, ByVal pDataValue3 As Object, ByVal pDataName4 As String, ByVal pDataValue4 As Object) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowConfirmDelete4(pDataName1, pDataValue1, pDataName2, pDataValue2, pDataName3, pDataValue3, pDataName4, pDataValue4)
    End Function

    Public Overrides Function ShowWarning(ByVal pMessage As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowWarning(pMessage)
    End Function

    Public Overrides Function ShowWarning(ByVal pMessage As String, ByVal pTitle As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowWarning(pMessage, pTitle)
    End Function

    Public Overrides Function ShowValidateRequired(ByVal pControl As Object, ByVal pDataName As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowValidateRequired(pControl, pDataName)
    End Function

    Public Overrides Function ShowInsertDuplicated(ByVal pValue As Object, ByVal pControl As Object, ByVal pDataName As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowInsertDuplicated(pValue, pControl, pDataName)
    End Function

    Public Overrides Function ShowInsertDuplicated(ByVal pControl As Object, ByVal pDataName As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowInsertDuplicated(pControl, pDataName)
    End Function

    Public Overrides Function ShowInvalidateCodeField(ByVal pControl As Object, ByVal pDataName As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowInvalidateCodeField(pControl, pDataName)
    End Function

    Public Overrides Function ShowDeleteFailedInUsed() As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowDeleteFailedInUsed()
    End Function

    Public Overrides Function ShowDeleteFailedInUsedAdv(ByVal pInUsedObjectList As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowDeleteFailedInUsedAdv(pInUsedObjectList)
    End Function

    Public Overrides Function ShowNotExistsFK(ByVal pControl As Object, ByVal pDataName As String) As System.Windows.Forms.DialogResult
        AppDevWaitingForm.Hide()
        Return MyBase.ShowNotExistsFK(pControl, pDataName)
    End Function

#End Region

End Class