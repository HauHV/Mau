﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBaseListEditable
    Inherits HTLFW.frmBaseListEditable

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        CType(Me.radMode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.radMode.SuspendLayout()
        CType(Me.chkModifyMode.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkViewMode.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(787, 352)
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        '
        'cmdExcel
        '
        Me.cmdExcel.Location = New System.Drawing.Point(746, 352)
        Me.HelpProvider.SetShowHelp(Me.cmdExcel, True)
        '
        'chkModifyMode
        '
        Me.chkModifyMode.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkModifyMode.Properties.Appearance.Options.UseFont = True
        Me.chkModifyMode.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkModifyMode.Properties.AppearanceDisabled.Options.UseFont = True
        Me.chkModifyMode.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkModifyMode.Properties.AppearanceFocused.Options.UseFont = True
        Me.chkModifyMode.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkModifyMode.Properties.AppearanceReadOnly.Options.UseFont = True
        '
        'chkViewMode
        '
        Me.chkViewMode.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkViewMode.Properties.Appearance.Options.UseFont = True
        Me.chkViewMode.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkViewMode.Properties.AppearanceDisabled.Options.UseFont = True
        Me.chkViewMode.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkViewMode.Properties.AppearanceFocused.Options.UseFont = True
        Me.chkViewMode.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.chkViewMode.Properties.AppearanceReadOnly.Options.UseFont = True
        '
        'frmBaseListEditable
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(874, 387)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmBaseListEditable"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Controls.SetChildIndex(Me.radMode, 0)
        Me.Controls.SetChildIndex(Me.cmdExit, 0)
        Me.Controls.SetChildIndex(Me.cmdExcel, 0)
        CType(Me.radMode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.radMode.ResumeLayout(False)
        CType(Me.chkModifyMode.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkViewMode.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
End Class
