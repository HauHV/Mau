﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBaseListInput
    Inherits HTLFW.frmBaseListInput

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdSaveAndClose
        '
        Me.HelpProvider.SetShowHelp(Me.cmdSaveAndClose, True)
        '
        'cmdSave
        '
        Me.HelpProvider.SetShowHelp(Me.cmdSave, True)
        '
        'cmdExit
        '
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        '
        'grUpdateInfor
        '
        Me.grUpdateInfor.AppearanceCaption.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.grUpdateInfor.AppearanceCaption.Options.UseFont = True
        Me.HelpProvider.SetShowHelp(Me.grUpdateInfor, True)
        '
        'frmBaseListInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(474, 261)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmBaseListInput"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Text = "frmBaseListInput"
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
End Class
