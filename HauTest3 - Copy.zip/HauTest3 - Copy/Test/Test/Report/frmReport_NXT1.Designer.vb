﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReport_NXT1
    Inherits AppRoot.frmBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.components = New System.ComponentModel.Container
        Me.txtPeriod = New HTLFW.TextEditPeriod
        Me.Label1 = New HTLFW.Label
        Me.Label2 = New HTLFW.Label
        Me.Label3 = New HTLFW.Label
        Me.txtDateFrom = New HTLFW.TextEditPeriod
        Me.txtDateTo = New HTLFW.TextEditPeriod
        Me.Label4 = New HTLFW.Label
        Me.Label5 = New HTLFW.Label
        Me.UcGridLookUpEdit1 = New HTLFW.UCGridLookUpEdit
        Me.UcGridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.UcGridLookUpEdit2 = New HTLFW.UCGridLookUpEdit
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.UcGridLookUpEdit3 = New HTLFW.UCGridLookUpEdit
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.UcGridLookUpEdit4 = New HTLFW.UCGridLookUpEdit
        Me.GridView3 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.Label6 = New HTLFW.Label
        Me.Label7 = New HTLFW.Label
        Me.UcGridControl1 = New HTLFW.UCGridControl
        Me.GridView4 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.UcButton1 = New HTLFW.UCButton
        Me.UcButton2 = New HTLFW.UCButton
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPeriod.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDateFrom.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDateTo.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit2.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit3.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit4.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPeriod
        '
        Me.txtPeriod.EnterMoveNextControl = True
        Me.txtPeriod.ForceRelateControlOnLeave = True
        Me.txtPeriod.IsFirstInPair = False
        Me.txtPeriod.Location = New System.Drawing.Point(53, 9)
        Me.txtPeriod.MyMaxValue = 99
        Me.txtPeriod.MyMinValue = 1
        Me.txtPeriod.MyRelateControl = Nothing
        Me.txtPeriod.MyTag01 = Nothing
        Me.txtPeriod.MyTag02 = Nothing
        Me.txtPeriod.MyTag03 = Nothing
        Me.txtPeriod.Name = "txtPeriod"
        Me.txtPeriod.PeriodFormatString = ""
        Me.txtPeriod.PeriodString = ""
        Me.txtPeriod.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtPeriod.Properties.Appearance.Options.UseFont = True
        Me.txtPeriod.Properties.Appearance.Options.UseTextOptions = True
        Me.txtPeriod.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtPeriod.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtPeriod.Properties.AppearanceDisabled.Options.UseFont = True
        Me.txtPeriod.Properties.AppearanceDisabled.Options.UseTextOptions = True
        Me.txtPeriod.Properties.AppearanceDisabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtPeriod.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtPeriod.Properties.AppearanceFocused.Options.UseFont = True
        Me.txtPeriod.Properties.AppearanceFocused.Options.UseTextOptions = True
        Me.txtPeriod.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtPeriod.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtPeriod.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.txtPeriod.Properties.AppearanceReadOnly.Options.UseTextOptions = True
        Me.txtPeriod.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtPeriod.Properties.DisplayFormat.FormatString = "PERIOD"
        Me.txtPeriod.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtPeriod.Properties.EditFormat.FormatString = "PERIOD"
        Me.txtPeriod.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtPeriod.Properties.EditValue = Nothing
        Me.txtPeriod.Properties.Mask.EditMask = "\d\d/(19\d\d|2\d\d\d)"
        Me.txtPeriod.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtPeriod.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtPeriod.Properties.MaxLength = 7
        Me.txtPeriod.Properties.MyMaxValue = 99
        Me.txtPeriod.Properties.MyMinValue = 1
        Me.txtPeriod.Properties.UseDefaultMode = True
        Me.txtPeriod.Properties.ValidateOnEnterKey = True
        Me.txtPeriod.Size = New System.Drawing.Size(69, 21)
        Me.txtPeriod.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label1.AutoSetTextToToolTip = False
        Me.Label1.Location = New System.Drawing.Point(12, 12)
        Me.Label1.MyNextControl = Me.txtPeriod
        Me.Label1.MyTag01 = Nothing
        Me.Label1.MyTag02 = Nothing
        Me.Label1.MyTag03 = Nothing
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.TagEN = Nothing
        Me.Label1.Text = "Tháng"
        '
        'Label2
        '
        Me.Label2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label2.AutoSetTextToToolTip = False
        Me.Label2.Location = New System.Drawing.Point(138, 12)
        Me.Label2.MyNextControl = Me.txtPeriod
        Me.Label2.MyTag01 = Nothing
        Me.Label2.MyTag02 = Nothing
        Me.Label2.MyTag03 = Nothing
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.TagEN = Nothing
        Me.Label2.Text = "Từ ngày "
        '
        'Label3
        '
        Me.Label3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label3.AutoSetTextToToolTip = False
        Me.Label3.Location = New System.Drawing.Point(284, 12)
        Me.Label3.MyNextControl = Me.txtPeriod
        Me.Label3.MyTag01 = Nothing
        Me.Label3.MyTag02 = Nothing
        Me.Label3.MyTag03 = Nothing
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(23, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.TagEN = Nothing
        Me.Label3.Text = "Đến"
        '
        'txtDateFrom
        '
        Me.txtDateFrom.EnterMoveNextControl = True
        Me.txtDateFrom.ForceRelateControlOnLeave = True
        Me.txtDateFrom.IsFirstInPair = False
        Me.txtDateFrom.Location = New System.Drawing.Point(194, 9)
        Me.txtDateFrom.MyMaxValue = 99
        Me.txtDateFrom.MyMinValue = 1
        Me.txtDateFrom.MyRelateControl = Nothing
        Me.txtDateFrom.MyTag01 = Nothing
        Me.txtDateFrom.MyTag02 = Nothing
        Me.txtDateFrom.MyTag03 = Nothing
        Me.txtDateFrom.Name = "txtDateFrom"
        Me.txtDateFrom.PeriodFormatString = ""
        Me.txtDateFrom.PeriodString = ""
        Me.txtDateFrom.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateFrom.Properties.Appearance.Options.UseFont = True
        Me.txtDateFrom.Properties.Appearance.Options.UseTextOptions = True
        Me.txtDateFrom.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateFrom.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateFrom.Properties.AppearanceDisabled.Options.UseFont = True
        Me.txtDateFrom.Properties.AppearanceDisabled.Options.UseTextOptions = True
        Me.txtDateFrom.Properties.AppearanceDisabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateFrom.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateFrom.Properties.AppearanceFocused.Options.UseFont = True
        Me.txtDateFrom.Properties.AppearanceFocused.Options.UseTextOptions = True
        Me.txtDateFrom.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateFrom.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateFrom.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.txtDateFrom.Properties.AppearanceReadOnly.Options.UseTextOptions = True
        Me.txtDateFrom.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateFrom.Properties.DisplayFormat.FormatString = "PERIOD"
        Me.txtDateFrom.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtDateFrom.Properties.EditFormat.FormatString = "PERIOD"
        Me.txtDateFrom.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtDateFrom.Properties.EditValue = Nothing
        Me.txtDateFrom.Properties.Mask.EditMask = "\d\d/(19\d\d|2\d\d\d)"
        Me.txtDateFrom.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtDateFrom.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtDateFrom.Properties.MaxLength = 7
        Me.txtDateFrom.Properties.MyMaxValue = 99
        Me.txtDateFrom.Properties.MyMinValue = 1
        Me.txtDateFrom.Properties.UseDefaultMode = True
        Me.txtDateFrom.Properties.ValidateOnEnterKey = True
        Me.txtDateFrom.Size = New System.Drawing.Size(84, 21)
        Me.txtDateFrom.TabIndex = 4
        '
        'txtDateTo
        '
        Me.txtDateTo.EnterMoveNextControl = True
        Me.txtDateTo.ForceRelateControlOnLeave = True
        Me.txtDateTo.IsFirstInPair = False
        Me.txtDateTo.Location = New System.Drawing.Point(313, 9)
        Me.txtDateTo.MyMaxValue = 99
        Me.txtDateTo.MyMinValue = 1
        Me.txtDateTo.MyRelateControl = Nothing
        Me.txtDateTo.MyTag01 = Nothing
        Me.txtDateTo.MyTag02 = Nothing
        Me.txtDateTo.MyTag03 = Nothing
        Me.txtDateTo.Name = "txtDateTo"
        Me.txtDateTo.PeriodFormatString = ""
        Me.txtDateTo.PeriodString = ""
        Me.txtDateTo.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateTo.Properties.Appearance.Options.UseFont = True
        Me.txtDateTo.Properties.Appearance.Options.UseTextOptions = True
        Me.txtDateTo.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateTo.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateTo.Properties.AppearanceDisabled.Options.UseFont = True
        Me.txtDateTo.Properties.AppearanceDisabled.Options.UseTextOptions = True
        Me.txtDateTo.Properties.AppearanceDisabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateTo.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateTo.Properties.AppearanceFocused.Options.UseFont = True
        Me.txtDateTo.Properties.AppearanceFocused.Options.UseTextOptions = True
        Me.txtDateTo.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateTo.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtDateTo.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.txtDateTo.Properties.AppearanceReadOnly.Options.UseTextOptions = True
        Me.txtDateTo.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtDateTo.Properties.DisplayFormat.FormatString = "PERIOD"
        Me.txtDateTo.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtDateTo.Properties.EditFormat.FormatString = "PERIOD"
        Me.txtDateTo.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtDateTo.Properties.EditValue = Nothing
        Me.txtDateTo.Properties.Mask.EditMask = "\d\d/(19\d\d|2\d\d\d)"
        Me.txtDateTo.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtDateTo.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtDateTo.Properties.MaxLength = 7
        Me.txtDateTo.Properties.MyMaxValue = 99
        Me.txtDateTo.Properties.MyMinValue = 1
        Me.txtDateTo.Properties.UseDefaultMode = True
        Me.txtDateTo.Properties.ValidateOnEnterKey = True
        Me.txtDateTo.Size = New System.Drawing.Size(84, 21)
        Me.txtDateTo.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label4.AutoSetTextToToolTip = False
        Me.Label4.Location = New System.Drawing.Point(460, 12)
        Me.Label4.MyNextControl = Me.txtPeriod
        Me.Label4.MyTag01 = Nothing
        Me.Label4.MyTag02 = Nothing
        Me.Label4.MyTag03 = Nothing
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.TagEN = Nothing
        Me.Label4.Text = "Hàng"
        '
        'Label5
        '
        Me.Label5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label5.AutoSetTextToToolTip = False
        Me.Label5.Location = New System.Drawing.Point(634, 12)
        Me.Label5.MyNextControl = Me.txtPeriod
        Me.Label5.MyTag01 = Nothing
        Me.Label5.MyTag02 = Nothing
        Me.Label5.MyTag03 = Nothing
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(23, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.TagEN = Nothing
        Me.Label5.Text = "Đến"
        '
        'UcGridLookUpEdit1
        '
        Me.UcGridLookUpEdit1.AllowNoSourceText = True
        Me.UcGridLookUpEdit1.AllowNULL = True
        Me.UcGridLookUpEdit1.ColumnWidths = Nothing
        Me.UcGridLookUpEdit1.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit1.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit1.ForceRelateControlOnLeave = True
        Me.UcGridLookUpEdit1.HasFilterRow = True
        Me.UcGridLookUpEdit1.IsChange = False
        Me.UcGridLookUpEdit1.IsFirstInPair = False
        Me.UcGridLookUpEdit1.Location = New System.Drawing.Point(496, 9)
        Me.UcGridLookUpEdit1.MyAutoFormat = False
        Me.UcGridLookUpEdit1.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit1.MyDataType = HTLFW.eValidDataRange.StringType
        Me.UcGridLookUpEdit1.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1.MyRelateControl = Nothing
        Me.UcGridLookUpEdit1.MyTag01 = Nothing
        Me.UcGridLookUpEdit1.MyTag02 = Nothing
        Me.UcGridLookUpEdit1.MyTag03 = Nothing
        Me.UcGridLookUpEdit1.MyTextControl = Nothing
        Me.UcGridLookUpEdit1.Name = "UcGridLookUpEdit1"
        Me.UcGridLookUpEdit1.Properties.AllowNoSourceText = True
        Me.UcGridLookUpEdit1.Properties.AllowNULL = True
        Me.UcGridLookUpEdit1.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1.Properties.Appearance.Options.UseFont = True
        Me.UcGridLookUpEdit1.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.UcGridLookUpEdit1.Properties.ColumnWidths = Nothing
        Me.UcGridLookUpEdit1.Properties.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit1.Properties.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit1.Properties.EditValue = Nothing
        Me.UcGridLookUpEdit1.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1.Properties.HasFilterRow = True
        Me.UcGridLookUpEdit1.Properties.IsChange = False
        Me.UcGridLookUpEdit1.Properties.MyAutoFormat = False
        Me.UcGridLookUpEdit1.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit1.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1.Properties.MyTextControl = Nothing
        Me.UcGridLookUpEdit1.Properties.View = Me.UcGridLookUpEdit1View
        Me.UcGridLookUpEdit1.Size = New System.Drawing.Size(132, 21)
        Me.UcGridLookUpEdit1.TabIndex = 10
        '
        'UcGridLookUpEdit1View
        '
        Me.UcGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.UcGridLookUpEdit1View.Name = "UcGridLookUpEdit1View"
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'UcGridLookUpEdit2
        '
        Me.UcGridLookUpEdit2.AllowNoSourceText = True
        Me.UcGridLookUpEdit2.AllowNULL = True
        Me.UcGridLookUpEdit2.ColumnWidths = Nothing
        Me.UcGridLookUpEdit2.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit2.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit2.ForceRelateControlOnLeave = True
        Me.UcGridLookUpEdit2.HasFilterRow = True
        Me.UcGridLookUpEdit2.IsChange = False
        Me.UcGridLookUpEdit2.IsFirstInPair = False
        Me.UcGridLookUpEdit2.Location = New System.Drawing.Point(663, 9)
        Me.UcGridLookUpEdit2.MyAutoFormat = False
        Me.UcGridLookUpEdit2.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit2.MyDataType = HTLFW.eValidDataRange.StringType
        Me.UcGridLookUpEdit2.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit2.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit2.MyRelateControl = Nothing
        Me.UcGridLookUpEdit2.MyTag01 = Nothing
        Me.UcGridLookUpEdit2.MyTag02 = Nothing
        Me.UcGridLookUpEdit2.MyTag03 = Nothing
        Me.UcGridLookUpEdit2.MyTextControl = Nothing
        Me.UcGridLookUpEdit2.Name = "UcGridLookUpEdit2"
        Me.UcGridLookUpEdit2.Properties.AllowNoSourceText = True
        Me.UcGridLookUpEdit2.Properties.AllowNULL = True
        Me.UcGridLookUpEdit2.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit2.Properties.Appearance.Options.UseFont = True
        Me.UcGridLookUpEdit2.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.UcGridLookUpEdit2.Properties.ColumnWidths = Nothing
        Me.UcGridLookUpEdit2.Properties.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit2.Properties.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit2.Properties.EditValue = Nothing
        Me.UcGridLookUpEdit2.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit2.Properties.HasFilterRow = True
        Me.UcGridLookUpEdit2.Properties.IsChange = False
        Me.UcGridLookUpEdit2.Properties.MyAutoFormat = False
        Me.UcGridLookUpEdit2.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit2.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit2.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit2.Properties.MyTextControl = Nothing
        Me.UcGridLookUpEdit2.Properties.View = Me.GridView1
        Me.UcGridLookUpEdit2.Size = New System.Drawing.Size(132, 21)
        Me.UcGridLookUpEdit2.TabIndex = 11
        '
        'GridView1
        '
        Me.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'UcGridLookUpEdit3
        '
        Me.UcGridLookUpEdit3.AllowNoSourceText = True
        Me.UcGridLookUpEdit3.AllowNULL = True
        Me.UcGridLookUpEdit3.ColumnWidths = Nothing
        Me.UcGridLookUpEdit3.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit3.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit3.ForceRelateControlOnLeave = True
        Me.UcGridLookUpEdit3.HasFilterRow = True
        Me.UcGridLookUpEdit3.IsChange = False
        Me.UcGridLookUpEdit3.IsFirstInPair = False
        Me.UcGridLookUpEdit3.Location = New System.Drawing.Point(663, 36)
        Me.UcGridLookUpEdit3.MyAutoFormat = False
        Me.UcGridLookUpEdit3.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit3.MyDataType = HTLFW.eValidDataRange.StringType
        Me.UcGridLookUpEdit3.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit3.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit3.MyRelateControl = Nothing
        Me.UcGridLookUpEdit3.MyTag01 = Nothing
        Me.UcGridLookUpEdit3.MyTag02 = Nothing
        Me.UcGridLookUpEdit3.MyTag03 = Nothing
        Me.UcGridLookUpEdit3.MyTextControl = Nothing
        Me.UcGridLookUpEdit3.Name = "UcGridLookUpEdit3"
        Me.UcGridLookUpEdit3.Properties.AllowNoSourceText = True
        Me.UcGridLookUpEdit3.Properties.AllowNULL = True
        Me.UcGridLookUpEdit3.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit3.Properties.Appearance.Options.UseFont = True
        Me.UcGridLookUpEdit3.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.UcGridLookUpEdit3.Properties.ColumnWidths = Nothing
        Me.UcGridLookUpEdit3.Properties.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit3.Properties.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit3.Properties.EditValue = Nothing
        Me.UcGridLookUpEdit3.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit3.Properties.HasFilterRow = True
        Me.UcGridLookUpEdit3.Properties.IsChange = False
        Me.UcGridLookUpEdit3.Properties.MyAutoFormat = False
        Me.UcGridLookUpEdit3.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit3.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit3.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit3.Properties.MyTextControl = Nothing
        Me.UcGridLookUpEdit3.Properties.View = Me.GridView2
        Me.UcGridLookUpEdit3.Size = New System.Drawing.Size(132, 21)
        Me.UcGridLookUpEdit3.TabIndex = 15
        '
        'GridView2
        '
        Me.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView2.Name = "GridView2"
        Me.GridView2.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView2.OptionsView.ShowGroupPanel = False
        '
        'UcGridLookUpEdit4
        '
        Me.UcGridLookUpEdit4.AllowNoSourceText = True
        Me.UcGridLookUpEdit4.AllowNULL = True
        Me.UcGridLookUpEdit4.ColumnWidths = Nothing
        Me.UcGridLookUpEdit4.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit4.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit4.ForceRelateControlOnLeave = True
        Me.UcGridLookUpEdit4.HasFilterRow = True
        Me.UcGridLookUpEdit4.IsChange = False
        Me.UcGridLookUpEdit4.IsFirstInPair = False
        Me.UcGridLookUpEdit4.Location = New System.Drawing.Point(496, 36)
        Me.UcGridLookUpEdit4.MyAutoFormat = False
        Me.UcGridLookUpEdit4.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit4.MyDataType = HTLFW.eValidDataRange.StringType
        Me.UcGridLookUpEdit4.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit4.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit4.MyRelateControl = Nothing
        Me.UcGridLookUpEdit4.MyTag01 = Nothing
        Me.UcGridLookUpEdit4.MyTag02 = Nothing
        Me.UcGridLookUpEdit4.MyTag03 = Nothing
        Me.UcGridLookUpEdit4.MyTextControl = Nothing
        Me.UcGridLookUpEdit4.Name = "UcGridLookUpEdit4"
        Me.UcGridLookUpEdit4.Properties.AllowNoSourceText = True
        Me.UcGridLookUpEdit4.Properties.AllowNULL = True
        Me.UcGridLookUpEdit4.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.Appearance.Options.UseFont = True
        Me.UcGridLookUpEdit4.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.UcGridLookUpEdit4.Properties.ColumnWidths = Nothing
        Me.UcGridLookUpEdit4.Properties.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit4.Properties.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit4.Properties.EditValue = Nothing
        Me.UcGridLookUpEdit4.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.HasFilterRow = True
        Me.UcGridLookUpEdit4.Properties.IsChange = False
        Me.UcGridLookUpEdit4.Properties.MyAutoFormat = False
        Me.UcGridLookUpEdit4.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit4.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit4.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit4.Properties.MyTextControl = Nothing
        Me.UcGridLookUpEdit4.Properties.View = Me.GridView3
        Me.UcGridLookUpEdit4.Size = New System.Drawing.Size(132, 21)
        Me.UcGridLookUpEdit4.TabIndex = 14
        '
        'GridView3
        '
        Me.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView3.Name = "GridView3"
        Me.GridView3.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView3.OptionsView.ShowGroupPanel = False
        '
        'Label6
        '
        Me.Label6.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label6.AutoSetTextToToolTip = False
        Me.Label6.Location = New System.Drawing.Point(634, 39)
        Me.Label6.MyNextControl = Me.txtPeriod
        Me.Label6.MyTag01 = Nothing
        Me.Label6.MyTag02 = Nothing
        Me.Label6.MyTag03 = Nothing
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(23, 15)
        Me.Label6.TabIndex = 13
        Me.Label6.TagEN = Nothing
        Me.Label6.Text = "Đến"
        '
        'Label7
        '
        Me.Label7.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label7.AutoSetTextToToolTip = False
        Me.Label7.Location = New System.Drawing.Point(460, 39)
        Me.Label7.MyNextControl = Me.txtPeriod
        Me.Label7.MyTag01 = Nothing
        Me.Label7.MyTag02 = Nothing
        Me.Label7.MyTag03 = Nothing
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(22, 15)
        Me.Label7.TabIndex = 12
        Me.Label7.TagEN = Nothing
        Me.Label7.Text = "Kho"
        '
        'UcGridControl1
        '
        Me.UcGridControl1.AllowCommandDelete = True
        Me.UcGridControl1.AllowCommandModify = True
        Me.UcGridControl1.AllowCommandView = True
        Me.UcGridControl1.AllowContextMenu = True
        Me.UcGridControl1.AutoFocusToNewRow = False
        Me.UcGridControl1.EnableCommandDelete = True
        Me.UcGridControl1.EnableCommandModify = True
        Me.UcGridControl1.EnableCommandView = True
        Me.UcGridControl1.Location = New System.Drawing.Point(0, 73)
        Me.UcGridControl1.MainView = Me.GridView4
        Me.UcGridControl1.MyAutoFormat = False
        Me.UcGridControl1.MyBoldFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridControl1.MyColorStyle = HTLFW.UCGridControl.eColorStyle.Custom
        Me.UcGridControl1.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridControl1.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridControl1.MyItalicFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridControl1.MyMainView = Nothing
        Me.UcGridControl1.MyNewRowBackColor = System.Drawing.Color.LemonChiffon
        Me.UcGridControl1.MyNewRowForeColor = System.Drawing.Color.Black
        Me.UcGridControl1.MyNormalFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridControl1.MyOrdSource = HTLFW.UCGridControl.eOrdSource.RowHandle
        Me.UcGridControl1.MyShowDateCreatedColumn = False
        Me.UcGridControl1.MyShowDateModifiedColumn = False
        Me.UcGridControl1.MyShowDeleteCMD = False
        Me.UcGridControl1.MyShowModifyCMD = False
        Me.UcGridControl1.MyShowOrderColumn = False
        Me.UcGridControl1.MyShowUserCreatedColumn = False
        Me.UcGridControl1.MyShowUserModifiedColumn = False
        Me.UcGridControl1.MyShowViewCMD = False
        Me.UcGridControl1.MyViewType = HTLFW.UCGridControl.eViewType.Custom
        Me.UcGridControl1.Name = "UcGridControl1"
        Me.UcGridControl1.ShowFilterRow = False
        Me.UcGridControl1.ShowFooter = False
        Me.UcGridControl1.ShowGroupPanel = False
        Me.UcGridControl1.ShowNewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None
        Me.UcGridControl1.Size = New System.Drawing.Size(899, 322)
        Me.UcGridControl1.TabIndex = 16
        Me.UcGridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView4})
        '
        'GridView4
        '
        Me.GridView4.GridControl = Me.UcGridControl1
        Me.GridView4.Name = "GridView4"
        '
        'UcButton1
        '
        Me.UcButton1.Image = Global.Test.My.Resources.Resources.CMD_RELOAD01
        Me.UcButton1.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter
        Me.UcButton1.Location = New System.Drawing.Point(804, 9)
        Me.UcButton1.Name = "UcButton1"
        Me.UcButton1.Size = New System.Drawing.Size(75, 48)
        Me.UcButton1.TabIndex = 18
        Me.UcButton1.Text = "Lấy dữ liệu"
        '
        'UcButton2
        '
        Me.UcButton2.Image = Global.Test.My.Resources.Resources.CMD_PREVIEW02
        Me.UcButton2.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft
        Me.UcButton2.Location = New System.Drawing.Point(804, 407)
        Me.UcButton2.Name = "UcButton2"
        Me.UcButton2.Size = New System.Drawing.Size(74, 29)
        Me.UcButton2.TabIndex = 19
        Me.UcButton2.Text = "Report"
        '
        'frmReport_NXT1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(898, 448)
        Me.Controls.Add(Me.UcButton2)
        Me.Controls.Add(Me.UcButton1)
        Me.Controls.Add(Me.UcGridControl1)
        Me.Controls.Add(Me.UcGridLookUpEdit3)
        Me.Controls.Add(Me.UcGridLookUpEdit4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.UcGridLookUpEdit2)
        Me.Controls.Add(Me.UcGridLookUpEdit1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtDateTo)
        Me.Controls.Add(Me.txtDateFrom)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtPeriod)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmReport_NXT1"
        Me.HelpProvider.SetShowHelp(Me, False)
        Me.Text = "frmReport_NXT1"
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPeriod.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDateFrom.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDateTo.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit2.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit3.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit4.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPeriod As HTLFW.TextEditPeriod
    Friend WithEvents Label1 As HTLFW.Label
    Friend WithEvents Label2 As HTLFW.Label
    Friend WithEvents Label3 As HTLFW.Label
    Friend WithEvents txtDateFrom As HTLFW.TextEditPeriod
    Friend WithEvents txtDateTo As HTLFW.TextEditPeriod
    Friend WithEvents Label4 As HTLFW.Label
    Friend WithEvents Label5 As HTLFW.Label
    Friend WithEvents UcGridLookUpEdit1 As HTLFW.UCGridLookUpEdit
    Friend WithEvents UcGridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents UcGridLookUpEdit2 As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents UcGridLookUpEdit3 As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents UcGridLookUpEdit4 As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Label6 As HTLFW.Label
    Friend WithEvents Label7 As HTLFW.Label
    Friend WithEvents UcGridControl1 As HTLFW.UCGridControl
    Friend WithEvents GridView4 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents UcButton1 As HTLFW.UCButton
    Friend WithEvents UcButton2 As HTLFW.UCButton
End Class
