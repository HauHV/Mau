﻿'#Region "Refs"

'Imports HTLFW
'Imports HTLFW.HTLLib
'Imports HTLFW.HTLLib.HTLComFuncs
'Imports HTLFW.HTLLib.HTLLayoutDefinition
'Imports HTLFW.HTLLib.HTLStringFuncs

'#End Region

'Public Class frmReport_NXT1
'#Region "Declares"

'    Private IsRunning As Boolean = False
'    Private tblData As DataTable

'#End Region

'#Region "Constructors"

'    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
'        txtPeriod.PeriodString = KyHienHanh()
'        txtDateFrom.EditValue = NgayBatDauKyHienHanh()
'        txtDateTo.EditValue = NgayKetThucKyHienHanh()
'        MyBase.OnLoad(e)
'    End Sub

'    Private Sub Me_KeyCodePressed(ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyCodePressed
'        If e.Control AndAlso Not e.Alt AndAlso Not e.Shift AndAlso e.KeyCode = Windows.Forms.Keys.O Then
'            cmdDetail.PerformClick()
'        ElseIf e.Control AndAlso Not e.Alt AndAlso e.Shift AndAlso e.KeyCode = Windows.Forms.Keys.E Then
'            cmdExcel.PerformClick()
'        End If
'    End Sub

'    Private Sub Me_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
'        AddKeyCodeRegister(KeyInfor.eControlShiftAlt.Control + KeyInfor.eControlShiftAlt.Shift, Windows.Forms.Keys.E)
'        AddKeyCodeRegister(KeyInfor.eControlShiftAlt.Control, Windows.Forms.Keys.O)
'        RefreshColumns()
'        RefreshData()
'        FirstLoad = False
'        UcHRConditionPicker_ForListData1.AvaliabeCondition_MyGroup = DBs.SystemValues.USING_Group
'    End Sub

'    Private Sub Me_KeyF5Pressed(ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyF5Pressed
'        RefreshData()
'    End Sub

'    Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
'        tblData.Release()
'        ReleaseMemory()
'    End Sub

'#End Region

'#Region "Funtions"

'#End Region

'End Class