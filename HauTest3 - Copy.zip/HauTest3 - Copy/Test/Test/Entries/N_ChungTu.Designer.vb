﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class N_ChungTu
    Inherits AppRoot.frmBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.components = New System.ComponentModel.Container
        Me.components = New System.ComponentModel.Container
        Me.components = New System.ComponentModel.Container
        Me.components = New System.ComponentModel.Container
        Me.gcData = New HTLFW.UCGridControl
        Me.gvData = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColSoChungTu = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColLoaiChungTu = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColNgayLap = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColMaKH = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColMaKho = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColMaKhoNhan = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColMaKhoChuyen = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColGhiChu = New DevExpress.XtraGrid.Columns.GridColumn
        Me.SoChungTu = New HTLFW.UCTextEdit
        Me.MaKH = New HTLFW.UCGridLookUpEdit
        Me.UcGridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.Label1 = New HTLFW.Label
        Me.Label2 = New HTLFW.Label
        Me.Label3 = New HTLFW.Label
        Me.Label4 = New HTLFW.Label
        Me.Label5 = New HTLFW.Label
        Me.MaKhoChuyen = New HTLFW.Label
        Me.Label7 = New HTLFW.Label
        Me.NgayLap = New HTLFW.UCTextEdit
        Me.MaKho = New HTLFW.UCGridLookUpEdit
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.MaKhoNhan = New HTLFW.UCGridLookUpEdit
        Me.GridView3 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.UcGridLookUpEdit4 = New HTLFW.UCGridLookUpEdit
        Me.GridView4 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.GhiChu = New HTLFW.UCTextEdit
        Me.Xem = New HTLFW.UCButton
        Me.Them = New HTLFW.UCButton
        Me.Xoa = New HTLFW.UCButton
        Me.Sua = New HTLFW.UCButton
        Me.Dong = New HTLFW.UCButton
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gcData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SoChungTu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NgayLap.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKhoNhan.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit4.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GhiChu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gcData
        '
        Me.gcData.AllowCommandDelete = True
        Me.gcData.AllowCommandModify = True
        Me.gcData.AllowCommandView = True
        Me.gcData.AllowContextMenu = True
        Me.gcData.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gcData.AutoFocusToNewRow = False
        Me.gcData.EnableCommandDelete = True
        Me.gcData.EnableCommandModify = True
        Me.gcData.EnableCommandView = True
        Me.gcData.Location = New System.Drawing.Point(0, 104)
        Me.gcData.MainView = Me.gvData
        Me.gcData.MyAutoFormat = False
        Me.gcData.MyBoldFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyColorStyle = HTLFW.UCGridControl.eColorStyle.iSale
        Me.gcData.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gcData.MyFocusForeColor = System.Drawing.Color.Black
        Me.gcData.MyItalicFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyMainView = Nothing
        Me.gcData.MyNewRowBackColor = System.Drawing.Color.LemonChiffon
        Me.gcData.MyNewRowForeColor = System.Drawing.Color.Black
        Me.gcData.MyNormalFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyOrdSource = HTLFW.UCGridControl.eOrdSource.RowHandle
        Me.gcData.MyShowDateCreatedColumn = False
        Me.gcData.MyShowDateModifiedColumn = False
        Me.gcData.MyShowDeleteCMD = False
        Me.gcData.MyShowModifyCMD = False
        Me.gcData.MyShowOrderColumn = False
        Me.gcData.MyShowUserCreatedColumn = False
        Me.gcData.MyShowUserModifiedColumn = False
        Me.gcData.MyShowViewCMD = False
        Me.gcData.MyViewType = HTLFW.UCGridControl.eViewType.Custom
        Me.gcData.Name = "gcData"
        Me.gcData.ShowFilterRow = False
        Me.gcData.ShowFooter = False
        Me.gcData.ShowGroupPanel = False
        Me.gcData.ShowNewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None
        Me.gcData.Size = New System.Drawing.Size(852, 311)
        Me.gcData.TabIndex = 0
        Me.gcData.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.gvData})
        '
        'gvData
        '
        Me.gvData.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.gvData.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.gvData.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.gvData.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.DetailTip.Options.UseFont = True
        Me.gvData.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.Empty.Options.UseFont = True
        Me.gvData.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.EvenRow.Options.UseFont = True
        Me.gvData.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FilterCloseButton.Options.UseFont = True
        Me.gvData.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FilterPanel.Options.UseFont = True
        Me.gvData.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FixedLine.Options.UseFont = True
        Me.gvData.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.gvData.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.FocusedCell.Options.UseBackColor = True
        Me.gvData.Appearance.FocusedCell.Options.UseForeColor = True
        Me.gvData.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.FocusedRow.Options.UseBackColor = True
        Me.gvData.Appearance.FocusedRow.Options.UseForeColor = True
        Me.gvData.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FooterPanel.Options.UseFont = True
        Me.gvData.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupButton.Options.UseFont = True
        Me.gvData.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupFooter.Options.UseFont = True
        Me.gvData.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupPanel.Options.UseFont = True
        Me.gvData.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupRow.Options.UseFont = True
        Me.gvData.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.HeaderPanel.Options.UseFont = True
        Me.gvData.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.gvData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.gvData.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.gvData.Appearance.HideSelectionRow.Options.UseFont = True
        Me.gvData.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.gvData.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.HorzLine.Options.UseFont = True
        Me.gvData.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.OddRow.Options.UseFont = True
        Me.gvData.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.Preview.Options.UseFont = True
        Me.gvData.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.Row.Options.UseFont = True
        Me.gvData.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.RowSeparator.Options.UseFont = True
        Me.gvData.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.SelectedRow.Options.UseBackColor = True
        Me.gvData.Appearance.SelectedRow.Options.UseFont = True
        Me.gvData.Appearance.SelectedRow.Options.UseForeColor = True
        Me.gvData.Appearance.TopNewRow.BackColor = System.Drawing.Color.LemonChiffon
        Me.gvData.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.TopNewRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.TopNewRow.Options.UseBackColor = True
        Me.gvData.Appearance.TopNewRow.Options.UseFont = True
        Me.gvData.Appearance.TopNewRow.Options.UseForeColor = True
        Me.gvData.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.VertLine.Options.UseFont = True
        Me.gvData.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.ViewCaption.Options.UseFont = True
        Me.gvData.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColSoChungTu, Me.grdColLoaiChungTu, Me.grdColNgayLap, Me.grdColMaKH, Me.grdColMaKho, Me.grdColMaKhoNhan, Me.grdColMaKhoChuyen, Me.grdColGhiChu})
        Me.gvData.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.gvData.GridControl = Me.gcData
        Me.gvData.Name = "gvData"
        Me.gvData.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.[False]
        Me.gvData.OptionsBehavior.AllowIncrementalSearch = True
        Me.gvData.OptionsBehavior.AutoExpandAllGroups = True
        Me.gvData.OptionsBehavior.AutoPopulateColumns = False
        Me.gvData.OptionsBehavior.FocusLeaveOnTab = True
        Me.gvData.OptionsCustomization.AllowQuickHideColumns = False
        Me.gvData.OptionsNavigation.AutoFocusNewRow = True
        Me.gvData.OptionsNavigation.EnterMoveNextColumn = True
        Me.gvData.OptionsPrint.AutoWidth = False
        Me.gvData.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.gvData.OptionsView.EnableAppearanceEvenRow = True
        '
        'grdColSoChungTu
        '
        Me.grdColSoChungTu.Caption = "SoChungTu"
        Me.grdColSoChungTu.FieldName = "SoChungTu"
        Me.grdColSoChungTu.Name = "grdColSoChungTu"
        Me.grdColSoChungTu.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColSoChungTu.Visible = True
        Me.grdColSoChungTu.VisibleIndex = 0
        '
        'grdColLoaiChungTu
        '
        Me.grdColLoaiChungTu.Caption = "LoaiChungTu"
        Me.grdColLoaiChungTu.FieldName = "LoaiChungTu"
        Me.grdColLoaiChungTu.Name = "grdColLoaiChungTu"
        Me.grdColLoaiChungTu.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColLoaiChungTu.Visible = True
        Me.grdColLoaiChungTu.VisibleIndex = 1
        '
        'grdColNgayLap
        '
        Me.grdColNgayLap.Caption = "NgayLap"
        Me.grdColNgayLap.FieldName = "NgayLap"
        Me.grdColNgayLap.Name = "grdColNgayLap"
        Me.grdColNgayLap.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColNgayLap.Visible = True
        Me.grdColNgayLap.VisibleIndex = 2
        '
        'grdColMaKH
        '
        Me.grdColMaKH.Caption = "MaKH"
        Me.grdColMaKH.FieldName = "MaKH"
        Me.grdColMaKH.Name = "grdColMaKH"
        Me.grdColMaKH.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaKH.Visible = True
        Me.grdColMaKH.VisibleIndex = 3
        '
        'grdColMaKho
        '
        Me.grdColMaKho.Caption = "MaKho"
        Me.grdColMaKho.FieldName = "MaKho"
        Me.grdColMaKho.Name = "grdColMaKho"
        Me.grdColMaKho.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaKho.Visible = True
        Me.grdColMaKho.VisibleIndex = 4
        '
        'grdColMaKhoNhan
        '
        Me.grdColMaKhoNhan.Caption = "MaKhoNhan"
        Me.grdColMaKhoNhan.FieldName = "MaKhoNhan"
        Me.grdColMaKhoNhan.Name = "grdColMaKhoNhan"
        Me.grdColMaKhoNhan.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaKhoNhan.Visible = True
        Me.grdColMaKhoNhan.VisibleIndex = 5
        '
        'grdColMaKhoChuyen
        '
        Me.grdColMaKhoChuyen.Caption = "MaKhoChuyen"
        Me.grdColMaKhoChuyen.FieldName = "MaKhoChuyen"
        Me.grdColMaKhoChuyen.Name = "grdColMaKhoChuyen"
        Me.grdColMaKhoChuyen.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaKhoChuyen.Visible = True
        Me.grdColMaKhoChuyen.VisibleIndex = 6
        '
        'grdColGhiChu
        '
        Me.grdColGhiChu.Caption = "GhiChu"
        Me.grdColGhiChu.FieldName = "GhiChu"
        Me.grdColGhiChu.Name = "grdColGhiChu"
        Me.grdColGhiChu.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColGhiChu.Visible = True
        Me.grdColGhiChu.VisibleIndex = 7
        '
        'SoChungTu
        '
        Me.SoChungTu.ForceRelateControlOnLeave = True
        Me.SoChungTu.IsFirstInPair = False
        Me.SoChungTu.Location = New System.Drawing.Point(89, 12)
        Me.SoChungTu.MyAutoFormat = False
        Me.SoChungTu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.SoChungTu.MyMaxLength = 0
        Me.SoChungTu.MyRelateControl = Nothing
        Me.SoChungTu.MyTag01 = Nothing
        Me.SoChungTu.MyTag02 = Nothing
        Me.SoChungTu.MyTag03 = Nothing
        Me.SoChungTu.Name = "SoChungTu"
        Me.SoChungTu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.Appearance.Options.UseFont = True
        Me.SoChungTu.Properties.EditValue = Nothing
        Me.SoChungTu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.MyAutoFormat = False
        Me.SoChungTu.Size = New System.Drawing.Size(214, 21)
        Me.SoChungTu.TabIndex = 1
        '
        'MaKH
        '
        Me.MaKH.AllowNoSourceText = True
        Me.MaKH.AllowNULL = True
        Me.MaKH.ColumnWidths = Nothing
        Me.MaKH.CreateDefaultColCodeColumn = False
        Me.MaKH.CreateDefaultColNameColumn = False
        Me.MaKH.EnterMoveNextControl = True
        Me.MaKH.ForceRelateControlOnLeave = True
        Me.MaKH.HasFilterRow = True
        Me.MaKH.IsChange = False
        Me.MaKH.IsFirstInPair = False
        Me.MaKH.Location = New System.Drawing.Point(353, 12)
        Me.MaKH.MyAutoFormat = False
        Me.MaKH.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKH.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKH.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKH.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKH.MyRelateControl = Nothing
        Me.MaKH.MyTag01 = Nothing
        Me.MaKH.MyTag02 = Nothing
        Me.MaKH.MyTag03 = Nothing
        Me.MaKH.MyTextControl = Nothing
        Me.MaKH.Name = "MaKH"
        Me.MaKH.Properties.AllowNoSourceText = True
        Me.MaKH.Properties.AllowNULL = True
        Me.MaKH.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKH.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.Appearance.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKH.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKH.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKH.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKH.Properties.ColumnWidths = Nothing
        Me.MaKH.Properties.CreateDefaultColCodeColumn = False
        Me.MaKH.Properties.CreateDefaultColNameColumn = False
        Me.MaKH.Properties.EditValue = Nothing
        Me.MaKH.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.HasFilterRow = True
        Me.MaKH.Properties.IsChange = False
        Me.MaKH.Properties.MyAutoFormat = False
        Me.MaKH.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKH.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKH.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKH.Properties.MyTextControl = Nothing
        Me.MaKH.Properties.NullText = ""
        Me.MaKH.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKH.Properties.PopupSizeable = False
        Me.MaKH.Properties.ShowFooter = False
        Me.MaKH.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKH.Properties.ValidateOnEnterKey = True
        Me.MaKH.Properties.View = Me.UcGridLookUpEdit1View
        Me.MaKH.Size = New System.Drawing.Size(214, 21)
        Me.MaKH.TabIndex = 2
        '
        'UcGridLookUpEdit1View
        '
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.DetailTip.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Empty.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.EvenRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FilterCloseButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FilterPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FixedLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FocusedCell.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FooterPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupFooter.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HorzLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.OddRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Preview.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Row.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.RowSeparator.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.TopNewRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.VertLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ViewCaption.Options.UseFont = True
        Me.UcGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.UcGridLookUpEdit1View.Name = "UcGridLookUpEdit1View"
        Me.UcGridLookUpEdit1View.OptionsBehavior.Editable = False
        Me.UcGridLookUpEdit1View.OptionsBehavior.ReadOnly = True
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowColumnMoving = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowColumnResizing = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowGroup = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowQuickHideColumns = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableColumnMenu = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableFooterMenu = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableGroupPanelMenu = False
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceHideSelection = False
        Me.UcGridLookUpEdit1View.OptionsView.ColumnAutoWidth = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowAutoFilterRow = True
        Me.UcGridLookUpEdit1View.OptionsView.ShowColumnHeaders = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowIndicator = False
        '
        'Label1
        '
        Me.Label1.AllowHtmlString = True
        Me.Label1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label1.AutoSetTextToToolTip = False
        Me.Label1.Location = New System.Drawing.Point(14, 12)
        Me.Label1.MyNextControl = Nothing
        Me.Label1.MyTag01 = Nothing
        Me.Label1.MyTag02 = Nothing
        Me.Label1.MyTag03 = Nothing
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.TagEN = Nothing
        Me.Label1.Text = "SoChungTu<b><Color=Red>*</Color></b>"
        '
        'Label2
        '
        Me.Label2.AllowHtmlString = True
        Me.Label2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label2.AutoSetTextToToolTip = False
        Me.Label2.Location = New System.Drawing.Point(309, 12)
        Me.Label2.MyNextControl = Nothing
        Me.Label2.MyTag01 = Nothing
        Me.Label2.MyTag02 = Nothing
        Me.Label2.MyTag03 = Nothing
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 15)
        Me.Label2.TabIndex = 4
        Me.Label2.TagEN = Nothing
        Me.Label2.Text = "MaKH<b><Color=Red>*</Color></b>"
        '
        'Label3
        '
        Me.Label3.AllowHtmlString = True
        Me.Label3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label3.AutoSetTextToToolTip = False
        Me.Label3.Location = New System.Drawing.Point(573, 12)
        Me.Label3.MyNextControl = Nothing
        Me.Label3.MyTag01 = Nothing
        Me.Label3.MyTag02 = Nothing
        Me.Label3.MyTag03 = Nothing
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.TagEN = Nothing
        Me.Label3.Text = "NgayLap<b><Color=Red>*</Color></b>"
        '
        'Label4
        '
        Me.Label4.AllowHtmlString = True
        Me.Label4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label4.AutoSetTextToToolTip = False
        Me.Label4.Location = New System.Drawing.Point(42, 44)
        Me.Label4.MyNextControl = Nothing
        Me.Label4.MyTag01 = Nothing
        Me.Label4.MyTag02 = Nothing
        Me.Label4.MyTag03 = Nothing
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.TagEN = Nothing
        Me.Label4.Text = "MaKho<b><Color=Red>*</Color></b>"
        '
        'Label5
        '
        Me.Label5.AllowHtmlString = True
        Me.Label5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label5.AutoSetTextToToolTip = False
        Me.Label5.Location = New System.Drawing.Point(309, 44)
        Me.Label5.MyNextControl = Nothing
        Me.Label5.MyTag01 = Nothing
        Me.Label5.MyTag02 = Nothing
        Me.Label5.MyTag03 = Nothing
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.TagEN = Nothing
        Me.Label5.Text = "MaKhoNhan<b><Color=Red>*</Color></b>"
        '
        'MaKhoChuyen
        '
        Me.MaKhoChuyen.AllowHtmlString = True
        Me.MaKhoChuyen.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.AutoSetTextToToolTip = False
        Me.MaKhoChuyen.Location = New System.Drawing.Point(573, 44)
        Me.MaKhoChuyen.MyNextControl = Nothing
        Me.MaKhoChuyen.MyTag01 = Nothing
        Me.MaKhoChuyen.MyTag02 = Nothing
        Me.MaKhoChuyen.MyTag03 = Nothing
        Me.MaKhoChuyen.Name = "MaKhoChuyen"
        Me.MaKhoChuyen.Size = New System.Drawing.Size(85, 15)
        Me.MaKhoChuyen.TabIndex = 8
        Me.MaKhoChuyen.TagEN = Nothing
        Me.MaKhoChuyen.Text = "MaKhoChuyen<b><Color=Red>*</Color></b>"
        '
        'Label7
        '
        Me.Label7.AllowHtmlString = True
        Me.Label7.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label7.AutoSetTextToToolTip = False
        Me.Label7.Location = New System.Drawing.Point(46, 77)
        Me.Label7.MyNextControl = Nothing
        Me.Label7.MyTag01 = Nothing
        Me.Label7.MyTag02 = Nothing
        Me.Label7.MyTag03 = Nothing
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 15)
        Me.Label7.TabIndex = 9
        Me.Label7.TagEN = Nothing
        Me.Label7.Text = "Ghichu"
        '
        'NgayLap
        '
        Me.NgayLap.ForceRelateControlOnLeave = True
        Me.NgayLap.IsFirstInPair = False
        Me.NgayLap.Location = New System.Drawing.Point(633, 12)
        Me.NgayLap.MyAutoFormat = False
        Me.NgayLap.MyDataType = HTLFW.eValidDataRange.StringType
        Me.NgayLap.MyMaxLength = 0
        Me.NgayLap.MyRelateControl = Nothing
        Me.NgayLap.MyTag01 = Nothing
        Me.NgayLap.MyTag02 = Nothing
        Me.NgayLap.MyTag03 = Nothing
        Me.NgayLap.Name = "NgayLap"
        Me.NgayLap.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.Appearance.Options.UseFont = True
        Me.NgayLap.Properties.DisplayFormat.FormatString = "dd/MM/yyyy"
        Me.NgayLap.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.NgayLap.Properties.EditFormat.FormatString = "dd/MM/yyyy"
        Me.NgayLap.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.NgayLap.Properties.EditValue = Nothing
        Me.NgayLap.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.MyAutoFormat = False
        Me.NgayLap.Size = New System.Drawing.Size(207, 21)
        Me.NgayLap.TabIndex = 11
        '
        'MaKho
        '
        Me.MaKho.AllowNoSourceText = True
        Me.MaKho.AllowNULL = True
        Me.MaKho.ColumnWidths = Nothing
        Me.MaKho.CreateDefaultColCodeColumn = False
        Me.MaKho.CreateDefaultColNameColumn = False
        Me.MaKho.EnterMoveNextControl = True
        Me.MaKho.ForceRelateControlOnLeave = True
        Me.MaKho.HasFilterRow = True
        Me.MaKho.IsChange = False
        Me.MaKho.IsFirstInPair = False
        Me.MaKho.Location = New System.Drawing.Point(89, 44)
        Me.MaKho.MyAutoFormat = False
        Me.MaKho.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKho.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKho.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKho.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKho.MyRelateControl = Nothing
        Me.MaKho.MyTag01 = Nothing
        Me.MaKho.MyTag02 = Nothing
        Me.MaKho.MyTag03 = Nothing
        Me.MaKho.MyTextControl = Nothing
        Me.MaKho.Name = "MaKho"
        Me.MaKho.Properties.AllowNoSourceText = True
        Me.MaKho.Properties.AllowNULL = True
        Me.MaKho.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKho.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.Appearance.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKho.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKho.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKho.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKho.Properties.ColumnWidths = Nothing
        Me.MaKho.Properties.CreateDefaultColCodeColumn = False
        Me.MaKho.Properties.CreateDefaultColNameColumn = False
        Me.MaKho.Properties.EditValue = Nothing
        Me.MaKho.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.HasFilterRow = True
        Me.MaKho.Properties.IsChange = False
        Me.MaKho.Properties.MyAutoFormat = False
        Me.MaKho.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKho.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKho.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKho.Properties.MyTextControl = Nothing
        Me.MaKho.Properties.NullText = ""
        Me.MaKho.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKho.Properties.PopupSizeable = False
        Me.MaKho.Properties.ShowFooter = False
        Me.MaKho.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKho.Properties.ValidateOnEnterKey = True
        Me.MaKho.Properties.View = Me.GridView2
        Me.MaKho.Size = New System.Drawing.Size(214, 21)
        Me.MaKho.TabIndex = 15
        '
        'GridView2
        '
        Me.GridView2.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView2.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView2.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView2.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.DetailTip.Options.UseFont = True
        Me.GridView2.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.Empty.Options.UseFont = True
        Me.GridView2.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.EvenRow.Options.UseFont = True
        Me.GridView2.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView2.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView2.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FixedLine.Options.UseFont = True
        Me.GridView2.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView2.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView2.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView2.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView2.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView2.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView2.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupButton.Options.UseFont = True
        Me.GridView2.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView2.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView2.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupRow.Options.UseFont = True
        Me.GridView2.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView2.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView2.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView2.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView2.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView2.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView2.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView2.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.HorzLine.Options.UseFont = True
        Me.GridView2.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.OddRow.Options.UseFont = True
        Me.GridView2.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.Preview.Options.UseFont = True
        Me.GridView2.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.Row.Options.UseFont = True
        Me.GridView2.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView2.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView2.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView2.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView2.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView2.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView2.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.VertLine.Options.UseFont = True
        Me.GridView2.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView2.Name = "GridView2"
        Me.GridView2.OptionsBehavior.Editable = False
        Me.GridView2.OptionsBehavior.ReadOnly = True
        Me.GridView2.OptionsCustomization.AllowColumnMoving = False
        Me.GridView2.OptionsCustomization.AllowColumnResizing = False
        Me.GridView2.OptionsCustomization.AllowGroup = False
        Me.GridView2.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView2.OptionsMenu.EnableColumnMenu = False
        Me.GridView2.OptionsMenu.EnableFooterMenu = False
        Me.GridView2.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView2.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView2.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView2.OptionsView.ColumnAutoWidth = False
        Me.GridView2.OptionsView.ShowAutoFilterRow = True
        Me.GridView2.OptionsView.ShowColumnHeaders = False
        Me.GridView2.OptionsView.ShowGroupPanel = False
        Me.GridView2.OptionsView.ShowIndicator = False
        '
        'MaKhoNhan
        '
        Me.MaKhoNhan.AllowNoSourceText = True
        Me.MaKhoNhan.AllowNULL = True
        Me.MaKhoNhan.ColumnWidths = Nothing
        Me.MaKhoNhan.CreateDefaultColCodeColumn = False
        Me.MaKhoNhan.CreateDefaultColNameColumn = False
        Me.MaKhoNhan.EnterMoveNextControl = True
        Me.MaKhoNhan.ForceRelateControlOnLeave = True
        Me.MaKhoNhan.HasFilterRow = True
        Me.MaKhoNhan.IsChange = False
        Me.MaKhoNhan.IsFirstInPair = False
        Me.MaKhoNhan.Location = New System.Drawing.Point(388, 44)
        Me.MaKhoNhan.MyAutoFormat = False
        Me.MaKhoNhan.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKhoNhan.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKhoNhan.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKhoNhan.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKhoNhan.MyRelateControl = Nothing
        Me.MaKhoNhan.MyTag01 = Nothing
        Me.MaKhoNhan.MyTag02 = Nothing
        Me.MaKhoNhan.MyTag03 = Nothing
        Me.MaKhoNhan.MyTextControl = Nothing
        Me.MaKhoNhan.Name = "MaKhoNhan"
        Me.MaKhoNhan.Properties.AllowNoSourceText = True
        Me.MaKhoNhan.Properties.AllowNULL = True
        Me.MaKhoNhan.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKhoNhan.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.Appearance.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKhoNhan.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKhoNhan.Properties.ColumnWidths = Nothing
        Me.MaKhoNhan.Properties.CreateDefaultColCodeColumn = False
        Me.MaKhoNhan.Properties.CreateDefaultColNameColumn = False
        Me.MaKhoNhan.Properties.EditValue = Nothing
        Me.MaKhoNhan.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.HasFilterRow = True
        Me.MaKhoNhan.Properties.IsChange = False
        Me.MaKhoNhan.Properties.MyAutoFormat = False
        Me.MaKhoNhan.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKhoNhan.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKhoNhan.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKhoNhan.Properties.MyTextControl = Nothing
        Me.MaKhoNhan.Properties.NullText = ""
        Me.MaKhoNhan.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKhoNhan.Properties.PopupSizeable = False
        Me.MaKhoNhan.Properties.ShowFooter = False
        Me.MaKhoNhan.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKhoNhan.Properties.ValidateOnEnterKey = True
        Me.MaKhoNhan.Properties.View = Me.GridView3
        Me.MaKhoNhan.Size = New System.Drawing.Size(179, 21)
        Me.MaKhoNhan.TabIndex = 16
        '
        'GridView3
        '
        Me.GridView3.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView3.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView3.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView3.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.DetailTip.Options.UseFont = True
        Me.GridView3.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.Empty.Options.UseFont = True
        Me.GridView3.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.EvenRow.Options.UseFont = True
        Me.GridView3.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView3.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView3.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FixedLine.Options.UseFont = True
        Me.GridView3.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView3.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView3.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView3.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView3.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView3.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView3.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupButton.Options.UseFont = True
        Me.GridView3.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView3.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView3.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupRow.Options.UseFont = True
        Me.GridView3.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView3.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView3.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView3.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView3.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView3.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView3.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView3.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.HorzLine.Options.UseFont = True
        Me.GridView3.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.OddRow.Options.UseFont = True
        Me.GridView3.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.Preview.Options.UseFont = True
        Me.GridView3.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.Row.Options.UseFont = True
        Me.GridView3.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView3.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView3.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView3.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView3.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView3.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView3.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.VertLine.Options.UseFont = True
        Me.GridView3.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView3.Name = "GridView3"
        Me.GridView3.OptionsBehavior.Editable = False
        Me.GridView3.OptionsBehavior.ReadOnly = True
        Me.GridView3.OptionsCustomization.AllowColumnMoving = False
        Me.GridView3.OptionsCustomization.AllowColumnResizing = False
        Me.GridView3.OptionsCustomization.AllowGroup = False
        Me.GridView3.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView3.OptionsMenu.EnableColumnMenu = False
        Me.GridView3.OptionsMenu.EnableFooterMenu = False
        Me.GridView3.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView3.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView3.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView3.OptionsView.ColumnAutoWidth = False
        Me.GridView3.OptionsView.ShowAutoFilterRow = True
        Me.GridView3.OptionsView.ShowColumnHeaders = False
        Me.GridView3.OptionsView.ShowGroupPanel = False
        Me.GridView3.OptionsView.ShowIndicator = False
        '
        'UcGridLookUpEdit4
        '
        Me.UcGridLookUpEdit4.AllowNoSourceText = True
        Me.UcGridLookUpEdit4.AllowNULL = True
        Me.UcGridLookUpEdit4.ColumnWidths = Nothing
        Me.UcGridLookUpEdit4.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit4.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit4.EnterMoveNextControl = True
        Me.UcGridLookUpEdit4.ForceRelateControlOnLeave = True
        Me.UcGridLookUpEdit4.HasFilterRow = True
        Me.UcGridLookUpEdit4.IsChange = False
        Me.UcGridLookUpEdit4.IsFirstInPair = False
        Me.UcGridLookUpEdit4.Location = New System.Drawing.Point(664, 44)
        Me.UcGridLookUpEdit4.MyAutoFormat = False
        Me.UcGridLookUpEdit4.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.UcGridLookUpEdit4.MyDataType = HTLFW.eValidDataRange.StringType
        Me.UcGridLookUpEdit4.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit4.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit4.MyRelateControl = Nothing
        Me.UcGridLookUpEdit4.MyTag01 = Nothing
        Me.UcGridLookUpEdit4.MyTag02 = Nothing
        Me.UcGridLookUpEdit4.MyTag03 = Nothing
        Me.UcGridLookUpEdit4.MyTextControl = Nothing
        Me.UcGridLookUpEdit4.Name = "UcGridLookUpEdit4"
        Me.UcGridLookUpEdit4.Properties.AllowNoSourceText = True
        Me.UcGridLookUpEdit4.Properties.AllowNULL = True
        Me.UcGridLookUpEdit4.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.UcGridLookUpEdit4.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.Appearance.Options.UseFont = True
        Me.UcGridLookUpEdit4.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.AppearanceDisabled.Options.UseFont = True
        Me.UcGridLookUpEdit4.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.AppearanceDropDown.Options.UseFont = True
        Me.UcGridLookUpEdit4.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.AppearanceFocused.Options.UseFont = True
        Me.UcGridLookUpEdit4.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.UcGridLookUpEdit4.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.UcGridLookUpEdit4.Properties.ColumnWidths = Nothing
        Me.UcGridLookUpEdit4.Properties.CreateDefaultColCodeColumn = False
        Me.UcGridLookUpEdit4.Properties.CreateDefaultColNameColumn = False
        Me.UcGridLookUpEdit4.Properties.EditValue = Nothing
        Me.UcGridLookUpEdit4.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit4.Properties.HasFilterRow = True
        Me.UcGridLookUpEdit4.Properties.IsChange = False
        Me.UcGridLookUpEdit4.Properties.MyAutoFormat = False
        Me.UcGridLookUpEdit4.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.UcGridLookUpEdit4.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit4.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit4.Properties.MyTextControl = Nothing
        Me.UcGridLookUpEdit4.Properties.NullText = ""
        Me.UcGridLookUpEdit4.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.UcGridLookUpEdit4.Properties.PopupSizeable = False
        Me.UcGridLookUpEdit4.Properties.ShowFooter = False
        Me.UcGridLookUpEdit4.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.UcGridLookUpEdit4.Properties.ValidateOnEnterKey = True
        Me.UcGridLookUpEdit4.Properties.View = Me.GridView4
        Me.UcGridLookUpEdit4.Size = New System.Drawing.Size(176, 21)
        Me.UcGridLookUpEdit4.TabIndex = 17
        '
        'GridView4
        '
        Me.GridView4.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView4.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView4.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView4.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.DetailTip.Options.UseFont = True
        Me.GridView4.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.Empty.Options.UseFont = True
        Me.GridView4.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.EvenRow.Options.UseFont = True
        Me.GridView4.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView4.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView4.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FixedLine.Options.UseFont = True
        Me.GridView4.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView4.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView4.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView4.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView4.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView4.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupButton.Options.UseFont = True
        Me.GridView4.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView4.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView4.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupRow.Options.UseFont = True
        Me.GridView4.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView4.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView4.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView4.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView4.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView4.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView4.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.HorzLine.Options.UseFont = True
        Me.GridView4.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.OddRow.Options.UseFont = True
        Me.GridView4.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.Preview.Options.UseFont = True
        Me.GridView4.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.Row.Options.UseFont = True
        Me.GridView4.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView4.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView4.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView4.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView4.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView4.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.VertLine.Options.UseFont = True
        Me.GridView4.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView4.Name = "GridView4"
        Me.GridView4.OptionsBehavior.Editable = False
        Me.GridView4.OptionsBehavior.ReadOnly = True
        Me.GridView4.OptionsCustomization.AllowColumnMoving = False
        Me.GridView4.OptionsCustomization.AllowColumnResizing = False
        Me.GridView4.OptionsCustomization.AllowGroup = False
        Me.GridView4.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView4.OptionsMenu.EnableColumnMenu = False
        Me.GridView4.OptionsMenu.EnableFooterMenu = False
        Me.GridView4.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView4.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView4.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView4.OptionsView.ColumnAutoWidth = False
        Me.GridView4.OptionsView.ShowAutoFilterRow = True
        Me.GridView4.OptionsView.ShowColumnHeaders = False
        Me.GridView4.OptionsView.ShowGroupPanel = False
        Me.GridView4.OptionsView.ShowIndicator = False
        '
        'GhiChu
        '
        Me.GhiChu.ForceRelateControlOnLeave = True
        Me.GhiChu.IsFirstInPair = False
        Me.GhiChu.Location = New System.Drawing.Point(89, 77)
        Me.GhiChu.MyAutoFormat = False
        Me.GhiChu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.GhiChu.MyMaxLength = 0
        Me.GhiChu.MyRelateControl = Nothing
        Me.GhiChu.MyTag01 = Nothing
        Me.GhiChu.MyTag02 = Nothing
        Me.GhiChu.MyTag03 = Nothing
        Me.GhiChu.Name = "GhiChu"
        Me.GhiChu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GhiChu.Properties.Appearance.Options.UseFont = True
        Me.GhiChu.Properties.EditValue = Nothing
        Me.GhiChu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GhiChu.Properties.MyAutoFormat = False
        Me.GhiChu.Size = New System.Drawing.Size(478, 21)
        Me.GhiChu.TabIndex = 18
        '
        'Xem
        '
        Me.Xem.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Xem.Location = New System.Drawing.Point(441, 421)
        Me.Xem.Name = "Xem"
        Me.Xem.Size = New System.Drawing.Size(75, 23)
        Me.Xem.TabIndex = 19
        Me.Xem.Text = "Xem"
        '
        'Them
        '
        Me.Them.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Them.Location = New System.Drawing.Point(522, 421)
        Me.Them.Name = "Them"
        Me.Them.Size = New System.Drawing.Size(75, 23)
        Me.Them.TabIndex = 20
        Me.Them.Text = "Them"
        '
        'Xoa
        '
        Me.Xoa.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Xoa.Location = New System.Drawing.Point(603, 421)
        Me.Xoa.Name = "Xoa"
        Me.Xoa.Size = New System.Drawing.Size(75, 23)
        Me.Xoa.TabIndex = 21
        Me.Xoa.Text = "Xoa"
        '
        'Sua
        '
        Me.Sua.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Sua.Location = New System.Drawing.Point(684, 421)
        Me.Sua.Name = "Sua"
        Me.Sua.Size = New System.Drawing.Size(75, 23)
        Me.Sua.TabIndex = 22
        Me.Sua.Text = "Sua"
        '
        'Dong
        '
        Me.Dong.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dong.Location = New System.Drawing.Point(765, 421)
        Me.Dong.Name = "Dong"
        Me.Dong.Size = New System.Drawing.Size(75, 23)
        Me.Dong.TabIndex = 23
        Me.Dong.Text = "Dong"
        '
        'N_ChungTu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(852, 451)
        Me.Controls.Add(Me.Dong)
        Me.Controls.Add(Me.Sua)
        Me.Controls.Add(Me.Xoa)
        Me.Controls.Add(Me.Them)
        Me.Controls.Add(Me.Xem)
        Me.Controls.Add(Me.GhiChu)
        Me.Controls.Add(Me.UcGridLookUpEdit4)
        Me.Controls.Add(Me.MaKhoNhan)
        Me.Controls.Add(Me.MaKho)
        Me.Controls.Add(Me.NgayLap)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.MaKhoChuyen)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MaKH)
        Me.Controls.Add(Me.SoChungTu)
        Me.Controls.Add(Me.gcData)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "N_ChungTu"
        Me.HelpProvider.SetShowHelp(Me, False)
        Me.Text = "N_ChungTu"
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gcData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SoChungTu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NgayLap.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKhoNhan.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit4.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GhiChu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gcData As HTLFW.UCGridControl
    Friend WithEvents gvData As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents SoChungTu As HTLFW.UCTextEdit
    Friend WithEvents MaKH As HTLFW.UCGridLookUpEdit
    Friend WithEvents UcGridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Label1 As HTLFW.Label
    Friend WithEvents Label2 As HTLFW.Label
    Friend WithEvents Label3 As HTLFW.Label
    Friend WithEvents Label4 As HTLFW.Label
    Friend WithEvents Label5 As HTLFW.Label
    Friend WithEvents MaKhoChuyen As HTLFW.Label
    Friend WithEvents Label7 As HTLFW.Label
    Friend WithEvents NgayLap As HTLFW.UCTextEdit
    Friend WithEvents MaKho As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents MaKhoNhan As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents UcGridLookUpEdit4 As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView4 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GhiChu As HTLFW.UCTextEdit
    Friend WithEvents Xem As HTLFW.UCButton
    Friend WithEvents Them As HTLFW.UCButton
    Friend WithEvents Xoa As HTLFW.UCButton
    Friend WithEvents Sua As HTLFW.UCButton
    Friend WithEvents Dong As HTLFW.UCButton
    Friend WithEvents grdColSoChungTu As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColLoaiChungTu As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColNgayLap As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColMaKH As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColMaKho As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColMaKhoNhan As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColMaKhoChuyen As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColGhiChu As DevExpress.XtraGrid.Columns.GridColumn
End Class
