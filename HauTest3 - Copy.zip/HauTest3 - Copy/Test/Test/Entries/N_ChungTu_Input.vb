﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs

#End Region

Public Class N_ChungTu_Input

#Region "Declares"
    Enum eMyFormMode
        None
        Them
        Xem
        Sua
    End Enum
    Private tblDetailData As DataTable

    Private MyFormMode As eMyFormMode = eMyFormMode.None
    Private MySoChungTu As String
    Private MyLoaiChungTu As String


#End Region

#Region "Constructors"

    Public Sub New(ByVal pFormMode As eMyFormMode, ByVal pSoChungTu As String, ByVal pLoaiChungTu As String)
        InitializeComponent()
        MyFormMode = pFormMode
        MySoChungTu = pSoChungTu
        MyLoaiChungTu = pLoaiChungTu
    End Sub

    Private Sub N_ChungTu_Input_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Select Case MyFormMode
            Case eMyFormMode.Sua, eMyFormMode.Them
                cmdLuu.Visible = True
                cmdLuuNext.Visible = (MyFormMode = eMyFormMode.Them)
            Case Else
                cmdLuu.Visible = False
                cmdLuuNext.Visible = False
        End Select
        If MyFormMode = eMyFormMode.Xem Then
            SoChungTu.Properties.ReadOnly = True
            NgayLap.Properties.ReadOnly = True
            MaKH.Properties.ReadOnly = True
            MaKho.Properties.ReadOnly = True
        End If

        FillCombo_MaKH()
        FillCombo_MaKho()

        Select Case MyFormMode
            Case eMyFormMode.Sua, eMyFormMode.Xem

                Dim mCurrObject = DBContext.ChungTus.FirstOrDefault(Function(p) p.SoChungTu = MySoChungTu)

                SoChungTu.EditValue = mCurrObject.SoChungTu
                NgayLap.EditValue = mCurrObject.NgayLap
                MaKH.EditValue = mCurrObject.MaKH
                MaKho.EditValue = mCurrObject.MaKho

                mCurrObject = Nothing

                RefreshDataDetail(MySoChungTu)

            Case eMyFormMode.Them

                RefreshDataDetail(Nothing)

            Case Else


        End Select
    End Sub
#End Region

#Region "Overrides"

#End Region

#Region "Sub"
    Private Sub RefreshDataDetail(ByVal pSoChungTu As String)
        tblDetailData.Release()
        If IsNoValue(pSoChungTu) Then
            tblDetailData = GetEditableDataTable("SELECT * FROM ChiTietChungTu WHERE 1=0")
        Else
            tblDetailData = GetEditableDataTable("SELECT * FROM ChiTietChungTu WHERE SoChungTu=N'" & pSoChungTu & "'")
        End If
        gcData.DataSource = tblDetailData
    End Sub

    Private Sub FillCombo_MaKH()
        Using mData = GetDataTable("SELECT MaKH as ColCode, MaKH+' - '+TenKH as ColName FROM KhachHang")
            MaKH.Properties.DataSource = mData
            mData.Release()
        End Using
    End Sub

    Private Sub FillCombo_MaKho()
        Using mData = GetDataTable("SELECT MaKho as ColCode, MaKho+' - '+TenKho as ColName FROM Kho")
            MaKho.Properties.DataSource = mData
            mData.Release()
        End Using
    End Sub
#End Region

#Region "Functions"
    Private Function SaveData() As Boolean

        Dim mDBContext = DBContextCreateNew()

        Dim mCurrObject = mDBContext.ChungTus.FirstOrDefault(Function(pp) pp.SoChungTu = MySoChungTu)

        mDBContext.ChiTietChungTus.DeleteAllOnSubmit(mDBContext.ChiTietChungTus.Where(Function(p) p.SoChungTu = MySoChungTu).ToList())
        mDBContext.SubmitChanges()

        'mCurrObject.SoChungTu = SoChungTu.EditValue
        mCurrObject.NgayLap = NgayLap.EditValue
        mCurrObject.MaKH = MaKH.EditValue
        mCurrObject.MaKho = MaKho.EditValue
        mCurrObject.LoaiChungTu = MyLoaiChungTu
        mDBContext.SubmitChanges()

        For Each mRow As DataRow In tblDetailData.Rows
            Dim mDetailObject = New DBs.ChiTietChungTu
            mDetailObject.SoChungTu = SoChungTu.EditValue
            mDetailObject.MaHang = mRow.Item("MaHang")
            mDetailObject.SoLuong = mRow.Item("SoLuong")
            mDetailObject.DonGia = mRow.Item("DonGia")
            mDetailObject.ThanhTien = mRow.Item("ThanhTien")
            mDetailObject.ThanhTienVon = 0.0
            mDBContext.ChiTietChungTus.InsertOnSubmit(mDetailObject)
            mDetailObject = Nothing
        Next
        mDBContext.SubmitChanges()

        mDBContext.Release()

    End Function

    Private Function InsertData() As Boolean

        Dim mDBContext = DBContextCreateNew()

        Dim mCurrObject = New DBs.ChungTu

        mCurrObject.SoChungTu = SoChungTu.EditValue
        mCurrObject.NgayLap = NgayLap.EditValue
        mCurrObject.MaKH = MaKH.EditValue
        mCurrObject.MaKho = MaKho.EditValue
        mCurrObject.LoaiChungTu = MyLoaiChungTu

        mDBContext.ChungTus.InsertOnSubmit(mCurrObject)
        mDBContext.SubmitChanges()

        For Each mRow As DataRow In tblDetailData.Rows
            Dim mDetailObject = New DBs.ChiTietChungTu
            mDetailObject.SoChungTu = SoChungTu.EditValue
            mDetailObject.MaHang = mRow.Item("MaHang")
            mDetailObject.SoLuong = mRow.Item("SoLuong")
            mDetailObject.DonGia = mRow.Item("DonGia")
            mDetailObject.ThanhTien = mRow.Item("ThanhTien")
            mDetailObject.ThanhTienVon = 0.0
            mDBContext.ChiTietChungTus.InsertOnSubmit(mDetailObject)
            mDetailObject = Nothing
        Next
        mDBContext.SubmitChanges()

        mDBContext.Release()

    End Function

#End Region

#Region "Control events"

#End Region


   
End Class