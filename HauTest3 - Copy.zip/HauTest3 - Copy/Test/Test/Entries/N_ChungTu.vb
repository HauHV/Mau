﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports HTLFW.HTLLib.HTLStringFuncs
Imports HTLFW.HTLLib.HTLLayoutDefinition
Imports DBs
Imports AppRoot
'Imports AppRoot.AppVars

#End Region

Public Class N_ChungTu

#Region "Declares"
   
    Dim tblData As DataTable
    Dim MyLoaiChungTu As String

#End Region

#Region "Constructors"

    Public Sub New(ByVal pLoaiChungTu As String)
        InitializeComponent()
        MyLoaiChungTu = pLoaiChungTu
    End Sub

    Private Sub N_ChungTu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshData()
    End Sub

#End Region

#Region "Sub"

    Private Sub RefreshData()
        tblData.Release()
        tblData = GetDataTable("SELECT * FROM ChungTu WHERE LoaiChungTu=N'" & MyLoaiChungTu & "'")
        gcData.DataSource = tblData
    End Sub

#End Region

#Region "Events"
    

    Private Sub Xem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Xem.Click
        If IsNoValue(SoChungTu()) Then
            ShowNoData()
            Exit Sub
        End If
        Using mForm = New N_ChungTu_Input(N_ChungTu_Input.eMyFormMode.Xem, MyLoaiChungTu, SoChungTuFunction())
            mForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub Them_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Them.Click

    End Sub

    Private Sub Xoa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Xoa.Click

    End Sub

    Private Sub Sua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Sua.Click

    End Sub

    Private Sub Dong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dong.Click

    End Sub
#End Region

#Region "Functions"
    Private Function SoChungTuFunction() As String
        If gvData.FocusedRowHandle >= 0 Then
            Return gvData.GetFocusedRowCellValue("SoChungTu")
        Else
            Return Nothing
        End If
    End Function
#End Region

#Region "Control events"

  
#End Region

    
End Class