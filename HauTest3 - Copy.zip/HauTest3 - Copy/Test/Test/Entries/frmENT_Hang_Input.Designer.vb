﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmENT_Hang_Input
    Inherits AppRoot.frmBaseListInput

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMaHang = New HTLFW.Label
        Me.MaHang = New HTLFW.UCTextEdit
        Me.lblTenHang = New HTLFW.Label
        Me.TenHang = New HTLFW.UCTextEdit
        Me.Label3 = New HTLFW.Label
        Me.txtGhiChu = New HTLFW.UCTextEdit
        Me.DVT = New HTLFW.UCTextEdit
        Me.TonMin = New HTLFW.TextEditNumber
        Me.Label2 = New HTLFW.Label
        Me.TonMax = New HTLFW.TextEditNumber
        Me.Label4 = New HTLFW.Label
        Me.Label5 = New HTLFW.Label
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TenHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DVT.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TonMin.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TonMax.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdSaveAndClose
        '
        Me.cmdSaveAndClose.Location = New System.Drawing.Point(269, 333)
        Me.HelpProvider.SetShowHelp(Me.cmdSaveAndClose, True)
        Me.cmdSaveAndClose.Tag = "8"
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(188, 333)
        Me.HelpProvider.SetShowHelp(Me.cmdSave, True)
        Me.cmdSave.Tag = "7"
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(376, 333)
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        Me.cmdExit.Tag = "9"
        '
        'grUpdateInfor
        '
        Me.grUpdateInfor.AppearanceCaption.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.grUpdateInfor.AppearanceCaption.Options.UseFont = True
        Me.grUpdateInfor.Location = New System.Drawing.Point(39, 230)
        Me.HelpProvider.SetShowHelp(Me.grUpdateInfor, True)
        '
        'lblMaHang
        '
        Me.lblMaHang.AllowHtmlString = True
        Me.lblMaHang.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblMaHang.AutoSetTextToToolTip = False
        Me.lblMaHang.Location = New System.Drawing.Point(31, 54)
        Me.lblMaHang.MyNextControl = Me.MaHang
        Me.lblMaHang.MyTag01 = Nothing
        Me.lblMaHang.MyTag02 = Nothing
        Me.lblMaHang.MyTag03 = Nothing
        Me.lblMaHang.Name = "lblMaHang"
        Me.lblMaHang.Size = New System.Drawing.Size(52, 15)
        Me.lblMaHang.TabIndex = 18
        Me.lblMaHang.TagEN = Nothing
        Me.lblMaHang.Text = "Mã hàng<b><Color=Red>*</Color></b>"
        '
        'MaHang
        '
        Me.MaHang.ForceRelateControlOnLeave = True
        Me.MaHang.IsFirstInPair = False
        Me.MaHang.Location = New System.Drawing.Point(89, 54)
        Me.MaHang.MyAutoFormat = False
        Me.MaHang.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaHang.MyMaxLength = 0
        Me.MaHang.MyRelateControl = Nothing
        Me.MaHang.MyTag01 = Nothing
        Me.MaHang.MyTag02 = Nothing
        Me.MaHang.MyTag03 = Nothing
        Me.MaHang.Name = "MaHang"
        Me.MaHang.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaHang.Properties.Appearance.Options.UseFont = True
        Me.MaHang.Properties.EditValue = Nothing
        Me.MaHang.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaHang.Properties.MyAutoFormat = False
        Me.MaHang.Size = New System.Drawing.Size(344, 21)
        Me.MaHang.TabIndex = 24
        Me.MaHang.Tag = "1"
        '
        'lblTenHang
        '
        Me.lblTenHang.AllowHtmlString = True
        Me.lblTenHang.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblTenHang.AutoSetTextToToolTip = False
        Me.lblTenHang.Location = New System.Drawing.Point(26, 84)
        Me.lblTenHang.MyNextControl = Me.TenHang
        Me.lblTenHang.MyTag01 = Nothing
        Me.lblTenHang.MyTag02 = Nothing
        Me.lblTenHang.MyTag03 = Nothing
        Me.lblTenHang.Name = "lblTenHang"
        Me.lblTenHang.Size = New System.Drawing.Size(57, 15)
        Me.lblTenHang.TabIndex = 19
        Me.lblTenHang.TagEN = Nothing
        Me.lblTenHang.Text = "Tên hàng<b><Color=Red>*</Color></b>"
        '
        'TenHang
        '
        Me.TenHang.ForceRelateControlOnLeave = True
        Me.TenHang.IsFirstInPair = False
        Me.TenHang.Location = New System.Drawing.Point(89, 81)
        Me.TenHang.MyAutoFormat = False
        Me.TenHang.MyDataType = HTLFW.eValidDataRange.StringType
        Me.TenHang.MyMaxLength = 0
        Me.TenHang.MyRelateControl = Nothing
        Me.TenHang.MyTag01 = Nothing
        Me.TenHang.MyTag02 = Nothing
        Me.TenHang.MyTag03 = Nothing
        Me.TenHang.Name = "TenHang"
        Me.TenHang.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TenHang.Properties.Appearance.Options.UseFont = True
        Me.TenHang.Properties.EditValue = Nothing
        Me.TenHang.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TenHang.Properties.MyAutoFormat = False
        Me.TenHang.Size = New System.Drawing.Size(344, 21)
        Me.TenHang.TabIndex = 25
        Me.TenHang.Tag = "2"
        '
        'Label3
        '
        Me.Label3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label3.AutoSetTextToToolTip = False
        Me.Label3.Location = New System.Drawing.Point(41, 192)
        Me.Label3.MyNextControl = Me.txtGhiChu
        Me.Label3.MyTag01 = Nothing
        Me.Label3.MyTag02 = Nothing
        Me.Label3.MyTag03 = Nothing
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 15)
        Me.Label3.TabIndex = 20
        Me.Label3.TagEN = Nothing
        Me.Label3.Text = "Ghi chú"
        '
        'txtGhiChu
        '
        Me.txtGhiChu.ForceRelateControlOnLeave = True
        Me.txtGhiChu.IsFirstInPair = False
        Me.txtGhiChu.Location = New System.Drawing.Point(89, 189)
        Me.txtGhiChu.MyAutoFormat = False
        Me.txtGhiChu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.txtGhiChu.MyMaxLength = 0
        Me.txtGhiChu.MyRelateControl = Nothing
        Me.txtGhiChu.MyTag01 = Nothing
        Me.txtGhiChu.MyTag02 = Nothing
        Me.txtGhiChu.MyTag03 = Nothing
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.Appearance.Options.UseFont = True
        Me.txtGhiChu.Properties.EditValue = Nothing
        Me.txtGhiChu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.MyAutoFormat = False
        Me.txtGhiChu.Size = New System.Drawing.Size(344, 21)
        Me.txtGhiChu.TabIndex = 26
        Me.txtGhiChu.Tag = "6"
        '
        'DVT
        '
        Me.DVT.ForceRelateControlOnLeave = True
        Me.DVT.IsFirstInPair = False
        Me.DVT.Location = New System.Drawing.Point(89, 108)
        Me.DVT.MyAutoFormat = False
        Me.DVT.MyDataType = HTLFW.eValidDataRange.StringType
        Me.DVT.MyMaxLength = 0
        Me.DVT.MyRelateControl = Nothing
        Me.DVT.MyTag01 = Nothing
        Me.DVT.MyTag02 = Nothing
        Me.DVT.MyTag03 = Nothing
        Me.DVT.Name = "DVT"
        Me.DVT.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.DVT.Properties.Appearance.Options.UseFont = True
        Me.DVT.Properties.EditValue = Nothing
        Me.DVT.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.DVT.Properties.MyAutoFormat = False
        Me.DVT.Size = New System.Drawing.Size(174, 21)
        Me.DVT.TabIndex = 28
        Me.DVT.Tag = "3"
        '
        'TonMin
        '
        Me.TonMin.EditValue = 0
        Me.TonMin.EnterMoveNextControl = True
        Me.TonMin.ForceRelateControlOnLeave = True
        Me.TonMin.IsFirstInPair = False
        Me.TonMin.Location = New System.Drawing.Point(89, 135)
        Me.TonMin.MyAllowNegative = False
        Me.TonMin.MyAllowUseArrowUpDown = False
        Me.TonMin.MyAllowUseMouseWheel = False
        Me.TonMin.MyAutoFormat = False
        Me.TonMin.MyDecimalPlaces = 0
        Me.TonMin.MyMaxValue = 0
        Me.TonMin.MyMinValue = 0
        Me.TonMin.MyRelateControl = Nothing
        Me.TonMin.MyTag01 = Nothing
        Me.TonMin.MyTag02 = Nothing
        Me.TonMin.MyTag03 = Nothing
        Me.TonMin.Name = "TonMin"
        Me.TonMin.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMin.Properties.Appearance.Options.UseFont = True
        Me.TonMin.Properties.Appearance.Options.UseTextOptions = True
        Me.TonMin.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMin.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMin.Properties.AppearanceDisabled.Options.UseFont = True
        Me.TonMin.Properties.AppearanceDisabled.Options.UseTextOptions = True
        Me.TonMin.Properties.AppearanceDisabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMin.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMin.Properties.AppearanceFocused.Options.UseFont = True
        Me.TonMin.Properties.AppearanceFocused.Options.UseTextOptions = True
        Me.TonMin.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMin.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMin.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.TonMin.Properties.AppearanceReadOnly.Options.UseTextOptions = True
        Me.TonMin.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMin.Properties.DisplayFormat.FormatString = "N0"
        Me.TonMin.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.TonMin.Properties.EditFormat.FormatString = "N0"
        Me.TonMin.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.TonMin.Properties.EditValue = 0
        Me.TonMin.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMin.Properties.Mask.EditMask = "N0"
        Me.TonMin.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.TonMin.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.TonMin.Properties.MyAllowNegative = False
        Me.TonMin.Properties.MyAllowUseArrowUpDown = False
        Me.TonMin.Properties.MyAllowUseMouseWheel = False
        Me.TonMin.Properties.MyAutoFormat = False
        Me.TonMin.Properties.MyDecimalPlaces = 0
        Me.TonMin.Properties.MyMaxValue = 0
        Me.TonMin.Properties.MyMinValue = 0
        Me.TonMin.Properties.UseDefaultMode = True
        Me.TonMin.Properties.ValidateOnEnterKey = True
        Me.TonMin.Size = New System.Drawing.Size(174, 21)
        Me.TonMin.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label2.AutoSetTextToToolTip = False
        Me.Label2.Location = New System.Drawing.Point(60, 111)
        Me.Label2.MyNextControl = Me.DVT
        Me.Label2.MyTag01 = Nothing
        Me.Label2.MyTag02 = Nothing
        Me.Label2.MyTag03 = Nothing
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 15)
        Me.Label2.TabIndex = 30
        Me.Label2.TagEN = Nothing
        Me.Label2.Text = "DVT"
        '
        'TonMax
        '
        Me.TonMax.EditValue = 0
        Me.TonMax.EnterMoveNextControl = True
        Me.TonMax.ForceRelateControlOnLeave = True
        Me.TonMax.IsFirstInPair = False
        Me.TonMax.Location = New System.Drawing.Point(89, 162)
        Me.TonMax.MyAllowNegative = False
        Me.TonMax.MyAllowUseArrowUpDown = False
        Me.TonMax.MyAllowUseMouseWheel = False
        Me.TonMax.MyAutoFormat = False
        Me.TonMax.MyDecimalPlaces = 0
        Me.TonMax.MyMaxValue = 0
        Me.TonMax.MyMinValue = 0
        Me.TonMax.MyRelateControl = Nothing
        Me.TonMax.MyTag01 = Nothing
        Me.TonMax.MyTag02 = Nothing
        Me.TonMax.MyTag03 = Nothing
        Me.TonMax.Name = "TonMax"
        Me.TonMax.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMax.Properties.Appearance.Options.UseFont = True
        Me.TonMax.Properties.Appearance.Options.UseTextOptions = True
        Me.TonMax.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMax.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMax.Properties.AppearanceDisabled.Options.UseFont = True
        Me.TonMax.Properties.AppearanceDisabled.Options.UseTextOptions = True
        Me.TonMax.Properties.AppearanceDisabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMax.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMax.Properties.AppearanceFocused.Options.UseFont = True
        Me.TonMax.Properties.AppearanceFocused.Options.UseTextOptions = True
        Me.TonMax.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMax.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMax.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.TonMax.Properties.AppearanceReadOnly.Options.UseTextOptions = True
        Me.TonMax.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.TonMax.Properties.DisplayFormat.FormatString = "N0"
        Me.TonMax.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.TonMax.Properties.EditFormat.FormatString = "N0"
        Me.TonMax.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.TonMax.Properties.EditValue = 0
        Me.TonMax.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TonMax.Properties.Mask.EditMask = "N0"
        Me.TonMax.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.TonMax.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.TonMax.Properties.MyAllowNegative = False
        Me.TonMax.Properties.MyAllowUseArrowUpDown = False
        Me.TonMax.Properties.MyAllowUseMouseWheel = False
        Me.TonMax.Properties.MyAutoFormat = False
        Me.TonMax.Properties.MyDecimalPlaces = 0
        Me.TonMax.Properties.MyMaxValue = 0
        Me.TonMax.Properties.MyMinValue = 0
        Me.TonMax.Properties.UseDefaultMode = True
        Me.TonMax.Properties.ValidateOnEnterKey = True
        Me.TonMax.Size = New System.Drawing.Size(174, 21)
        Me.TonMax.TabIndex = 31
        Me.TonMax.Tag = "5"
        '
        'Label4
        '
        Me.Label4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label4.AutoSetTextToToolTip = False
        Me.Label4.Location = New System.Drawing.Point(40, 138)
        Me.Label4.MyNextControl = Me.TonMin
        Me.Label4.MyTag01 = Nothing
        Me.Label4.MyTag02 = Nothing
        Me.Label4.MyTag03 = Nothing
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 15)
        Me.Label4.TabIndex = 32
        Me.Label4.TagEN = Nothing
        Me.Label4.Text = "Tồn Min"
        '
        'Label5
        '
        Me.Label5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label5.AutoSetTextToToolTip = False
        Me.Label5.Location = New System.Drawing.Point(38, 165)
        Me.Label5.MyNextControl = Me.TonMax
        Me.Label5.MyTag01 = Nothing
        Me.Label5.MyTag02 = Nothing
        Me.Label5.MyTag03 = Nothing
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 15)
        Me.Label5.TabIndex = 33
        Me.Label5.TagEN = Nothing
        Me.Label5.Text = "Tồn Max"
        '
        'frmENT_Hang_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 369)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TonMax)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TonMin)
        Me.Controls.Add(Me.DVT)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.TenHang)
        Me.Controls.Add(Me.MaHang)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblTenHang)
        Me.Controls.Add(Me.lblMaHang)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmENT_Hang_Input"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Text = "frmENT_Kho_Input"
        Me.Controls.SetChildIndex(Me.lblMaHang, 0)
        Me.Controls.SetChildIndex(Me.grUpdateInfor, 0)
        Me.Controls.SetChildIndex(Me.cmdSaveAndClose, 0)
        Me.Controls.SetChildIndex(Me.cmdSave, 0)
        Me.Controls.SetChildIndex(Me.cmdExit, 0)
        Me.Controls.SetChildIndex(Me.lblTenHang, 0)
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.MaHang, 0)
        Me.Controls.SetChildIndex(Me.TenHang, 0)
        Me.Controls.SetChildIndex(Me.txtGhiChu, 0)
        Me.Controls.SetChildIndex(Me.DVT, 0)
        Me.Controls.SetChildIndex(Me.TonMin, 0)
        Me.Controls.SetChildIndex(Me.Label2, 0)
        Me.Controls.SetChildIndex(Me.TonMax, 0)
        Me.Controls.SetChildIndex(Me.Label4, 0)
        Me.Controls.SetChildIndex(Me.Label5, 0)
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TenHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DVT.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TonMin.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TonMax.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblMaHang As HTLFW.Label
    Friend WithEvents lblTenHang As HTLFW.Label
    Friend WithEvents Label3 As HTLFW.Label
    Friend WithEvents MaHang As HTLFW.UCTextEdit
    Friend WithEvents TenHang As HTLFW.UCTextEdit
    Friend WithEvents txtGhiChu As HTLFW.UCTextEdit
    Friend WithEvents DVT As HTLFW.UCTextEdit
    Friend WithEvents TonMin As HTLFW.TextEditNumber
    Friend WithEvents Label2 As HTLFW.Label
    Friend WithEvents TonMax As HTLFW.TextEditNumber
    Friend WithEvents Label4 As HTLFW.Label
    Friend WithEvents Label5 As HTLFW.Label
End Class
