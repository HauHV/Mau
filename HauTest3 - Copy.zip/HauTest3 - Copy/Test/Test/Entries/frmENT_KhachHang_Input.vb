﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports HTLFW.HTLLib.HTLStringFuncs
Imports HTLFW.HTLLib.HTLLayoutDefinition
Imports DBs

#End Region
Public Class frmENT_KhachHang_Input
#Region "Declares"

    Private _NewCodeValue As String = Nothing
    Private DataSourceTableName As String = "KH"
    'Private AutoRefObjectDefined As Boolean = True
    Private MyMaKH As String

#End Region
#Region "Properties"

    Public Overrides Property FormMode() As HTLFW.eFormMode
        Get
            Return MyBase.FormMode
        End Get
        Set(ByVal value As HTLFW.eFormMode)
            MyBase.FormMode = value
            If IsAllVIEWMode() Then
                MaKH.Properties.ReadOnly = True
                MaKH.Enabled = False
                TenKH.Properties.ReadOnly = True
                TenKH.Enabled = False
                SDT.Properties.ReadOnly = True
                SDT.Enabled = False
                DiaChi.Properties.ReadOnly = True
                DiaChi.Enabled = False
                txtGhiChu.Properties.ReadOnly = True
                txtGhiChu.Enabled = False
            End If
        End Set
    End Property

#End Region

#Region "Constructors"

    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pMaKH As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        MyMaKH = pMaKH
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean, ByVal pMaKH As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
        MyMaKH = pMaKH
    End Sub

    Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        ReleaseMemory()
    End Sub

    Private Sub Me_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


#End Region

#Region "Override"

    Public Overrides Function LoadData() As Boolean
        Try
            Select Case FormMode
                Case eFormMode.Modify, eFormMode.View, eFormMode.ModifyAndy, eFormMode.ViewAny
                    Dim mCurrObject = DBContext.KhachHangs.FirstOrDefault(Function(pp) pp.MaKH.Equals(PrimaryKey.KeyValue("MaKH")))
                    If mCurrObject Is Nothing Then
                        ResetControls()
                        Return False
                    Else
                        With mCurrObject

                            MaKH.EditValue = .MaKH
                            TenKH.EditValue = .TenKH
                            DiaChi.EditValue = .DiaChi
                            SDT.EditValue = .SDT
                            txtGhiChu.EditValue = .GhiChu

                        End With
                    End If
                    mCurrObject = Nothing
                    Return True
                Case Else
                    ResetControls()
                    Return True
            End Select
        Catch ex As Exception
            ShowErrorStop(ex.Message)
            Return False
        End Try

    End Function

    Public Overrides Function InsertData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()
        mDBContext.TransactionStart()

        Dim mNewObject = New KhachHang
        With mNewObject

            .MaKH = Nz(MaKH.EditValue, Nothing)
            .TenKH = Nz(TenKH.EditValue, Nothing)
            .DiaChi = Nz(DiaChi.EditValue, Nothing)
            .SDT = Nz(SDT.EditValue, Nothing)
            .GhiChu = Nz(txtGhiChu.EditValue, Nothing)

        End With
        Try
            mDBContext.KhachHangs.InsertOnSubmit(mNewObject)
            mDBContext.SubmitChanges()
        Catch ex As Exception
            mDBContext.TransactionRollback()
            mDBContext.Release()
            mNewObject = Nothing
            ShowUnknownError(ex.Message)
            Return False
        End Try

        mDBContext.AppendToAppHistory("ADDNEW " + DataSourceTableName, "MaKH=[" + mNewObject.MaKH + "] | TenKH=[" + Nz(mNewObject.TenKH, "") + "] | GhiChu=[" + Nz(mNewObject.GhiChu, ""))

        mDBContext.TransactionCommit()
        mDBContext.Release()

        PrimaryKey.KeyValue("MaKH") = mNewObject.MaKH

        mNewObject = Nothing

        ResetControls()

        FillCombosData()

        Return True
    End Function

    Public Overrides Function SaveData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()

        mDBContext.TransactionStart()

        Dim mModifyObject = mDBContext.KhachHangs.FirstOrDefault(Function(pp) pp.MaKH.Equals(MaKH.EditValue))
        If mModifyObject Is Nothing Then
            mDBContext.TransactionRollback()
            mDBContext.Release()
            ShowErrorStop(HTLFW.My.Resources.MessageContent.infoErrorSaveFailedMissing)
            Return False
        Else
            With mModifyObject

                .MaKH = Nz(MaKH.EditValue, Nothing)
                .TenKH = Nz(TenKH.EditValue, Nothing)
                .DiaChi = Nz(DiaChi.EditValue, Nothing)
                .SDT = Nz(SDT.EditValue, Nothing)
                .GhiChu = Nz(txtGhiChu.EditValue, Nothing)
            End With
            Try
                mDBContext.SubmitChanges()
            Catch ex As Exception
                mDBContext.TransactionRollback()
                mDBContext.Release()
                mModifyObject = Nothing
                ShowUnknownError(ex.Message)
                Return False
            End Try

            mDBContext.AppendToAppHistory("MODIFY " + DataSourceTableName, "MaKH=[" + PrimaryKey.KeyValue("MaKH") + "]->[" + mModifyObject.MaKH + "] | TenKH=[" + Nz(PrimaryKey.KeyValue("TenKH"), "") + "]->[" + Nz(mModifyObject.TenKH, ""))

            PrimaryKey.KeyValue("MaKH") = mModifyObject.MaKH

            mDBContext.TransactionCommit()
            mDBContext.Release()
            mModifyObject = Nothing

            Return True
        End If

    End Function

    'Public Overrides Sub FillCombosData()
    '    FillCombosData_MaKho()
    '    FillCombosData_TenKho()
    'End Sub

#End Region

#Region "ValidData"

    Private Function DataIsOK() As Boolean
        RefreshErrors()
        Dim mTam As String = ""
        For Each mControl As DevExpress.XtraEditors.BaseEdit In Me.Controls.OfType(Of DevExpress.XtraEditors.BaseEdit)().OrderBy(Function(pp) pp.TabIndex).ToList
            mTam = DxError.GetError(mControl)
            If mTam <> "" Then
                ShowErrorStop(mTam)
                mControl.Focus()
                Return False
            End If
        Next
        Return True
    End Function
    Private Sub ResetErrors()
        For Each mControl In Me.Controls
            DxError.SetError(mControl, "")
        Next
    End Sub
    Private Sub RefreshErrors()
        ResetErrors()
        If IsNoValue(MaKH.EditValue) Then
            DxError.SetError(MaKH, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblMaKH.UniText}))
        End If
        If IsNoValue(TenKH.EditValue) Then
            DxError.SetError(TenKH, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblTenKH.UniText}))
        End If

    End Sub

#End Region

#Region "Subs"

    Private Sub ResetControls()

        MaKH.EditValue = Nothing
        TenKH.EditValue = Nothing
        DiaChi.EditValue = Nothing
        SDT.EditValue = Nothing
        txtGhiChu.EditValue = Nothing

        MaKH.Focus()
    End Sub

#End Region

#Region "Controls Events"

#End Region

   
End Class