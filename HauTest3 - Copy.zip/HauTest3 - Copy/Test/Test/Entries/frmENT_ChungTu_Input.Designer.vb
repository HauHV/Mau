﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmENT_ChungTu_Input
    Inherits AppRoot.frmBaseListInput

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSoChungTu = New HTLFW.Label
        Me.SoChungTu = New HTLFW.UCTextEdit
        Me.lblLoaiChungTu = New HTLFW.Label
        Me.Label3 = New HTLFW.Label
        Me.txtGhiChu = New HTLFW.UCTextEdit
        Me.lblNgayLap = New HTLFW.Label
        Me.lblSDT = New HTLFW.Label
        Me.MaKH = New HTLFW.UCGridLookUpEdit
        Me.UcGridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColMaKH = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColTenKH = New DevExpress.XtraGrid.Columns.GridColumn
        Me.Label1 = New HTLFW.Label
        Me.Label2 = New HTLFW.Label
        Me.MaKhoNhan = New HTLFW.UCGridLookUpEdit
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColMaKhoNhan = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColTenKhoNhan = New DevExpress.XtraGrid.Columns.GridColumn
        Me.Label4 = New HTLFW.Label
        Me.MaKhoChuyen = New HTLFW.UCGridLookUpEdit
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.GridColumn1 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn2 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.MaKho = New HTLFW.UCGridLookUpEdit
        Me.GridView3 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColMaKho = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColTenKho = New DevExpress.XtraGrid.Columns.GridColumn
        Me.NgayLap = New HTLFW.UCTextEdit
        Me.grdChiTietChungTu = New HTLFW.UCGridControl
        Me.GridView4 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grColMaHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColSoLuong = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColDonGia = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdcolThanhTien = New DevExpress.XtraGrid.Columns.GridColumn
        Me.LoaiChungTu = New HTLFW.UCGridLookUpEdit
        Me.GridView5 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColLoaiChungTu = New DevExpress.XtraGrid.Columns.GridColumn
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SoChungTu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKhoNhan.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKhoChuyen.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NgayLap.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdChiTietChungTu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LoaiChungTu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdSaveAndClose
        '
        Me.cmdSaveAndClose.Location = New System.Drawing.Point(732, 459)
        Me.HelpProvider.SetShowHelp(Me.cmdSaveAndClose, True)
        Me.cmdSaveAndClose.Tag = "10"
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(651, 459)
        Me.HelpProvider.SetShowHelp(Me.cmdSave, True)
        Me.cmdSave.Tag = "9"
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(839, 459)
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        Me.cmdExit.Tag = "11"
        '
        'grUpdateInfor
        '
        Me.grUpdateInfor.AppearanceCaption.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.grUpdateInfor.AppearanceCaption.Options.UseFont = True
        Me.grUpdateInfor.Location = New System.Drawing.Point(23, 438)
        Me.HelpProvider.SetShowHelp(Me.grUpdateInfor, True)
        '
        'lblSoChungTu
        '
        Me.lblSoChungTu.AllowHtmlString = True
        Me.lblSoChungTu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblSoChungTu.AutoSetTextToToolTip = False
        Me.lblSoChungTu.Location = New System.Drawing.Point(23, 12)
        Me.lblSoChungTu.MyNextControl = Me.SoChungTu
        Me.lblSoChungTu.MyTag01 = Nothing
        Me.lblSoChungTu.MyTag02 = Nothing
        Me.lblSoChungTu.MyTag03 = Nothing
        Me.lblSoChungTu.Name = "lblSoChungTu"
        Me.lblSoChungTu.Size = New System.Drawing.Size(72, 15)
        Me.lblSoChungTu.TabIndex = 18
        Me.lblSoChungTu.TagEN = Nothing
        Me.lblSoChungTu.Text = "Số chứng từ<b><Color=Red>*</Color></b>"
        '
        'SoChungTu
        '
        Me.SoChungTu.ForceRelateControlOnLeave = True
        Me.SoChungTu.IsFirstInPair = False
        Me.SoChungTu.Location = New System.Drawing.Point(101, 12)
        Me.SoChungTu.MyAutoFormat = False
        Me.SoChungTu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.SoChungTu.MyMaxLength = 0
        Me.SoChungTu.MyRelateControl = Nothing
        Me.SoChungTu.MyTag01 = Nothing
        Me.SoChungTu.MyTag02 = Nothing
        Me.SoChungTu.MyTag03 = Nothing
        Me.SoChungTu.Name = "SoChungTu"
        Me.SoChungTu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.Appearance.Options.UseFont = True
        Me.SoChungTu.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.AppearanceDisabled.Options.UseFont = True
        Me.SoChungTu.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.AppearanceFocused.Options.UseFont = True
        Me.SoChungTu.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.SoChungTu.Properties.EditValue = Nothing
        Me.SoChungTu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.MyAutoFormat = False
        Me.SoChungTu.Size = New System.Drawing.Size(210, 21)
        Me.SoChungTu.TabIndex = 24
        Me.SoChungTu.Tag = "1"
        '
        'lblLoaiChungTu
        '
        Me.lblLoaiChungTu.AllowHtmlString = True
        Me.lblLoaiChungTu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblLoaiChungTu.AutoSetTextToToolTip = False
        Me.lblLoaiChungTu.Location = New System.Drawing.Point(317, 12)
        Me.lblLoaiChungTu.MyNextControl = Nothing
        Me.lblLoaiChungTu.MyTag01 = Nothing
        Me.lblLoaiChungTu.MyTag02 = Nothing
        Me.lblLoaiChungTu.MyTag03 = Nothing
        Me.lblLoaiChungTu.Name = "lblLoaiChungTu"
        Me.lblLoaiChungTu.Size = New System.Drawing.Size(81, 15)
        Me.lblLoaiChungTu.TabIndex = 19
        Me.lblLoaiChungTu.TagEN = Nothing
        Me.lblLoaiChungTu.Text = "Loại chứng từ<b><Color=Red>*</Color></b>"
        '
        'Label3
        '
        Me.Label3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label3.AutoSetTextToToolTip = False
        Me.Label3.Location = New System.Drawing.Point(356, 85)
        Me.Label3.MyNextControl = Me.txtGhiChu
        Me.Label3.MyTag01 = Nothing
        Me.Label3.MyTag02 = Nothing
        Me.Label3.MyTag03 = Nothing
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 15)
        Me.Label3.TabIndex = 20
        Me.Label3.TagEN = Nothing
        Me.Label3.Text = "Ghi chú"
        '
        'txtGhiChu
        '
        Me.txtGhiChu.ForceRelateControlOnLeave = True
        Me.txtGhiChu.IsFirstInPair = False
        Me.txtGhiChu.Location = New System.Drawing.Point(404, 82)
        Me.txtGhiChu.MyAutoFormat = False
        Me.txtGhiChu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.txtGhiChu.MyMaxLength = 0
        Me.txtGhiChu.MyRelateControl = Nothing
        Me.txtGhiChu.MyTag01 = Nothing
        Me.txtGhiChu.MyTag02 = Nothing
        Me.txtGhiChu.MyTag03 = Nothing
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.Appearance.Options.UseFont = True
        Me.txtGhiChu.Properties.EditValue = Nothing
        Me.txtGhiChu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.MyAutoFormat = False
        Me.txtGhiChu.Size = New System.Drawing.Size(471, 21)
        Me.txtGhiChu.TabIndex = 26
        Me.txtGhiChu.Tag = "8"
        '
        'lblNgayLap
        '
        Me.lblNgayLap.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblNgayLap.AutoSetTextToToolTip = False
        Me.lblNgayLap.Location = New System.Drawing.Point(599, 12)
        Me.lblNgayLap.MyNextControl = Nothing
        Me.lblNgayLap.MyTag01 = Nothing
        Me.lblNgayLap.MyTag02 = Nothing
        Me.lblNgayLap.MyTag03 = Nothing
        Me.lblNgayLap.Name = "lblNgayLap"
        Me.lblNgayLap.Size = New System.Drawing.Size(48, 15)
        Me.lblNgayLap.TabIndex = 29
        Me.lblNgayLap.TagEN = Nothing
        Me.lblNgayLap.Text = "Ngày lập"
        '
        'lblSDT
        '
        Me.lblSDT.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblSDT.AutoSetTextToToolTip = False
        Me.lblSDT.Location = New System.Drawing.Point(12, 85)
        Me.lblSDT.MyNextControl = Me.MaKH
        Me.lblSDT.MyTag01 = Nothing
        Me.lblSDT.MyTag02 = Nothing
        Me.lblSDT.MyTag03 = Nothing
        Me.lblSDT.Name = "lblSDT"
        Me.lblSDT.Size = New System.Drawing.Size(83, 15)
        Me.lblSDT.TabIndex = 30
        Me.lblSDT.TagEN = Nothing
        Me.lblSDT.Text = "Mã khách hàng"
        '
        'MaKH
        '
        Me.MaKH.AllowNoSourceText = True
        Me.MaKH.AllowNULL = False
        Me.MaKH.ColumnWidths = New Integer() {0, -1}
        Me.MaKH.CreateDefaultColCodeColumn = False
        Me.MaKH.CreateDefaultColNameColumn = False
        Me.MaKH.EditValue = ""
        Me.MaKH.EnterMoveNextControl = True
        Me.MaKH.ForceRelateControlOnLeave = True
        Me.MaKH.HasFilterRow = True
        Me.MaKH.IsChange = False
        Me.MaKH.IsFirstInPair = False
        Me.MaKH.Location = New System.Drawing.Point(101, 82)
        Me.MaKH.MyAutoFormat = False
        Me.MaKH.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKH.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKH.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKH.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKH.MyRelateControl = Nothing
        Me.MaKH.MyTag01 = Nothing
        Me.MaKH.MyTag02 = Nothing
        Me.MaKH.MyTag03 = Nothing
        Me.MaKH.MyTextControl = Nothing
        Me.MaKH.Name = "MaKH"
        Me.MaKH.Properties.AllowNoSourceText = True
        Me.MaKH.Properties.AllowNULL = False
        Me.MaKH.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKH.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.Appearance.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKH.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKH.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKH.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKH.Properties.ColumnWidths = New Integer() {0, -1}
        Me.MaKH.Properties.CreateDefaultColCodeColumn = False
        Me.MaKH.Properties.CreateDefaultColNameColumn = False
        Me.MaKH.Properties.DisplayMember = "MaKH"
        Me.MaKH.Properties.EditValue = ""
        Me.MaKH.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.HasFilterRow = True
        Me.MaKH.Properties.IsChange = False
        Me.MaKH.Properties.MyAutoFormat = False
        Me.MaKH.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKH.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKH.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKH.Properties.MyTextControl = Nothing
        Me.MaKH.Properties.NullText = ""
        Me.MaKH.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKH.Properties.PopupSizeable = False
        Me.MaKH.Properties.ShowFooter = False
        Me.MaKH.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKH.Properties.ValidateOnEnterKey = True
        Me.MaKH.Properties.ValueMember = "MaKH"
        Me.MaKH.Properties.View = Me.UcGridLookUpEdit1View
        Me.MaKH.Size = New System.Drawing.Size(210, 21)
        Me.MaKH.TabIndex = 35
        Me.MaKH.Tag = "4"
        '
        'UcGridLookUpEdit1View
        '
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.DetailTip.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Empty.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.EvenRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FilterCloseButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FilterPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FixedLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FocusedCell.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FooterPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupFooter.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HorzLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.OddRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Preview.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Row.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.RowSeparator.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.TopNewRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.VertLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ViewCaption.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColMaKH, Me.grdColTenKH})
        Me.UcGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.UcGridLookUpEdit1View.Name = "UcGridLookUpEdit1View"
        Me.UcGridLookUpEdit1View.OptionsBehavior.Editable = False
        Me.UcGridLookUpEdit1View.OptionsBehavior.ReadOnly = True
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowColumnMoving = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowColumnResizing = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowGroup = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowQuickHideColumns = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableColumnMenu = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableFooterMenu = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableGroupPanelMenu = False
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceHideSelection = False
        Me.UcGridLookUpEdit1View.OptionsView.ColumnAutoWidth = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowAutoFilterRow = True
        Me.UcGridLookUpEdit1View.OptionsView.ShowColumnHeaders = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowIndicator = False
        Me.UcGridLookUpEdit1View.SortInfo.AddRange(New DevExpress.XtraGrid.Columns.GridColumnSortInfo() {New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.grdColMaKH, DevExpress.Data.ColumnSortOrder.Ascending), New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.grdColTenKH, DevExpress.Data.ColumnSortOrder.Ascending)})
        '
        'grdColMaKH
        '
        Me.grdColMaKH.AppearanceCell.Options.UseTextOptions = True
        Me.grdColMaKH.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
        Me.grdColMaKH.Caption = "MaKH"
        Me.grdColMaKH.FieldName = "MaKH"
        Me.grdColMaKH.Name = "grdColMaKH"
        Me.grdColMaKH.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaKH.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.grdColMaKH.Visible = True
        Me.grdColMaKH.VisibleIndex = 0
        '
        'grdColTenKH
        '
        Me.grdColTenKH.AppearanceCell.Options.UseTextOptions = True
        Me.grdColTenKH.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
        Me.grdColTenKH.Caption = "TenKH"
        Me.grdColTenKH.FieldName = "TenKH"
        Me.grdColTenKH.Name = "grdColTenKH"
        Me.grdColTenKH.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColTenKH.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.grdColTenKH.Visible = True
        Me.grdColTenKH.VisibleIndex = 1
        '
        'Label1
        '
        Me.Label1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label1.AutoSetTextToToolTip = False
        Me.Label1.Location = New System.Drawing.Point(53, 50)
        Me.Label1.MyNextControl = Nothing
        Me.Label1.MyTag01 = Nothing
        Me.Label1.MyTag02 = Nothing
        Me.Label1.MyTag03 = Nothing
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 15)
        Me.Label1.TabIndex = 31
        Me.Label1.TagEN = Nothing
        Me.Label1.Text = "Mã kho "
        '
        'Label2
        '
        Me.Label2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label2.AutoSetTextToToolTip = False
        Me.Label2.Location = New System.Drawing.Point(328, 50)
        Me.Label2.MyNextControl = Me.MaKhoNhan
        Me.Label2.MyTag01 = Nothing
        Me.Label2.MyTag02 = Nothing
        Me.Label2.MyTag03 = Nothing
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 15)
        Me.Label2.TabIndex = 32
        Me.Label2.TagEN = Nothing
        Me.Label2.Text = "Mã kho nhận"
        '
        'MaKhoNhan
        '
        Me.MaKhoNhan.AllowNoSourceText = True
        Me.MaKhoNhan.AllowNULL = True
        Me.MaKhoNhan.ColumnWidths = New Integer() {0, -1}
        Me.MaKhoNhan.CreateDefaultColCodeColumn = False
        Me.MaKhoNhan.CreateDefaultColNameColumn = False
        Me.MaKhoNhan.EnterMoveNextControl = True
        Me.MaKhoNhan.ForceRelateControlOnLeave = True
        Me.MaKhoNhan.HasFilterRow = True
        Me.MaKhoNhan.IsChange = False
        Me.MaKhoNhan.IsFirstInPair = False
        Me.MaKhoNhan.Location = New System.Drawing.Point(404, 47)
        Me.MaKhoNhan.MyAutoFormat = False
        Me.MaKhoNhan.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKhoNhan.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKhoNhan.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKhoNhan.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKhoNhan.MyRelateControl = Nothing
        Me.MaKhoNhan.MyTag01 = Nothing
        Me.MaKhoNhan.MyTag02 = Nothing
        Me.MaKhoNhan.MyTag03 = Nothing
        Me.MaKhoNhan.MyTextControl = Nothing
        Me.MaKhoNhan.Name = "MaKhoNhan"
        Me.MaKhoNhan.Properties.AllowNoSourceText = True
        Me.MaKhoNhan.Properties.AllowNULL = True
        Me.MaKhoNhan.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKhoNhan.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.Appearance.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKhoNhan.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKhoNhan.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKhoNhan.Properties.ColumnWidths = New Integer() {0, -1}
        Me.MaKhoNhan.Properties.CreateDefaultColCodeColumn = False
        Me.MaKhoNhan.Properties.CreateDefaultColNameColumn = False
        Me.MaKhoNhan.Properties.DisplayMember = "TenKho"
        Me.MaKhoNhan.Properties.EditValue = Nothing
        Me.MaKhoNhan.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoNhan.Properties.HasFilterRow = True
        Me.MaKhoNhan.Properties.IsChange = False
        Me.MaKhoNhan.Properties.MyAutoFormat = False
        Me.MaKhoNhan.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKhoNhan.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKhoNhan.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKhoNhan.Properties.MyTextControl = Nothing
        Me.MaKhoNhan.Properties.NullText = ""
        Me.MaKhoNhan.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKhoNhan.Properties.PopupSizeable = False
        Me.MaKhoNhan.Properties.ShowFooter = False
        Me.MaKhoNhan.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKhoNhan.Properties.ValidateOnEnterKey = True
        Me.MaKhoNhan.Properties.ValueMember = "MaKho"
        Me.MaKhoNhan.Properties.View = Me.GridView2
        Me.MaKhoNhan.Size = New System.Drawing.Size(189, 21)
        Me.MaKhoNhan.TabIndex = 37
        Me.MaKhoNhan.Tag = "6"
        '
        'GridView2
        '
        Me.GridView2.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView2.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView2.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView2.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.DetailTip.Options.UseFont = True
        Me.GridView2.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.Empty.Options.UseFont = True
        Me.GridView2.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.EvenRow.Options.UseFont = True
        Me.GridView2.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView2.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView2.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FixedLine.Options.UseFont = True
        Me.GridView2.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView2.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView2.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView2.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView2.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView2.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView2.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupButton.Options.UseFont = True
        Me.GridView2.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView2.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView2.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.GroupRow.Options.UseFont = True
        Me.GridView2.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView2.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView2.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView2.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView2.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView2.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView2.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView2.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.HorzLine.Options.UseFont = True
        Me.GridView2.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.OddRow.Options.UseFont = True
        Me.GridView2.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.Preview.Options.UseFont = True
        Me.GridView2.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.Row.Options.UseFont = True
        Me.GridView2.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView2.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView2.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView2.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView2.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView2.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView2.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.VertLine.Options.UseFont = True
        Me.GridView2.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView2.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView2.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColMaKhoNhan, Me.grdColTenKhoNhan})
        Me.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView2.Name = "GridView2"
        Me.GridView2.OptionsBehavior.Editable = False
        Me.GridView2.OptionsBehavior.ReadOnly = True
        Me.GridView2.OptionsCustomization.AllowColumnMoving = False
        Me.GridView2.OptionsCustomization.AllowColumnResizing = False
        Me.GridView2.OptionsCustomization.AllowGroup = False
        Me.GridView2.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView2.OptionsMenu.EnableColumnMenu = False
        Me.GridView2.OptionsMenu.EnableFooterMenu = False
        Me.GridView2.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView2.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView2.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView2.OptionsView.ColumnAutoWidth = False
        Me.GridView2.OptionsView.ShowAutoFilterRow = True
        Me.GridView2.OptionsView.ShowColumnHeaders = False
        Me.GridView2.OptionsView.ShowGroupPanel = False
        Me.GridView2.OptionsView.ShowIndicator = False
        '
        'grdColMaKhoNhan
        '
        Me.grdColMaKhoNhan.Caption = "MaKho"
        Me.grdColMaKhoNhan.FieldName = "MaKho"
        Me.grdColMaKhoNhan.Name = "grdColMaKhoNhan"
        Me.grdColMaKhoNhan.Visible = True
        Me.grdColMaKhoNhan.VisibleIndex = 0
        '
        'grdColTenKhoNhan
        '
        Me.grdColTenKhoNhan.Caption = "TenKho"
        Me.grdColTenKhoNhan.FieldName = "TenKho"
        Me.grdColTenKhoNhan.Name = "grdColTenKhoNhan"
        Me.grdColTenKhoNhan.Visible = True
        Me.grdColTenKhoNhan.VisibleIndex = 1
        '
        'Label4
        '
        Me.Label4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label4.AutoSetTextToToolTip = False
        Me.Label4.Location = New System.Drawing.Point(599, 50)
        Me.Label4.MyNextControl = Me.MaKhoChuyen
        Me.Label4.MyTag01 = Nothing
        Me.Label4.MyTag02 = Nothing
        Me.Label4.MyTag03 = Nothing
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 15)
        Me.Label4.TabIndex = 33
        Me.Label4.TagEN = Nothing
        Me.Label4.Text = "Mã kho chuyển"
        '
        'MaKhoChuyen
        '
        Me.MaKhoChuyen.AllowNoSourceText = True
        Me.MaKhoChuyen.AllowNULL = True
        Me.MaKhoChuyen.ColumnWidths = New Integer() {0, -1}
        Me.MaKhoChuyen.CreateDefaultColCodeColumn = False
        Me.MaKhoChuyen.CreateDefaultColNameColumn = False
        Me.MaKhoChuyen.EnterMoveNextControl = True
        Me.MaKhoChuyen.ForceRelateControlOnLeave = True
        Me.MaKhoChuyen.HasFilterRow = True
        Me.MaKhoChuyen.IsChange = False
        Me.MaKhoChuyen.IsFirstInPair = False
        Me.MaKhoChuyen.Location = New System.Drawing.Point(686, 47)
        Me.MaKhoChuyen.MyAutoFormat = False
        Me.MaKhoChuyen.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKhoChuyen.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKhoChuyen.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKhoChuyen.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKhoChuyen.MyRelateControl = Nothing
        Me.MaKhoChuyen.MyTag01 = Nothing
        Me.MaKhoChuyen.MyTag02 = Nothing
        Me.MaKhoChuyen.MyTag03 = Nothing
        Me.MaKhoChuyen.MyTextControl = Nothing
        Me.MaKhoChuyen.Name = "MaKhoChuyen"
        Me.MaKhoChuyen.Properties.AllowNoSourceText = True
        Me.MaKhoChuyen.Properties.AllowNULL = True
        Me.MaKhoChuyen.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKhoChuyen.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.Properties.Appearance.Options.UseFont = True
        Me.MaKhoChuyen.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKhoChuyen.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKhoChuyen.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKhoChuyen.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKhoChuyen.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKhoChuyen.Properties.ColumnWidths = New Integer() {0, -1}
        Me.MaKhoChuyen.Properties.CreateDefaultColCodeColumn = False
        Me.MaKhoChuyen.Properties.CreateDefaultColNameColumn = False
        Me.MaKhoChuyen.Properties.DisplayMember = "TenKho"
        Me.MaKhoChuyen.Properties.EditValue = Nothing
        Me.MaKhoChuyen.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKhoChuyen.Properties.HasFilterRow = True
        Me.MaKhoChuyen.Properties.IsChange = False
        Me.MaKhoChuyen.Properties.MyAutoFormat = False
        Me.MaKhoChuyen.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKhoChuyen.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKhoChuyen.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKhoChuyen.Properties.MyTextControl = Nothing
        Me.MaKhoChuyen.Properties.NullText = ""
        Me.MaKhoChuyen.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKhoChuyen.Properties.PopupSizeable = False
        Me.MaKhoChuyen.Properties.ShowFooter = False
        Me.MaKhoChuyen.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKhoChuyen.Properties.ValidateOnEnterKey = True
        Me.MaKhoChuyen.Properties.ValueMember = "MaKho"
        Me.MaKhoChuyen.Properties.View = Me.GridView1
        Me.MaKhoChuyen.Size = New System.Drawing.Size(189, 21)
        Me.MaKhoChuyen.TabIndex = 36
        Me.MaKhoChuyen.Tag = "7"
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn1, Me.GridColumn2})
        Me.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'GridColumn1
        '
        Me.GridColumn1.Caption = "MaKho"
        Me.GridColumn1.FieldName = "MaKho"
        Me.GridColumn1.Name = "GridColumn1"
        Me.GridColumn1.Visible = True
        Me.GridColumn1.VisibleIndex = 0
        '
        'GridColumn2
        '
        Me.GridColumn2.Caption = "TenKho"
        Me.GridColumn2.FieldName = "TenKho"
        Me.GridColumn2.Name = "GridColumn2"
        Me.GridColumn2.Visible = True
        Me.GridColumn2.VisibleIndex = 1
        '
        'MaKho
        '
        Me.MaKho.AllowNoSourceText = True
        Me.MaKho.AllowNULL = True
        Me.MaKho.ColumnWidths = New Integer() {0, -1}
        Me.MaKho.CreateDefaultColCodeColumn = False
        Me.MaKho.CreateDefaultColNameColumn = False
        Me.MaKho.EnterMoveNextControl = True
        Me.MaKho.ForceRelateControlOnLeave = True
        Me.MaKho.HasFilterRow = True
        Me.MaKho.IsChange = False
        Me.MaKho.IsFirstInPair = False
        Me.MaKho.Location = New System.Drawing.Point(101, 47)
        Me.MaKho.MyAutoFormat = False
        Me.MaKho.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKho.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKho.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKho.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKho.MyRelateControl = Nothing
        Me.MaKho.MyTag01 = Nothing
        Me.MaKho.MyTag02 = Nothing
        Me.MaKho.MyTag03 = Nothing
        Me.MaKho.MyTextControl = Me.MaKho
        Me.MaKho.Name = "MaKho"
        Me.MaKho.Properties.AllowNoSourceText = True
        Me.MaKho.Properties.AllowNULL = True
        Me.MaKho.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKho.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.Appearance.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKho.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKho.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKho.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKho.Properties.ColumnWidths = New Integer() {0, -1}
        Me.MaKho.Properties.CreateDefaultColCodeColumn = False
        Me.MaKho.Properties.CreateDefaultColNameColumn = False
        Me.MaKho.Properties.DisplayMember = "TenKho"
        Me.MaKho.Properties.EditValue = Nothing
        Me.MaKho.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.HasFilterRow = True
        Me.MaKho.Properties.IsChange = False
        Me.MaKho.Properties.MyAutoFormat = False
        Me.MaKho.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKho.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKho.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKho.Properties.MyTextControl = Me.MaKho
        Me.MaKho.Properties.NullText = ""
        Me.MaKho.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKho.Properties.PopupSizeable = False
        Me.MaKho.Properties.ShowFooter = False
        Me.MaKho.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKho.Properties.ValidateOnEnterKey = True
        Me.MaKho.Properties.ValueMember = "MaKho"
        Me.MaKho.Properties.View = Me.GridView3
        Me.MaKho.Size = New System.Drawing.Size(210, 21)
        Me.MaKho.TabIndex = 38
        Me.MaKho.Tag = "5"
        '
        'GridView3
        '
        Me.GridView3.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView3.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView3.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView3.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.DetailTip.Options.UseFont = True
        Me.GridView3.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.Empty.Options.UseFont = True
        Me.GridView3.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.EvenRow.Options.UseFont = True
        Me.GridView3.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView3.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView3.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FixedLine.Options.UseFont = True
        Me.GridView3.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView3.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView3.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView3.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView3.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView3.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView3.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupButton.Options.UseFont = True
        Me.GridView3.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView3.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView3.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.GroupRow.Options.UseFont = True
        Me.GridView3.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView3.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView3.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView3.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView3.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView3.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView3.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView3.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.HorzLine.Options.UseFont = True
        Me.GridView3.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.OddRow.Options.UseFont = True
        Me.GridView3.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.Preview.Options.UseFont = True
        Me.GridView3.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.Row.Options.UseFont = True
        Me.GridView3.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView3.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView3.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView3.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView3.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView3.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView3.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.VertLine.Options.UseFont = True
        Me.GridView3.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView3.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView3.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColMaKho, Me.grdColTenKho})
        Me.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView3.Name = "GridView3"
        Me.GridView3.OptionsBehavior.Editable = False
        Me.GridView3.OptionsBehavior.ReadOnly = True
        Me.GridView3.OptionsCustomization.AllowColumnMoving = False
        Me.GridView3.OptionsCustomization.AllowColumnResizing = False
        Me.GridView3.OptionsCustomization.AllowGroup = False
        Me.GridView3.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView3.OptionsMenu.EnableColumnMenu = False
        Me.GridView3.OptionsMenu.EnableFooterMenu = False
        Me.GridView3.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView3.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView3.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView3.OptionsView.ColumnAutoWidth = False
        Me.GridView3.OptionsView.ShowAutoFilterRow = True
        Me.GridView3.OptionsView.ShowColumnHeaders = False
        Me.GridView3.OptionsView.ShowGroupPanel = False
        Me.GridView3.OptionsView.ShowIndicator = False
        Me.GridView3.SortInfo.AddRange(New DevExpress.XtraGrid.Columns.GridColumnSortInfo() {New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.grdColMaKho, DevExpress.Data.ColumnSortOrder.Ascending), New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.grdColTenKho, DevExpress.Data.ColumnSortOrder.Ascending)})
        '
        'grdColMaKho
        '
        Me.grdColMaKho.AppearanceCell.Options.UseTextOptions = True
        Me.grdColMaKho.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
        Me.grdColMaKho.Caption = "MaKho"
        Me.grdColMaKho.FieldName = "MaKho"
        Me.grdColMaKho.Name = "grdColMaKho"
        Me.grdColMaKho.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaKho.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.grdColMaKho.Visible = True
        Me.grdColMaKho.VisibleIndex = 0
        '
        'grdColTenKho
        '
        Me.grdColTenKho.AppearanceCell.Options.UseTextOptions = True
        Me.grdColTenKho.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
        Me.grdColTenKho.Caption = "TenKho"
        Me.grdColTenKho.FieldName = "TenKho"
        Me.grdColTenKho.Name = "grdColTenKho"
        Me.grdColTenKho.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColTenKho.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.grdColTenKho.Visible = True
        Me.grdColTenKho.VisibleIndex = 1
        '
        'NgayLap
        '
        Me.NgayLap.ForceRelateControlOnLeave = True
        Me.NgayLap.IsFirstInPair = False
        Me.NgayLap.Location = New System.Drawing.Point(653, 9)
        Me.NgayLap.MyAutoFormat = False
        Me.NgayLap.MyDataType = HTLFW.eValidDataRange.DateType
        Me.NgayLap.MyMaxLength = 0
        Me.NgayLap.MyRelateControl = Nothing
        Me.NgayLap.MyTag01 = Nothing
        Me.NgayLap.MyTag02 = Nothing
        Me.NgayLap.MyTag03 = Nothing
        Me.NgayLap.Name = "NgayLap"
        Me.NgayLap.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.Appearance.Options.UseFont = True
        Me.NgayLap.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.AppearanceDisabled.Options.UseFont = True
        Me.NgayLap.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.AppearanceFocused.Options.UseFont = True
        Me.NgayLap.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.NgayLap.Properties.DisplayFormat.FormatString = "dd/MM/yyyy"
        Me.NgayLap.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.NgayLap.Properties.EditFormat.FormatString = "dd/MM/yyyy"
        Me.NgayLap.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.NgayLap.Properties.EditValue = Nothing
        Me.NgayLap.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.MyAutoFormat = False
        Me.NgayLap.Size = New System.Drawing.Size(222, 21)
        Me.NgayLap.TabIndex = 39
        '
        'grdChiTietChungTu
        '
        Me.grdChiTietChungTu.AllowCommandDelete = True
        Me.grdChiTietChungTu.AllowCommandModify = True
        Me.grdChiTietChungTu.AllowCommandView = True
        Me.grdChiTietChungTu.AllowContextMenu = True
        Me.grdChiTietChungTu.AutoFocusToNewRow = True
        Me.grdChiTietChungTu.EnableCommandDelete = True
        Me.grdChiTietChungTu.EnableCommandModify = True
        Me.grdChiTietChungTu.EnableCommandView = True
        Me.grdChiTietChungTu.Location = New System.Drawing.Point(-2, 109)
        Me.grdChiTietChungTu.MainView = Me.GridView4
        Me.grdChiTietChungTu.MyAutoFormat = False
        Me.grdChiTietChungTu.MyBoldFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.grdChiTietChungTu.MyColorStyle = HTLFW.UCGridControl.eColorStyle.Custom
        Me.grdChiTietChungTu.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.grdChiTietChungTu.MyFocusForeColor = System.Drawing.Color.Black
        Me.grdChiTietChungTu.MyItalicFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.grdChiTietChungTu.MyMainView = Me.GridView4
        Me.grdChiTietChungTu.MyNewRowBackColor = System.Drawing.Color.LemonChiffon
        Me.grdChiTietChungTu.MyNewRowForeColor = System.Drawing.Color.Black
        Me.grdChiTietChungTu.MyNormalFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.grdChiTietChungTu.MyOrdSource = HTLFW.UCGridControl.eOrdSource.RowHandle
        Me.grdChiTietChungTu.MyShowDateCreatedColumn = False
        Me.grdChiTietChungTu.MyShowDateModifiedColumn = False
        Me.grdChiTietChungTu.MyShowDeleteCMD = False
        Me.grdChiTietChungTu.MyShowModifyCMD = False
        Me.grdChiTietChungTu.MyShowOrderColumn = False
        Me.grdChiTietChungTu.MyShowUserCreatedColumn = False
        Me.grdChiTietChungTu.MyShowUserModifiedColumn = False
        Me.grdChiTietChungTu.MyShowViewCMD = False
        Me.grdChiTietChungTu.MyViewType = HTLFW.UCGridControl.eViewType.EditableView
        Me.grdChiTietChungTu.Name = "grdChiTietChungTu"
        Me.grdChiTietChungTu.ShowFilterRow = False
        Me.grdChiTietChungTu.ShowFooter = False
        Me.grdChiTietChungTu.ShowGroupPanel = True
        Me.HelpProvider.SetShowHelp(Me.grdChiTietChungTu, False)
        Me.grdChiTietChungTu.ShowNewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top
        Me.grdChiTietChungTu.Size = New System.Drawing.Size(930, 323)
        Me.grdChiTietChungTu.TabIndex = 40
        Me.grdChiTietChungTu.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView4})
        '
        'GridView4
        '
        Me.GridView4.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView4.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView4.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView4.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.DetailTip.Options.UseFont = True
        Me.GridView4.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.Empty.Options.UseFont = True
        Me.GridView4.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.EvenRow.Options.UseFont = True
        Me.GridView4.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView4.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView4.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FixedLine.Options.UseFont = True
        Me.GridView4.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.GridView4.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.FocusedCell.Options.UseBackColor = True
        Me.GridView4.Appearance.FocusedCell.Options.UseForeColor = True
        Me.GridView4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView4.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView4.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView4.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupButton.Options.UseFont = True
        Me.GridView4.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView4.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView4.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.GroupRow.Options.UseFont = True
        Me.GridView4.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView4.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView4.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView4.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView4.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView4.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView4.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.HorzLine.Options.UseFont = True
        Me.GridView4.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.OddRow.Options.UseFont = True
        Me.GridView4.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.Preview.Options.UseFont = True
        Me.GridView4.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.Row.Options.UseFont = True
        Me.GridView4.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView4.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView4.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView4.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView4.Appearance.TopNewRow.BackColor = System.Drawing.Color.LemonChiffon
        Me.GridView4.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.TopNewRow.ForeColor = System.Drawing.Color.Black
        Me.GridView4.Appearance.TopNewRow.Options.UseBackColor = True
        Me.GridView4.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView4.Appearance.TopNewRow.Options.UseForeColor = True
        Me.GridView4.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.VertLine.Options.UseFont = True
        Me.GridView4.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView4.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView4.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grColMaHang, Me.grdColSoLuong, Me.grdColDonGia, Me.grdcolThanhTien})
        Me.GridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView4.GridControl = Me.grdChiTietChungTu
        Me.GridView4.Name = "GridView4"
        Me.GridView4.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.[True]
        Me.GridView4.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.[False]
        Me.GridView4.OptionsBehavior.AllowIncrementalSearch = True
        Me.GridView4.OptionsBehavior.AutoExpandAllGroups = True
        Me.GridView4.OptionsBehavior.AutoPopulateColumns = False
        Me.GridView4.OptionsBehavior.FocusLeaveOnTab = True
        Me.GridView4.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView4.OptionsNavigation.AutoFocusNewRow = True
        Me.GridView4.OptionsNavigation.EnterMoveNextColumn = True
        Me.GridView4.OptionsPrint.AutoWidth = False
        Me.GridView4.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView4.OptionsView.EnableAppearanceEvenRow = True
        Me.GridView4.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top
        '
        'grColMaHang
        '
        Me.grColMaHang.Caption = "MaHang"
        Me.grColMaHang.FieldName = "MaHang"
        Me.grColMaHang.Name = "grColMaHang"
        Me.grColMaHang.Visible = True
        Me.grColMaHang.VisibleIndex = 0
        Me.grColMaHang.Width = 260
        '
        'grdColSoLuong
        '
        Me.grdColSoLuong.Caption = "SoLuong"
        Me.grdColSoLuong.FieldName = "SoLuong"
        Me.grdColSoLuong.Name = "grdColSoLuong"
        Me.grdColSoLuong.Visible = True
        Me.grdColSoLuong.VisibleIndex = 1
        Me.grdColSoLuong.Width = 265
        '
        'grdColDonGia
        '
        Me.grdColDonGia.Caption = "DonGia"
        Me.grdColDonGia.FieldName = "DonGia"
        Me.grdColDonGia.Name = "grdColDonGia"
        Me.grdColDonGia.Visible = True
        Me.grdColDonGia.VisibleIndex = 2
        '
        'grdcolThanhTien
        '
        Me.grdcolThanhTien.Caption = "ThanhTien"
        Me.grdcolThanhTien.FieldName = "ThanhTien"
        Me.grdcolThanhTien.Name = "grdcolThanhTien"
        Me.grdcolThanhTien.Visible = True
        Me.grdcolThanhTien.VisibleIndex = 3
        '
        'LoaiChungTu
        '
        Me.LoaiChungTu.AllowNoSourceText = True
        Me.LoaiChungTu.AllowNULL = True
        Me.LoaiChungTu.ColumnWidths = New Integer() {-1}
        Me.LoaiChungTu.CreateDefaultColCodeColumn = False
        Me.LoaiChungTu.CreateDefaultColNameColumn = False
        Me.LoaiChungTu.EnterMoveNextControl = True
        Me.LoaiChungTu.ForceRelateControlOnLeave = True
        Me.LoaiChungTu.HasFilterRow = True
        Me.LoaiChungTu.IsChange = False
        Me.LoaiChungTu.IsFirstInPair = False
        Me.LoaiChungTu.Location = New System.Drawing.Point(404, 9)
        Me.LoaiChungTu.MyAutoFormat = False
        Me.LoaiChungTu.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.LoaiChungTu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.LoaiChungTu.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.LoaiChungTu.MyFocusForeColor = System.Drawing.Color.Black
        Me.LoaiChungTu.MyRelateControl = Nothing
        Me.LoaiChungTu.MyTag01 = Nothing
        Me.LoaiChungTu.MyTag02 = Nothing
        Me.LoaiChungTu.MyTag03 = Nothing
        Me.LoaiChungTu.MyTextControl = Nothing
        Me.LoaiChungTu.Name = "LoaiChungTu"
        Me.LoaiChungTu.Properties.AllowNoSourceText = True
        Me.LoaiChungTu.Properties.AllowNULL = True
        Me.LoaiChungTu.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.LoaiChungTu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LoaiChungTu.Properties.Appearance.Options.UseFont = True
        Me.LoaiChungTu.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LoaiChungTu.Properties.AppearanceDisabled.Options.UseFont = True
        Me.LoaiChungTu.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LoaiChungTu.Properties.AppearanceDropDown.Options.UseFont = True
        Me.LoaiChungTu.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LoaiChungTu.Properties.AppearanceFocused.Options.UseFont = True
        Me.LoaiChungTu.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LoaiChungTu.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.LoaiChungTu.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.LoaiChungTu.Properties.ColumnWidths = New Integer() {-1}
        Me.LoaiChungTu.Properties.CreateDefaultColCodeColumn = False
        Me.LoaiChungTu.Properties.CreateDefaultColNameColumn = False
        Me.LoaiChungTu.Properties.DisplayMember = "LoaiChungTu"
        Me.LoaiChungTu.Properties.EditValue = Nothing
        Me.LoaiChungTu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LoaiChungTu.Properties.HasFilterRow = True
        Me.LoaiChungTu.Properties.IsChange = False
        Me.LoaiChungTu.Properties.MyAutoFormat = False
        Me.LoaiChungTu.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.LoaiChungTu.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.LoaiChungTu.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.LoaiChungTu.Properties.MyTextControl = Nothing
        Me.LoaiChungTu.Properties.NullText = ""
        Me.LoaiChungTu.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.LoaiChungTu.Properties.PopupSizeable = False
        Me.LoaiChungTu.Properties.ShowFooter = False
        Me.LoaiChungTu.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.LoaiChungTu.Properties.ValidateOnEnterKey = True
        Me.LoaiChungTu.Properties.ValueMember = "LoaiChungTu"
        Me.LoaiChungTu.Properties.View = Me.GridView5
        Me.LoaiChungTu.Size = New System.Drawing.Size(189, 21)
        Me.LoaiChungTu.TabIndex = 41
        '
        'GridView5
        '
        Me.GridView5.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView5.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView5.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView5.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.DetailTip.Options.UseFont = True
        Me.GridView5.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.Empty.Options.UseFont = True
        Me.GridView5.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.EvenRow.Options.UseFont = True
        Me.GridView5.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView5.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView5.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.FixedLine.Options.UseFont = True
        Me.GridView5.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView5.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView5.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView5.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView5.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView5.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView5.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView5.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.GroupButton.Options.UseFont = True
        Me.GridView5.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView5.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView5.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.GroupRow.Options.UseFont = True
        Me.GridView5.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView5.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView5.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView5.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView5.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView5.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView5.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView5.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView5.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.HorzLine.Options.UseFont = True
        Me.GridView5.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.OddRow.Options.UseFont = True
        Me.GridView5.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.Preview.Options.UseFont = True
        Me.GridView5.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.Row.Options.UseFont = True
        Me.GridView5.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView5.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView5.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView5.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView5.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView5.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView5.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView5.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.VertLine.Options.UseFont = True
        Me.GridView5.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView5.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView5.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColLoaiChungTu})
        Me.GridView5.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView5.Name = "GridView5"
        Me.GridView5.OptionsBehavior.Editable = False
        Me.GridView5.OptionsBehavior.ReadOnly = True
        Me.GridView5.OptionsCustomization.AllowColumnMoving = False
        Me.GridView5.OptionsCustomization.AllowColumnResizing = False
        Me.GridView5.OptionsCustomization.AllowGroup = False
        Me.GridView5.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView5.OptionsMenu.EnableColumnMenu = False
        Me.GridView5.OptionsMenu.EnableFooterMenu = False
        Me.GridView5.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView5.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView5.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView5.OptionsView.ColumnAutoWidth = False
        Me.GridView5.OptionsView.ShowAutoFilterRow = True
        Me.GridView5.OptionsView.ShowColumnHeaders = False
        Me.GridView5.OptionsView.ShowGroupPanel = False
        Me.GridView5.OptionsView.ShowIndicator = False
        '
        'grdColLoaiChungTu
        '
        Me.grdColLoaiChungTu.Caption = "LoaiChungTu"
        Me.grdColLoaiChungTu.FieldName = "LoaiChungTu"
        Me.grdColLoaiChungTu.Name = "grdColLoaiChungTu"
        Me.grdColLoaiChungTu.Visible = True
        Me.grdColLoaiChungTu.VisibleIndex = 0
        '
        'frmENT_ChungTu_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(926, 527)
        Me.Controls.Add(Me.LoaiChungTu)
        Me.Controls.Add(Me.grdChiTietChungTu)
        Me.Controls.Add(Me.NgayLap)
        Me.Controls.Add(Me.MaKho)
        Me.Controls.Add(Me.MaKhoNhan)
        Me.Controls.Add(Me.MaKhoChuyen)
        Me.Controls.Add(Me.MaKH)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblSDT)
        Me.Controls.Add(Me.lblNgayLap)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.SoChungTu)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblLoaiChungTu)
        Me.Controls.Add(Me.lblSoChungTu)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmENT_ChungTu_Input"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Text = "frmENT_Kho_Input"
        Me.Controls.SetChildIndex(Me.lblSoChungTu, 0)
        Me.Controls.SetChildIndex(Me.grUpdateInfor, 0)
        Me.Controls.SetChildIndex(Me.cmdSaveAndClose, 0)
        Me.Controls.SetChildIndex(Me.cmdSave, 0)
        Me.Controls.SetChildIndex(Me.cmdExit, 0)
        Me.Controls.SetChildIndex(Me.lblLoaiChungTu, 0)
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.SoChungTu, 0)
        Me.Controls.SetChildIndex(Me.txtGhiChu, 0)
        Me.Controls.SetChildIndex(Me.lblNgayLap, 0)
        Me.Controls.SetChildIndex(Me.lblSDT, 0)
        Me.Controls.SetChildIndex(Me.Label1, 0)
        Me.Controls.SetChildIndex(Me.Label2, 0)
        Me.Controls.SetChildIndex(Me.Label4, 0)
        Me.Controls.SetChildIndex(Me.MaKH, 0)
        Me.Controls.SetChildIndex(Me.MaKhoChuyen, 0)
        Me.Controls.SetChildIndex(Me.MaKhoNhan, 0)
        Me.Controls.SetChildIndex(Me.MaKho, 0)
        Me.Controls.SetChildIndex(Me.NgayLap, 0)
        Me.Controls.SetChildIndex(Me.grdChiTietChungTu, 0)
        Me.Controls.SetChildIndex(Me.LoaiChungTu, 0)
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SoChungTu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKhoNhan.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKhoChuyen.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NgayLap.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdChiTietChungTu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LoaiChungTu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblSoChungTu As HTLFW.Label
    Friend WithEvents lblLoaiChungTu As HTLFW.Label
    Friend WithEvents Label3 As HTLFW.Label
    Friend WithEvents SoChungTu As HTLFW.UCTextEdit
    Friend WithEvents txtGhiChu As HTLFW.UCTextEdit
    Friend WithEvents lblNgayLap As HTLFW.Label
    Friend WithEvents lblSDT As HTLFW.Label
    Friend WithEvents Label1 As HTLFW.Label
    Friend WithEvents Label2 As HTLFW.Label
    Friend WithEvents Label4 As HTLFW.Label
    Friend WithEvents MaKH As HTLFW.UCGridLookUpEdit
    Friend WithEvents UcGridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents MaKhoNhan As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents MaKhoChuyen As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents MaKho As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents grdColMaKH As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColTenKH As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColMaKho As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColTenKho As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents NgayLap As HTLFW.UCTextEdit
    Friend WithEvents grdChiTietChungTu As HTLFW.UCGridControl
    Friend WithEvents GridView4 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents grColMaHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColSoLuong As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColDonGia As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdcolThanhTien As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColMaKhoNhan As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColTenKhoNhan As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn1 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn2 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents LoaiChungTu As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView5 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents grdColLoaiChungTu As DevExpress.XtraGrid.Columns.GridColumn
End Class
