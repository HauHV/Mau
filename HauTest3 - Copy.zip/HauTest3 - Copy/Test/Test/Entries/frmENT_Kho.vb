﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports HTLFW.HTLLib.HTLStringFuncs
Imports HTLFW.HTLLib.HTLLayoutDefinition
Imports DBs
Imports AppRoot
'Imports AppRoot.AppVars

#End Region

Public Class frmENT_Kho

#Region "Declares"
    'Private MyObjectType As String = "NV_BANGCAP"
    Private DataSourceTableName As String = "Kho"
    Private IsRunning As Boolean = False
    Private _Condition As String = ""

#End Region

#Region "Constructors"

    Public Sub New()
        InitializeComponent()
        PrimaryKey.Add(New ListKeyValues.KeyValueObj("MaKho"))
        MyGridControl = gcData
        MyGridView = gvData
        ShowContextMenu = True
    End Sub
   
#End Region

#Region "Overrides"

    Public Overrides Sub RefreshSourceString()
        Dim mWhere As String = _Condition
        'If Not chkNoWork.Checked Then
        '    Me.SourceString = "SELECT * FROM datv_DataEM_BangCap " & If(mWhere <> "", " WHERE " & mWhere, "")
        'Else
        Me.SourceString = "SELECT * FROM Kho " & If(mWhere <> "", " WHERE " & mWhere, "")
        'End If
    End Sub

    Public Overrides Sub RefreshData()
        If Me.InvokeRequired Then
            Invoke(New frmUsers.Delegate_RefreshData(AddressOf RefreshData))
        Else
            If DesignMode Then Exit Sub
            If Me.IsDisposed OrElse Me.Disposing Then Exit Sub
            'If Not IsHandleCreated Then Exit Sub
            If Not AppIsReady() Then Exit Sub
            If IsRunning Then Exit Sub
            IsRunning = True
            If Not FirstLoad Then AppDevWaitingForm.Show()
            RefreshSourceString()
            MyDataTable.Release()
            MyDataTable = GetDataTable(SourceString)
            MyBase.RefreshData()
            If Not MyDataTable.IsNoData AndAlso MyDataTable.Rows.Count <= 1000 Then
                For Each mColumn As DevExpress.XtraGrid.Columns.GridColumn In gvData.Columns
                    mColumn.Width = mColumn.GetBestWidth + 5
                Next
            End If
            IsRunning = False
            If Not FirstLoad Then AppDevWaitingForm.Hide()
        End If
    End Sub

    Delegate Sub Delegate_RefreshData_WithKey(ByVal pPrimaryKey As HTLFW.ListKeyValues)
    Public Overrides Sub RefreshData(ByVal pPrimaryKey As HTLFW.ListKeyValues)
        If Me.InvokeRequired Then
            Invoke(New Delegate_RefreshData_WithKey(AddressOf RefreshData), pPrimaryKey)
        Else
            If DesignMode Then Exit Sub
            If Me.IsDisposed OrElse Me.Disposing Then Exit Sub
            'If Not IsHandleCreated Then Exit Sub
            If Not AppIsReady() Then Exit Sub
            If IsRunning Then Exit Sub
            IsRunning = True
            RefreshSourceString()
            MyDataTable.Release()
            MyDataTable = GetDataTable(SourceString)
            MyBase.RefreshData(pPrimaryKey)
            'If Not MyDataTable.IsNoData AndAlso MyDataTable.Rows.Count <= 1000 Then
            '    For Each mColumn As DevExpress.XtraGrid.Columns.GridColumn In gvData.Columns
            '        mColumn.Width = mColumn.GetBestWidth + 5
            '    Next
            'End If
            IsRunning = False
        End If
    End Sub

    Public Overrides Sub RefreshPrimaryKeyValue()
        PrimaryKey.KeyValue("MaKho") = MaKho()
    End Sub

#End Region

#Region "Events"
    Private Sub Process_InputForm_NeedRefreshData()
        FirstLoad = True
        RefreshData()
        FirstLoad = False
        'CatchRelateChanged(Me)
        'SendRequestToServer(FunctionID)
    End Sub
    Private Sub Process_InputForm_NeedRefreshData(ByVal pKey As ListKeyValues)
        FirstLoad = True
        If Not pKey Is Nothing Then
            RefreshData(pKey)
        Else
            RefreshData()
        End If
        FirstLoad = False
        'CatchRelateChanged(Me)
        'SendRequestToServer(FunctionID)
    End Sub
    Private Sub Me_NeedDataAdd() Handles Me.NeedDataAdd
        Try
            AppDevWaitingForm.Show()
            Using mForm As New frmENT_Kho_Input(eFormMode.Add, PrimaryKey.ResetValue)
                AddHandler mForm.NeedRefreshData, AddressOf Process_InputForm_NeedRefreshData
                mForm.FunctionID = FunctionID
                mForm.ShowDialog(Me)
                mForm.Release()
            End Using
            AppDevWaitingForm.Hide()
        Catch ex As Exception
            ShowUnknownError(ex.Message)
        End Try
    End Sub
    Private Sub Me_NeedDataDelete() Handles Me.NeedDataDelete
        Try
            AppDevWaitingForm.Show()

            RefreshPrimaryKeyValue()

            ' Giữ DBContext
            Dim mDBContext = DBContextCreateNew()
            mDBContext.TransactionStart()

            ' Kiểm tra record cần xóa còn tồn tại không
            Dim mCurObject = mDBContext.Khos.FirstOrDefault(Function(pp) pp.MaKho.Equals(MaKho))
            If mCurObject Is Nothing Then
                mDBContext.TransactionRollback()
                mDBContext.Release()
                ShowError(HTLFW.My.Resources.MessageContent.infoErrorSaveFailedMissing, HTLFW.My.Resources.MessageContent.MSGTitleGeneralValidData)
                RefreshData()
                Exit Sub
                
            End If

            ' Xác nhận với User xóa record
            If ShowConfirmDelete2(grdColMaKho.Caption, MaKho, grdColTenKho.Caption, TenKho) = Windows.Forms.DialogResult.No Then
                mDBContext.TransactionRollback()
                mDBContext.Release()
                mCurObject = Nothing
                Exit Sub
            End If

            Try
                mDBContext.Khos.DeleteOnSubmit(mCurObject)
                mDBContext.SubmitChanges()
                ' Cập nhật history
                mDBContext.AppendToAppHistory("DELETE " + DataSourceTableName, "MaKho=[" + Nz(mCurObject.MaKho, "") + "]")
            Catch ex As Exception
                mDBContext.TransactionRollback()
                mDBContext.Release()
                mCurObject = Nothing
                ShowUnknownError(ex.Message)
                RefreshData()
                Exit Sub
            End Try
            mDBContext.TransactionCommit()
            mDBContext.Release()
            mCurObject = Nothing

            'CatchRelateChanged(Me)
            'SendRequestToServer(FunctionID)

            ' Refresh dữ liệu danh sách
            RefreshData()

            AppDevWaitingForm.Hide()
        Catch ex As Exception
            ShowUnknownError(ex.Message)
        End Try
    End Sub

    Private Sub Me_NeedDataEdit() Handles Me.NeedDataEdit
        Try
            AppDevWaitingForm.Show()

            RefreshPrimaryKeyValue()

            'Kiểm tra record hiện hành có dữ liệu hay không
            If MaKho() Is Nothing Then
                ShowNoData()
                Exit Sub
            End If

            ' Giữ DBContext
            Dim mDBContext = DBContextCreateNew()
            mDBContext.TransactionStart()

            ' Kiểm tra record cần sửa được phép sửa hay không
            Dim mCurObject As Kho = mDBContext.Khos.FirstOrDefault(Function(pp) pp.MaKho.Equals(MaKho))
            If mCurObject Is Nothing Then
                mDBContext.TransactionRollback()
                mDBContext.Release()
                ShowError(HTLFW.My.Resources.MessageContent.infoErrorSaveFailedMissing, HTLFW.My.Resources.MessageContent.MSGTitleGeneralValidData)
                RefreshData()
                Exit Sub
               
            End If

            'Try
            '    mDBContext.SubmitChanges()
            'Catch ex As Exception
            '    mDBContext.TransactionRollback()
            '    mDBContext.Release()
            '    mCurObject = Nothing
            '    ShowUnknownError(ex.Message)
            '    RefreshData()
            '    Exit Sub
            'End Try

            'mDBContext.TransactionCommit()
            mCurObject = Nothing

            Dim mAllowCodeChange As Boolean = True
            'mAllowCodeChange = If(mDBContext.COM_fGETBIT_ObjectModifyDelete(MyObjectType, TenBangCap).FirstOrDefault() Is Nothing, True, False)
            mDBContext.Release()

            Dim mForm As New frmENT_Kho_Input(eFormMode.Modify, PrimaryKey, mAllowCodeChange)
            AddHandler mForm.NeedRefreshData, AddressOf Process_InputForm_NeedRefreshData
            mForm.FunctionID = FunctionID
            mForm.ShowDialog(Me)

            mForm.Release()

            AppDevWaitingForm.Hide()
        Catch ex As Exception
            ShowUnknownError(ex.Message)
        End Try
    End Sub

    Private Sub Me_NeedDataExportExcel() Handles Me.NeedDataExportExcel
        Try
            AppDevWaitingForm.Show()
            HTLLib.HTLComFuncs.DataExcelByGrid(MyGridView, Text)
            AppDevWaitingForm.Hide()
        Catch ex As Exception
            ShowUnknownError(ex.Message)
        End Try
    End Sub

    Private Sub Me_NeedDataView() Handles Me.NeedDataView
        Try
            RefreshPrimaryKeyValue()
            ' Kiểm tra record hiện hành có dữ liệu hay không
            If MaKho() Is Nothing Then
                ShowNoData()
                Exit Sub
            End If
            AppDevWaitingForm.Show()
            Using mForm As New frmENT_Kho_Input(eFormMode.View, PrimaryKey)
                mForm.FunctionID = FunctionID
                mForm.ShowDialog(Me)
                mForm.Release()
            End Using
            AppDevWaitingForm.Hide()
        Catch ex As Exception
            ShowUnknownError(ex.Message)
        End Try
    End Sub
#End Region

#Region "Functions"
    Public Overridable Function ID() As Decimal
        If MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.NewItemRowHandle Or MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.AutoFilterRowHandle Or MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.InvalidRowHandle Then
            Return 0
        Else
            Try
                Return CType(MyGridView.GetRowCellValue(MyGridView.FocusedRowHandle, "ID"), Decimal)
            Catch ex As Exception
                Return 0
            End Try
        End If
    End Function
    Public Overridable Function MaKho() As String
        If MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.NewItemRowHandle Or MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.AutoFilterRowHandle Or MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.InvalidRowHandle Then
            Return ""
        Else
            Try
                Return Nz(MyGridView.GetRowCellValue(MyGridView.FocusedRowHandle, "MaKho"), "").ToString
            Catch ex As Exception
                Return ""
            End Try
        End If
    End Function
    Public Overridable Function TenKho() As String
        If MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.NewItemRowHandle Or MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.AutoFilterRowHandle Or MyGridView.FocusedRowHandle = DevExpress.XtraGrid.GridControl.InvalidRowHandle Then
            Return ""
        Else
            Try
                Return Nz(MyGridView.GetRowCellValue(MyGridView.FocusedRowHandle, "TenKho"), "").ToString
            Catch ex As Exception
                Return ""
            End Try
        End If
    End Function
#End Region

#Region "Control events"

    'Private Sub UcHRConditionPicker_ForListData_ConditionsSQLChanged(ByVal pSQL As String) Handles UcHRConditionPicker_ForListData1.ConditionsSQLChanged, UcHRConditionPicker_ForListData1.ConditionsSQLChangedForcedApply
    '    _Condition = pSQL
    '    RefreshData()
    'End Sub

    'Private Sub chkNoWork_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNoWork.CheckedChanged
    '    If DesignMode Then Exit Sub
    '    If Me.IsDisposed OrElse Me.Disposing Then Exit Sub
    '    'If Not IsHandleCreated Then Exit Sub
    '    If Not AppIsReady() Then Exit Sub
    '    RefreshData()
    'End Sub

    'Private Sub gvData_CustomColumnSort(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Base.CustomColumnSortEventArgs)
    '    Try
    '        If e.Column.FieldName = "EMFullName" Then
    '            Dim dr1 As DataRowView = (TryCast(gvData.DataSource, DataView))(e.ListSourceRowIndex1)
    '            Dim dr2 As DataRowView = (TryCast(gvData.DataSource, DataView))(e.ListSourceRowIndex2)
    '            e.Handled = True
    '            e.Result = System.Collections.Comparer.Default.Compare(dr1("EMFullNameSort"), dr2("EMFullNameSort"))
    '        End If
    '    Catch ex As Exception
    '    End Try
    'End Sub

#End Region

End Class