﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmENT_Hang
    Inherits AppRoot.frmBaseList

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gcData = New HTLFW.UCGridControl
        Me.gvData = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColSTT = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColMaHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColTenHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColDVT = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColSoLuongTonMin = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColSoLuongTonMax = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColGhiChu = New DevExpress.XtraGrid.Columns.GridColumn
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gcData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        '
        'cmdModify
        '
        Me.HelpProvider.SetShowHelp(Me.cmdModify, True)
        '
        'cmdDelete
        '
        Me.HelpProvider.SetShowHelp(Me.cmdDelete, True)
        '
        'cmdAdd
        '
        Me.HelpProvider.SetShowHelp(Me.cmdAdd, True)
        '
        'cmdView
        '
        Me.HelpProvider.SetShowHelp(Me.cmdView, True)
        '
        'cmdExcel
        '
        Me.HelpProvider.SetShowHelp(Me.cmdExcel, True)
        '
        'gcData
        '
        Me.gcData.AllowCommandDelete = True
        Me.gcData.AllowCommandModify = True
        Me.gcData.AllowCommandView = True
        Me.gcData.AllowContextMenu = True
        Me.gcData.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gcData.AutoFocusToNewRow = True
        Me.gcData.EnableCommandDelete = True
        Me.gcData.EnableCommandModify = True
        Me.gcData.EnableCommandView = True
        Me.gcData.Location = New System.Drawing.Point(0, 0)
        Me.gcData.MainView = Me.gvData
        Me.gcData.MyAutoFormat = False
        Me.gcData.MyBoldFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyColorStyle = HTLFW.UCGridControl.eColorStyle.iSale
        Me.gcData.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gcData.MyFocusForeColor = System.Drawing.Color.Black
        Me.gcData.MyItalicFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyMainView = Me.gvData
        Me.gcData.MyNewRowBackColor = System.Drawing.Color.LemonChiffon
        Me.gcData.MyNewRowForeColor = System.Drawing.Color.Black
        Me.gcData.MyNormalFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyOrdSource = HTLFW.UCGridControl.eOrdSource.RowHandle
        Me.gcData.MyShowDateCreatedColumn = False
        Me.gcData.MyShowDateModifiedColumn = False
        Me.gcData.MyShowDeleteCMD = False
        Me.gcData.MyShowModifyCMD = False
        Me.gcData.MyShowOrderColumn = False
        Me.gcData.MyShowUserCreatedColumn = False
        Me.gcData.MyShowUserModifiedColumn = False
        Me.gcData.MyShowViewCMD = False
        Me.gcData.MyViewType = HTLFW.UCGridControl.eViewType.ReadOnlyView
        Me.gcData.Name = "gcData"
        Me.gcData.ShowFilterRow = False
        Me.gcData.ShowFooter = False
        Me.gcData.ShowGroupPanel = True
        Me.gcData.ShowNewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None
        Me.gcData.Size = New System.Drawing.Size(922, 292)
        Me.gcData.TabIndex = 17
        Me.gcData.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.gvData})
        '
        'gvData
        '
        Me.gvData.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.gvData.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.gvData.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.gvData.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.DetailTip.Options.UseFont = True
        Me.gvData.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.Empty.Options.UseFont = True
        Me.gvData.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.EvenRow.Options.UseFont = True
        Me.gvData.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.FilterCloseButton.Options.UseFont = True
        Me.gvData.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic)
        Me.gvData.Appearance.FilterPanel.Options.UseFont = True
        Me.gvData.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.FixedLine.Options.UseFont = True
        Me.gvData.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.gvData.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.FocusedCell.Options.UseBackColor = True
        Me.gvData.Appearance.FocusedCell.Options.UseForeColor = True
        Me.gvData.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.FocusedRow.Options.UseBackColor = True
        Me.gvData.Appearance.FocusedRow.Options.UseForeColor = True
        Me.gvData.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.gvData.Appearance.FooterPanel.Options.UseFont = True
        Me.gvData.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.gvData.Appearance.GroupButton.Options.UseFont = True
        Me.gvData.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.gvData.Appearance.GroupFooter.Options.UseFont = True
        Me.gvData.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.GroupPanel.Options.UseFont = True
        Me.gvData.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.gvData.Appearance.GroupRow.Options.UseFont = True
        Me.gvData.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.gvData.Appearance.HeaderPanel.Options.UseFont = True
        Me.gvData.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.gvData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.gvData.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.gvData.Appearance.HideSelectionRow.Options.UseFont = True
        Me.gvData.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.gvData.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.HorzLine.Options.UseFont = True
        Me.gvData.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.OddRow.Options.UseFont = True
        Me.gvData.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.Preview.Options.UseFont = True
        Me.gvData.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.Row.Options.UseFont = True
        Me.gvData.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.RowSeparator.Options.UseFont = True
        Me.gvData.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.SelectedRow.Options.UseBackColor = True
        Me.gvData.Appearance.SelectedRow.Options.UseFont = True
        Me.gvData.Appearance.SelectedRow.Options.UseForeColor = True
        Me.gvData.Appearance.TopNewRow.BackColor = System.Drawing.Color.LemonChiffon
        Me.gvData.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic)
        Me.gvData.Appearance.TopNewRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.TopNewRow.Options.UseBackColor = True
        Me.gvData.Appearance.TopNewRow.Options.UseFont = True
        Me.gvData.Appearance.TopNewRow.Options.UseForeColor = True
        Me.gvData.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.VertLine.Options.UseFont = True
        Me.gvData.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.gvData.Appearance.ViewCaption.Options.UseFont = True
        Me.gvData.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColSTT, Me.grdColMaHang, Me.grdColTenHang, Me.grdColDVT, Me.grdColSoLuongTonMin, Me.grdColSoLuongTonMax, Me.grdColGhiChu})
        Me.gvData.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.gvData.GridControl = Me.gcData
        Me.gvData.Name = "gvData"
        Me.gvData.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.[False]
        Me.gvData.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.[False]
        Me.gvData.OptionsBehavior.AllowIncrementalSearch = True
        Me.gvData.OptionsBehavior.AutoExpandAllGroups = True
        Me.gvData.OptionsBehavior.AutoPopulateColumns = False
        Me.gvData.OptionsBehavior.FocusLeaveOnTab = True
        Me.gvData.OptionsBehavior.ReadOnly = True
        Me.gvData.OptionsCustomization.AllowQuickHideColumns = False
        Me.gvData.OptionsNavigation.AutoFocusNewRow = True
        Me.gvData.OptionsNavigation.EnterMoveNextColumn = True
        Me.gvData.OptionsPrint.AutoWidth = False
        Me.gvData.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.gvData.OptionsView.ColumnAutoWidth = False
        Me.gvData.OptionsView.EnableAppearanceEvenRow = True
        '
        'grdColSTT
        '
        Me.grdColSTT.Caption = "#"
        Me.grdColSTT.DisplayFormat.FormatString = "N0"
        Me.grdColSTT.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.grdColSTT.FieldName = "#"
        Me.grdColSTT.Name = "grdColSTT"
        Me.grdColSTT.OptionsColumn.AllowEdit = False
        Me.grdColSTT.OptionsColumn.AllowFocus = False
        Me.grdColSTT.OptionsColumn.AllowGroup = DevExpress.Utils.DefaultBoolean.[False]
        Me.grdColSTT.OptionsColumn.AllowSort = DevExpress.Utils.DefaultBoolean.[False]
        Me.grdColSTT.OptionsColumn.TabStop = False
        Me.grdColSTT.Tag = "SYSCOMMANDROWORDER"
        Me.grdColSTT.UnboundType = DevExpress.Data.UnboundColumnType.[Decimal]
        Me.grdColSTT.Visible = True
        Me.grdColSTT.VisibleIndex = 0
        Me.grdColSTT.Width = 50
        '
        'grdColMaHang
        '
        Me.grdColMaHang.Caption = "MaHang"
        Me.grdColMaHang.FieldName = "MaHang"
        Me.grdColMaHang.Name = "grdColMaHang"
        Me.grdColMaHang.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaHang.Visible = True
        Me.grdColMaHang.VisibleIndex = 1
        Me.grdColMaHang.Width = 158
        '
        'grdColTenHang
        '
        Me.grdColTenHang.Caption = "TenHang"
        Me.grdColTenHang.FieldName = "TenHang"
        Me.grdColTenHang.Name = "grdColTenHang"
        Me.grdColTenHang.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColTenHang.Visible = True
        Me.grdColTenHang.VisibleIndex = 2
        Me.grdColTenHang.Width = 210
        '
        'grdColDVT
        '
        Me.grdColDVT.Caption = "DVT"
        Me.grdColDVT.FieldName = "DVT"
        Me.grdColDVT.Name = "grdColDVT"
        Me.grdColDVT.Visible = True
        Me.grdColDVT.VisibleIndex = 6
        '
        'grdColSoLuongTonMin
        '
        Me.grdColSoLuongTonMin.Caption = "SoLuongTonMin"
        Me.grdColSoLuongTonMin.FieldName = "SoLuongTonMin"
        Me.grdColSoLuongTonMin.Name = "grdColSoLuongTonMin"
        Me.grdColSoLuongTonMin.Visible = True
        Me.grdColSoLuongTonMin.VisibleIndex = 4
        '
        'grdColSoLuongTonMax
        '
        Me.grdColSoLuongTonMax.Caption = "SoLuongTonMax"
        Me.grdColSoLuongTonMax.FieldName = "SoLuongTonMax"
        Me.grdColSoLuongTonMax.Name = "grdColSoLuongTonMax"
        Me.grdColSoLuongTonMax.Visible = True
        Me.grdColSoLuongTonMax.VisibleIndex = 5
        '
        'grdColGhiChu
        '
        Me.grdColGhiChu.Caption = "GhiChu"
        Me.grdColGhiChu.FieldName = "GhiChu"
        Me.grdColGhiChu.Name = "grdColGhiChu"
        Me.grdColGhiChu.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColGhiChu.Visible = True
        Me.grdColGhiChu.VisibleIndex = 3
        Me.grdColGhiChu.Width = 413
        '
        'frmENT_Hang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(922, 333)
        Me.Controls.Add(Me.gcData)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmENT_Hang"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Text = "frmENT_Kho"
        Me.Controls.SetChildIndex(Me.gcData, 0)
        Me.Controls.SetChildIndex(Me.cmdView, 0)
        Me.Controls.SetChildIndex(Me.cmdDelete, 0)
        Me.Controls.SetChildIndex(Me.cmdModify, 0)
        Me.Controls.SetChildIndex(Me.cmdExcel, 0)
        Me.Controls.SetChildIndex(Me.cmdAdd, 0)
        Me.Controls.SetChildIndex(Me.cmdExit, 0)
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gcData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gcData As HTLFW.UCGridControl
    Friend WithEvents gvData As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents grdColMaHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColTenHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColGhiChu As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColSTT As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColDVT As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColSoLuongTonMin As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColSoLuongTonMax As DevExpress.XtraGrid.Columns.GridColumn
End Class
