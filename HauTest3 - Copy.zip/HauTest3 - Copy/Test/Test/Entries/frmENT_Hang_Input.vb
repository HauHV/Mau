﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports HTLFW.HTLLib.HTLStringFuncs
Imports HTLFW.HTLLib.HTLLayoutDefinition
Imports DBs

#End Region
Public Class frmENT_Hang_Input
#Region "Declares"

    Private _NewCodeValue As String = Nothing
    Private DataSourceTableName As String = "HangHoa"
    'Private AutoRefObjectDefined As Boolean = True
    Private MyMaHang As String

#End Region
#Region "Properties"

    Public Overrides Property FormMode() As HTLFW.eFormMode
        Get
            Return MyBase.FormMode
        End Get
        Set(ByVal value As HTLFW.eFormMode)
            MyBase.FormMode = value
            If IsAllVIEWMode() Then
                MaHang.Properties.ReadOnly = True
                MaHang.Enabled = False
                TenHang.Properties.ReadOnly = True
                TenHang.Enabled = False
                DVT.Properties.ReadOnly = True
                DVT.Enabled = False
                TonMin.Properties.ReadOnly = True
                TonMin.Enabled = False
                TonMax.Properties.ReadOnly = True
                TonMax.Enabled = False
                txtGhiChu.Properties.ReadOnly = True
                txtGhiChu.Enabled = False
            End If
        End Set
    End Property

#End Region

#Region "Constructors"

    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pMaHang As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        MyMaHang = pMaHang
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean, ByVal pMaHang As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
        MyMaHang = pMaHang
    End Sub

    Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        ReleaseMemory()
    End Sub

    Private Sub Me_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


#End Region

#Region "Override"

    Public Overrides Function LoadData() As Boolean
        Try
            Select Case FormMode
                Case eFormMode.Modify, eFormMode.View, eFormMode.ModifyAndy, eFormMode.ViewAny
                    Dim mCurrObject = DBContext.HangHoas.FirstOrDefault(Function(pp) pp.MaHang.Equals(PrimaryKey.KeyValue("MaHang")))
                    If mCurrObject Is Nothing Then
                        ResetControls()
                        Return False
                    Else
                        With mCurrObject

                            MaHang.EditValue = .MaHang
                            TenHang.EditValue = .TenHang
                            DVT.EditValue = .DVT
                            TonMin.EditValue = .SoLuongTonMin
                            TonMax.EditValue = .SoLuongTonMax
                            txtGhiChu.EditValue = .GhiChu

                        End With
                    End If
                    mCurrObject = Nothing
                    Return True
                Case Else
                    ResetControls()
                    Return True
            End Select
        Catch ex As Exception
            ShowErrorStop(ex.Message)
            Return False
        End Try

    End Function

    Public Overrides Function InsertData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()
        mDBContext.TransactionStart()

        Dim mNewObject = New HangHoa
        With mNewObject

            .MaHang = Nz(MaHang.EditValue, Nothing)
            .TenHang = Nz(TenHang.EditValue, Nothing)
            .DVT = Nz(DVT.EditValue, Nothing)
            .SoLuongTonMin = Nz(TonMin.EditValue, Nothing)
            .SoLuongTonMax = Nz(TonMax.EditValue, Nothing)
            .GhiChu = Nz(txtGhiChu.EditValue, Nothing)

        End With
        Try
            mDBContext.HangHoas.InsertOnSubmit(mNewObject)
            mDBContext.SubmitChanges()
        Catch ex As Exception
            mDBContext.TransactionRollback()
            mDBContext.Release()
            mNewObject = Nothing
            ShowUnknownError(ex.Message)
            Return False
        End Try

        mDBContext.AppendToAppHistory("ADDNEW " + DataSourceTableName, "MaHang=[" + mNewObject.MaHang + "] | TenHang=[" + Nz(mNewObject.TenHang, ""))

        mDBContext.TransactionCommit()
        mDBContext.Release()

        PrimaryKey.KeyValue("MaHang") = mNewObject.MaHang

        mNewObject = Nothing

        ResetControls()

        FillCombosData()

        Return True
    End Function

    Public Overrides Function SaveData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()

        mDBContext.TransactionStart()

        Dim mModifyObject = mDBContext.HangHoas.FirstOrDefault(Function(pp) pp.MaHang.Equals(MaHang.EditValue))
        If mModifyObject Is Nothing Then
            mDBContext.TransactionRollback()
            mDBContext.Release()
            ShowErrorStop(HTLFW.My.Resources.MessageContent.infoErrorSaveFailedMissing)
            Return False
        Else
            With mModifyObject

                .MaHang = Nz(MaHang.EditValue, Nothing)
                .TenHang = Nz(TenHang.EditValue, Nothing)
                .DVT = Nz(DVT.EditValue, Nothing)
                .SoLuongTonMin = Nz(TonMin.EditValue, Nothing)
                .SoLuongTonMax = Nz(TonMax.EditValue, Nothing)
                .GhiChu = Nz(txtGhiChu.EditValue, Nothing)
            End With
            Try
                mDBContext.SubmitChanges()
            Catch ex As Exception
                mDBContext.TransactionRollback()
                mDBContext.Release()
                mModifyObject = Nothing
                ShowUnknownError(ex.Message)
                Return False
            End Try

            mDBContext.AppendToAppHistory("MODIFY " + DataSourceTableName, "MaHang=[" + PrimaryKey.KeyValue("MaHang") + "]->[" + mModifyObject.MaHang + "] | TenHang=[" + Nz(PrimaryKey.KeyValue("TenHang"), "") + "]->[" + Nz(mModifyObject.TenHang, ""))

            PrimaryKey.KeyValue("MaHang") = mModifyObject.MaHang

            mDBContext.TransactionCommit()
            mDBContext.Release()
            mModifyObject = Nothing

            Return True
        End If

    End Function

    'Public Overrides Sub FillCombosData()
    '    FillCombosData_MaKho()
    '    FillCombosData_TenKho()
    'End Sub

#End Region

#Region "ValidData"

    Private Function DataIsOK() As Boolean
        RefreshErrors()
        Dim mTam As String = ""
        For Each mControl As DevExpress.XtraEditors.BaseEdit In Me.Controls.OfType(Of DevExpress.XtraEditors.BaseEdit)().OrderBy(Function(pp) pp.TabIndex).ToList
            mTam = DxError.GetError(mControl)
            If mTam <> "" Then
                ShowErrorStop(mTam)
                mControl.Focus()
                Return False
            End If
        Next
        Return True
    End Function
    Private Sub ResetErrors()
        For Each mControl In Me.Controls
            DxError.SetError(mControl, "")
        Next
    End Sub
    Private Sub RefreshErrors()
        ResetErrors()
        If IsNoValue(MaHang.EditValue) Then
            DxError.SetError(MaHang, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblMaHang.UniText}))
        End If
        If IsNoValue(TenHang.EditValue) Then
            DxError.SetError(TenHang, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblTenHang.UniText}))
        End If

    End Sub

#End Region

#Region "Subs"

    Private Sub ResetControls()

        MaHang.EditValue = Nothing
        TenHang.EditValue = Nothing
        DVT.EditValue = "Cái"
        txtGhiChu.EditValue = Nothing

        MaHang.Focus()
    End Sub

#End Region

#Region "Controls Events"


#End Region

End Class