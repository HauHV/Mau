﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports HTLFW.HTLLib.HTLStringFuncs
Imports HTLFW.HTLLib.HTLLayoutDefinition
Imports DBs

#End Region
Public Class frmENT_ChungTu_Input

#Region "Declares"

    Private _NewCodeValue As String = Nothing
    Private DataSourceTableName As String = "ChungTu"
    'Private AutoRefObjectDefined As Boolean = True
    Private MySoChungTu As String

    Private tblData As DataTable

#End Region

#Region "Properties"

    Public Overrides Property FormMode() As HTLFW.eFormMode
        Get
            Return MyBase.FormMode
        End Get
        Set(ByVal value As HTLFW.eFormMode)
            MyBase.FormMode = value
            If IsAllVIEWMode() Then
                SoChungTu.Properties.ReadOnly = True
                SoChungTu.Enabled = False
                LoaiChungTu.Properties.ReadOnly = True
                LoaiChungTu.Enabled = False
                NgayLap.Properties.ReadOnly = True
                NgayLap.Enabled = False
                MaKH.Properties.ReadOnly = True
                MaKH.Enabled = False
                MaKho.Properties.ReadOnly = True
                MaKho.Enabled = False
                MaKhoNhan.Properties.ReadOnly = True
                MaKhoNhan.Enabled = False
                MaKhoChuyen.Properties.ReadOnly = True
                MaKhoChuyen.Enabled = False
                txtGhiChu.Properties.ReadOnly = True
                txtGhiChu.Enabled = False
            End If
        End Set
    End Property

#End Region

#Region "Constructors"

    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pSoChungTu As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        MySoChungTu = pSoChungTu
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean, ByVal pSoChungTu As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
        MySoChungTu = pSoChungTu
    End Sub

    Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        ReleaseMemory()
    End Sub

    Private Sub Me_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


#End Region

#Region "Override"

    Public Overrides Function LoadData() As Boolean
        
        Try
            Select Case FormMode
                Case eFormMode.Modify, eFormMode.View, eFormMode.ModifyAndy, eFormMode.ViewAny
                    Dim mCurrObject = DBContext.ChungTus.FirstOrDefault(Function(pp) pp.SoChungTu.Equals(PrimaryKey.KeyValue("SochungTu")))
                    If mCurrObject Is Nothing Then
                        ResetControls()
                        Return False
                    Else
                        With mCurrObject

                            SoChungTu.EditValue = .SoChungTu
                            LoaiChungTu.EditValue = .LoaiChungTu
                            NgayLap.EditValue = .NgayLap
                            MaKH.EditValue = .MaKH
                            MaKho.EditValue = .MaKho
                            MaKhoNhan.EditValue = .MaKhoNhan
                            MaKhoChuyen.EditValue = .MaKhoChuyen
                            txtGhiChu.EditValue = .Ghichu

                        End With

                        tblData.Release()
                        tblData = GetEditableDataTable("select * from ChiTietChungTu WHERE SoChungTu=N'" & mCurrObject.SoChungTu & "'")
                        grdChiTietChungTu.DataSource = tblData
                        If Not tblData.IsNoData AndAlso tblData.Rows.Count <= 1000 Then
                            For Each mColumn As DevExpress.XtraGrid.Columns.GridColumn In GridView4.Columns
                                mColumn.Width = mColumn.GetBestWidth + 5
                            Next
                        End If
                    End If
                    mCurrObject = Nothing
                    Return True
                Case Else
                    ResetControls()
                    Return True
            End Select
        Catch ex As Exception
            ShowErrorStop(ex.Message)
            Return False
        End Try

    End Function

    Public Overrides Function InsertData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()
        mDBContext.TransactionStart()

        Dim mNewObject = New ChungTu
        With mNewObject

            .SoChungTu = Nz(SoChungTu.EditValue, Nothing)
            .LoaiChungTu = Nz(LoaiChungTu.EditValue, Nothing)
            .NgayLap = Nz(NgayLap.EditValue, Nothing)
            .MaKH = Nz(MaKH.EditValue, Nothing)
            .MaKho = Nz(MaKho.EditValue, Nothing)
            .MaKhoNhan = Nz(MaKhoNhan.EditValue, Nothing)
            .MaKhoChuyen = Nz(MaKhoChuyen.EditValue, Nothing)
            .Ghichu = Nz(txtGhiChu.EditValue, Nothing)

        End With

        Dim mNewDetailObjects = New List(Of ChiTietChungTu)
        For Each mRow As DataRow In tblData.Rows
            Dim mNewDetailObject = New ChiTietChungTu
            With mNewDetailObject
                .SoChungTu = Nz(SoChungTu.EditValue, Nothing)
                .MaHang = Nz(mRow.Item("MaHang"), Nothing)
                .SoLuong = Nz(mRow.Item("SoLuong"), Nothing)
                .DonGia = Nz(mRow.Item("DonGia"), Nothing)
                .ThanhTien = Nz(mRow.Item("ThanhTien"), Nothing)
                .ThanhTienVon = Nz(mRow.Item("ThanhTienVon"), Nothing)
            End With
            mNewDetailObjects.Add(mNewDetailObject)
        Next

        Try
            mDBContext.ChungTus.InsertOnSubmit(mNewObject)
            mDBContext.ChiTietChungTus.InsertAllOnSubmit(mNewDetailObjects)
            mDBContext.SubmitChanges()
        Catch ex As Exception
            mDBContext.TransactionRollback()
            mDBContext.Release()
            mNewObject = Nothing
            ShowUnknownError(ex.Message)
            Return False
        End Try

        mDBContext.AppendToAppHistory("ADDNEW " + DataSourceTableName, "SoChungTu=[" + mNewObject.SoChungTu + "] | LoaiChungTu=[" + Nz(mNewObject.LoaiChungTu, ""))

        mDBContext.TransactionCommit()
        mDBContext.Release()

        PrimaryKey.KeyValue("SoChungTu") = mNewObject.SoChungTu

        mNewObject = Nothing

        ResetControls()

        FillCombosData()

        Return True
    End Function

    Public Overrides Function SaveData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()

        mDBContext.TransactionStart()

        If PrimaryKey.KeyValue("SoChungTu") <> SoChungTu.EditValue Then
            Try
                mDBContext.ExecuteCommand("UPDATE " + DataSourceTableName + " SET SoChungTu=N'" & SoChungTu.EditValue.ToString & "' WHERE SoChungTu=N'" & PrimaryKey.KeyValue("SoChungTu").ToString & "'")
            Catch ex As Exception
                mDBContext.TransactionRollback()
                mDBContext.Release()
                ShowUnknownError(ex.Message)
                Return False
            End Try
        End If

        Dim mModifyObject = mDBContext.ChungTus.FirstOrDefault(Function(pp) pp.SoChungTu.Equals(SoChungTu.EditValue))
        If mModifyObject Is Nothing Then
            mDBContext.TransactionRollback()
            mDBContext.Release()
            ShowErrorStop(HTLFW.My.Resources.MessageContent.infoErrorSaveFailedMissing)
            Return False
        Else

            mDBContext.Execute("DELETE FROM ChiTietChungTu WHERE SoChungTu=N'" & SoChungTu.EditValue.ToString & "'")

            With mModifyObject
                .SoChungTu = Nz(SoChungTu.EditValue, Nothing)
                .LoaiChungTu = Nz(LoaiChungTu.EditValue, Nothing)
                .NgayLap = Nz(NgayLap.EditValue, Nothing)
                .MaKH = Nz(MaKH.EditValue, Nothing)
                .MaKho = Nz(MaKho.EditValue, Nothing)
                .MaKhoNhan = Nz(MaKhoNhan.EditValue, Nothing)
                .MaKhoChuyen = Nz(MaKhoChuyen.EditValue, Nothing)
                .Ghichu = Nz(txtGhiChu.EditValue, Nothing)
            End With

            Try
                mDBContext.SubmitChanges()
            Catch ex As Exception
                mDBContext.TransactionRollback()
                mDBContext.Release()
                mModifyObject = Nothing
                ShowUnknownError(ex.Message)
                Return False
            End Try

            For Each mRow As DataRow In tblData.Rows
                Dim mNewDetailObject = New ChiTietChungTu
                With mNewDetailObject
                    .SoChungTu = Nz(SoChungTu.EditValue, Nothing)
                    .MaHang = Nz(mRow.Item("MaHang"), Nothing)
                    .SoLuong = Nz(mRow.Item("SoLuong"), Nothing)
                    .DonGia = Nz(mRow.Item("DonGia"), Nothing)
                    .ThanhTien = Nz(mRow.Item("ThanhTien"), Nothing)
                    .ThanhTienVon = Nz(mRow.Item("ThanhTienVon"), Nothing)
                End With
                Try
                    mDBContext.ChiTietChungTus.InsertOnSubmit(mNewDetailObject)
                    mDBContext.SubmitChanges()
                Catch ex As Exception
                    mDBContext.TransactionRollback()
                    mDBContext.Release()
                    mModifyObject = Nothing
                    ShowUnknownError(ex.Message)
                    Return False
                End Try
            Next

            mDBContext.AppendToAppHistory("MODIFY " + DataSourceTableName, "SoChungTu=[" + PrimaryKey.KeyValue("SoChungTu") + "]->[" + mModifyObject.SoChungTu + "] | LoaiChungTu=[" + Nz(PrimaryKey.KeyValue("LoaiChungTu"), "") + "]->[" + Nz(mModifyObject.LoaiChungTu, ""))

            PrimaryKey.KeyValue("SoChungTu") = mModifyObject.SoChungTu

            mDBContext.TransactionCommit()
            mDBContext.Release()
            mModifyObject = Nothing

            Return True
        End If

       
    End Function

    Public Overrides Sub FillCombosData()
        FillCombosData_MaKH()
        FillCombosData_MaKho()
        FillCombosData_LoaiChungTu()
        'FillCombosData_MaKhoChuyen()
    End Sub

#End Region

#Region "ValidData"

    Private Function DataIsOK() As Boolean
        RefreshErrors()
        Dim mTam As String = ""
        For Each mControl As DevExpress.XtraEditors.BaseEdit In Me.Controls.OfType(Of DevExpress.XtraEditors.BaseEdit)().OrderBy(Function(pp) pp.TabIndex).ToList
            mTam = DxError.GetError(mControl)
            If mTam <> "" Then
                ShowErrorStop(mTam)
                mControl.Focus()
                Return False
            End If
        Next
        Return True
    End Function
    Private Sub ResetErrors()
        For Each mControl In Me.Controls
            DxError.SetError(mControl, "")
        Next
    End Sub
    Private Sub RefreshErrors()
        ResetErrors()
        If IsNoValue(SoChungTu.EditValue) Then
            DxError.SetError(SoChungTu, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblSoChungTu.UniText}))
        End If
        If IsNoValue(LoaiChungTu.EditValue) Then
            DxError.SetError(LoaiChungTu, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblLoaiChungTu.UniText}))
        End If

    End Sub

    

#End Region

#Region "Subs"

    Private Sub ResetControls()

        SoChungTu.EditValue = Nothing
        LoaiChungTu.EditValue = Nothing
        NgayLap.EditValue = Today
        txtGhiChu.EditValue = Nothing

        tblData.Release()
        tblData = GetEditableDataTable("select * from ChiTietChungTu WHERE 1=0")
        grdChiTietChungTu.DataSource = tblData

        SoChungTu.Focus()
    End Sub

    Delegate Sub Delegate_FillCombosData_MaKho()
    Private Sub FillCombosData_MaKho()
        If Me.InvokeRequired Then
            Dim mCallBack = New Delegate_FillCombosData_MaKho(AddressOf FillCombosData_MaKho)
            Invoke(mCallBack)
        Else
            Using mData As DataTable = GetDataTable("SELECT MaKho as MaKho, MaKho+' - '+TenKho as TenKho FROM KhoView")
                MaKho.Properties.DataSource = mData
                MaKhoNhan.Properties.DataSource = mData
                MaKhoChuyen.Properties.DataSource = mData
                mData.Release()
            End Using
        End If
    End Sub
 
    Delegate Sub Delegate_FillCombosData_MaKH()
    Private Sub FillCombosData_MaKH()
        If Me.InvokeRequired Then
            Dim mCallBack = New Delegate_FillCombosData_MaKH(AddressOf FillCombosData_MaKH)
            Invoke(mCallBack)
        Else
            Using mData As DataTable = GetDataTable("SELECT MaKH, MaKH+' - '+TenKH as TenKH FROM KHView")
                MaKH.Properties.DataSource = mData
                If Not IsNoValue(MaKH.EditValue) AndAlso Nz(MaKH.Colums("ColValid"), 0) = 0 Then
                    If IsEditableMode() Then MaKH.EditValue = Nothing
                    DxError.SetError(MaKH, "Giá trị không hợp lệ!")
                End If
                mData.Release()
            End Using
        End If
    End Sub

    Delegate Sub Delegate_FillCombosData_LoaiChungTu()
    Private Sub FillCombosData_LoaiChungTu()
        If Me.InvokeRequired Then
            Dim mCallBack = New Delegate_FillCombosData_LoaiChungTu(AddressOf FillCombosData_LoaiChungTu)
            Invoke(mCallBack)
        Else
            Using mData As DataTable = GetDataTable("SELECT distinct  LoaiChungTu FROM ChungTu")
                LoaiChungTu.Properties.DataSource = mData
                If Not IsNoValue(LoaiChungTu.EditValue) AndAlso Nz(LoaiChungTu.Colums("ColValid"), 0) = 0 Then
                    If IsEditableMode() Then LoaiChungTu.EditValue = Nothing
                    DxError.SetError(LoaiChungTu, "Giá trị không hợp lệ!")
                End If
                mData.Release()
            End Using
        End If
    End Sub

#End Region

#Region "Controls Events"

    'Private Sub cmdMaKho_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UcButton1.Click
    '    AppDevWaitingForm.Show()
    '    Using mForm As New AppRoot.frmTOL_MaKho_Search(NgayHienHanh, AppRoot.frmTOL_MaKho_Search.eIncludeNoWork.TatCa, MaKho.EditValue)
    '        AddHandler mForm.EMIDPicked, AddressOf ProcessEMIDPicked
    '        mForm.ShowDialog(Me)
    '        mForm.Release()
    '    End Using
    '    AppDevWaitingForm.Hide()
    'End Sub
    'Private Sub ProcessEMIDPicked(ByVal pMaKho As String)
    '    If IsEditableMode() Then MaKho.EditValue = pMaKho
    'End Sub
#End Region

 
End Class