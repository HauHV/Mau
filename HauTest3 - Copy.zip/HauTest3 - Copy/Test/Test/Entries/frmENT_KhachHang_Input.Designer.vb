﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmENT_KhachHang_Input
    Inherits AppRoot.frmBaseListInput

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMaKH = New HTLFW.Label
        Me.MaKH = New HTLFW.UCTextEdit
        Me.lblTenKH = New HTLFW.Label
        Me.TenKH = New HTLFW.UCTextEdit
        Me.Label3 = New HTLFW.Label
        Me.txtGhiChu = New HTLFW.UCTextEdit
        Me.DiaChi = New HTLFW.UCTextEdit
        Me.SDT = New HTLFW.UCTextEdit
        Me.lblDiaChi = New HTLFW.Label
        Me.lblSDT = New HTLFW.Label
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TenKH.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DiaChi.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SDT.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdSaveAndClose
        '
        Me.cmdSaveAndClose.Location = New System.Drawing.Point(284, 303)
        Me.HelpProvider.SetShowHelp(Me.cmdSaveAndClose, True)
        Me.cmdSaveAndClose.Tag = "7"
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(203, 303)
        Me.HelpProvider.SetShowHelp(Me.cmdSave, True)
        Me.cmdSave.Tag = "6"
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(391, 303)
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        Me.cmdExit.Tag = "8"
        '
        'grUpdateInfor
        '
        Me.grUpdateInfor.AppearanceCaption.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.grUpdateInfor.AppearanceCaption.Options.UseFont = True
        Me.grUpdateInfor.Location = New System.Drawing.Point(54, 204)
        Me.HelpProvider.SetShowHelp(Me.grUpdateInfor, True)
        '
        'lblMaKH
        '
        Me.lblMaKH.AllowHtmlString = True
        Me.lblMaKH.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblMaKH.AutoSetTextToToolTip = False
        Me.lblMaKH.Location = New System.Drawing.Point(12, 51)
        Me.lblMaKH.MyNextControl = Me.MaKH
        Me.lblMaKH.MyTag01 = Nothing
        Me.lblMaKH.MyTag02 = Nothing
        Me.lblMaKH.MyTag03 = Nothing
        Me.lblMaKH.Name = "lblMaKH"
        Me.lblMaKH.Size = New System.Drawing.Size(88, 15)
        Me.lblMaKH.TabIndex = 18
        Me.lblMaKH.TagEN = Nothing
        Me.lblMaKH.Text = "Mã khách hàng<b><Color=Red>*</Color></b>"
        '
        'MaKH
        '
        Me.MaKH.ForceRelateControlOnLeave = True
        Me.MaKH.IsFirstInPair = False
        Me.MaKH.Location = New System.Drawing.Point(104, 48)
        Me.MaKH.MyAutoFormat = False
        Me.MaKH.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKH.MyMaxLength = 0
        Me.MaKH.MyRelateControl = Nothing
        Me.MaKH.MyTag01 = Nothing
        Me.MaKH.MyTag02 = Nothing
        Me.MaKH.MyTag03 = Nothing
        Me.MaKH.Name = "MaKH"
        Me.MaKH.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.Appearance.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKH.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKH.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKH.Properties.EditValue = Nothing
        Me.MaKH.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.MyAutoFormat = False
        Me.MaKH.Size = New System.Drawing.Size(344, 21)
        Me.MaKH.TabIndex = 24
        Me.MaKH.Tag = "1"
        '
        'lblTenKH
        '
        Me.lblTenKH.AllowHtmlString = True
        Me.lblTenKH.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblTenKH.AutoSetTextToToolTip = False
        Me.lblTenKH.Location = New System.Drawing.Point(7, 79)
        Me.lblTenKH.MyNextControl = Me.TenKH
        Me.lblTenKH.MyTag01 = Nothing
        Me.lblTenKH.MyTag02 = Nothing
        Me.lblTenKH.MyTag03 = Nothing
        Me.lblTenKH.Name = "lblTenKH"
        Me.lblTenKH.Size = New System.Drawing.Size(93, 15)
        Me.lblTenKH.TabIndex = 19
        Me.lblTenKH.TagEN = Nothing
        Me.lblTenKH.Text = "Tên khách hàng<b><Color=Red>*</Color></b>"
        '
        'TenKH
        '
        Me.TenKH.ForceRelateControlOnLeave = True
        Me.TenKH.IsFirstInPair = False
        Me.TenKH.Location = New System.Drawing.Point(104, 79)
        Me.TenKH.MyAutoFormat = False
        Me.TenKH.MyDataType = HTLFW.eValidDataRange.StringType
        Me.TenKH.MyMaxLength = 0
        Me.TenKH.MyRelateControl = Nothing
        Me.TenKH.MyTag01 = Nothing
        Me.TenKH.MyTag02 = Nothing
        Me.TenKH.MyTag03 = Nothing
        Me.TenKH.Name = "TenKH"
        Me.TenKH.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TenKH.Properties.Appearance.Options.UseFont = True
        Me.TenKH.Properties.EditValue = Nothing
        Me.TenKH.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TenKH.Properties.MyAutoFormat = False
        Me.TenKH.Size = New System.Drawing.Size(344, 21)
        Me.TenKH.TabIndex = 25
        Me.TenKH.Tag = "2"
        '
        'Label3
        '
        Me.Label3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label3.AutoSetTextToToolTip = False
        Me.Label3.Location = New System.Drawing.Point(54, 167)
        Me.Label3.MyNextControl = Me.txtGhiChu
        Me.Label3.MyTag01 = Nothing
        Me.Label3.MyTag02 = Nothing
        Me.Label3.MyTag03 = Nothing
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 15)
        Me.Label3.TabIndex = 20
        Me.Label3.TagEN = Nothing
        Me.Label3.Text = "Ghi chú"
        '
        'txtGhiChu
        '
        Me.txtGhiChu.ForceRelateControlOnLeave = True
        Me.txtGhiChu.IsFirstInPair = False
        Me.txtGhiChu.Location = New System.Drawing.Point(104, 164)
        Me.txtGhiChu.MyAutoFormat = False
        Me.txtGhiChu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.txtGhiChu.MyMaxLength = 0
        Me.txtGhiChu.MyRelateControl = Nothing
        Me.txtGhiChu.MyTag01 = Nothing
        Me.txtGhiChu.MyTag02 = Nothing
        Me.txtGhiChu.MyTag03 = Nothing
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.Appearance.Options.UseFont = True
        Me.txtGhiChu.Properties.EditValue = Nothing
        Me.txtGhiChu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.MyAutoFormat = False
        Me.txtGhiChu.Size = New System.Drawing.Size(344, 21)
        Me.txtGhiChu.TabIndex = 26
        Me.txtGhiChu.Tag = "5"
        '
        'DiaChi
        '
        Me.DiaChi.ForceRelateControlOnLeave = True
        Me.DiaChi.IsFirstInPair = False
        Me.DiaChi.Location = New System.Drawing.Point(104, 106)
        Me.DiaChi.MyAutoFormat = False
        Me.DiaChi.MyDataType = HTLFW.eValidDataRange.StringType
        Me.DiaChi.MyMaxLength = 0
        Me.DiaChi.MyRelateControl = Nothing
        Me.DiaChi.MyTag01 = Nothing
        Me.DiaChi.MyTag02 = Nothing
        Me.DiaChi.MyTag03 = Nothing
        Me.DiaChi.Name = "DiaChi"
        Me.DiaChi.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.DiaChi.Properties.Appearance.Options.UseFont = True
        Me.DiaChi.Properties.EditValue = Nothing
        Me.DiaChi.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.DiaChi.Properties.MyAutoFormat = False
        Me.DiaChi.Size = New System.Drawing.Size(344, 21)
        Me.DiaChi.TabIndex = 27
        Me.DiaChi.Tag = "3"
        '
        'SDT
        '
        Me.SDT.ForceRelateControlOnLeave = True
        Me.SDT.IsFirstInPair = False
        Me.SDT.Location = New System.Drawing.Point(104, 137)
        Me.SDT.MyAutoFormat = False
        Me.SDT.MyDataType = HTLFW.eValidDataRange.StringType
        Me.SDT.MyMaxLength = 0
        Me.SDT.MyRelateControl = Nothing
        Me.SDT.MyTag01 = Nothing
        Me.SDT.MyTag02 = Nothing
        Me.SDT.MyTag03 = Nothing
        Me.SDT.Name = "SDT"
        Me.SDT.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SDT.Properties.Appearance.Options.UseFont = True
        Me.SDT.Properties.EditValue = Nothing
        Me.SDT.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SDT.Properties.MyAutoFormat = False
        Me.SDT.Size = New System.Drawing.Size(344, 21)
        Me.SDT.TabIndex = 28
        Me.SDT.Tag = "4"
        '
        'lblDiaChi
        '
        Me.lblDiaChi.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblDiaChi.AutoSetTextToToolTip = False
        Me.lblDiaChi.Location = New System.Drawing.Point(58, 109)
        Me.lblDiaChi.MyNextControl = Me.txtGhiChu
        Me.lblDiaChi.MyTag01 = Nothing
        Me.lblDiaChi.MyTag02 = Nothing
        Me.lblDiaChi.MyTag03 = Nothing
        Me.lblDiaChi.Name = "lblDiaChi"
        Me.lblDiaChi.Size = New System.Drawing.Size(38, 15)
        Me.lblDiaChi.TabIndex = 29
        Me.lblDiaChi.TagEN = Nothing
        Me.lblDiaChi.Text = "Địa chỉ"
        '
        'lblSDT
        '
        Me.lblSDT.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblSDT.AutoSetTextToToolTip = False
        Me.lblSDT.Location = New System.Drawing.Point(72, 140)
        Me.lblSDT.MyNextControl = Me.txtGhiChu
        Me.lblSDT.MyTag01 = Nothing
        Me.lblSDT.MyTag02 = Nothing
        Me.lblSDT.MyTag03 = Nothing
        Me.lblSDT.Name = "lblSDT"
        Me.lblSDT.Size = New System.Drawing.Size(24, 15)
        Me.lblSDT.TabIndex = 30
        Me.lblSDT.TagEN = Nothing
        Me.lblSDT.Text = "SĐT"
        '
        'frmENT_KhachHang_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 369)
        Me.Controls.Add(Me.lblSDT)
        Me.Controls.Add(Me.lblDiaChi)
        Me.Controls.Add(Me.SDT)
        Me.Controls.Add(Me.DiaChi)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.TenKH)
        Me.Controls.Add(Me.MaKH)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblTenKH)
        Me.Controls.Add(Me.lblMaKH)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmENT_KhachHang_Input"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Text = "frmENT_KhachHang_Input"
        Me.Controls.SetChildIndex(Me.lblMaKH, 0)
        Me.Controls.SetChildIndex(Me.grUpdateInfor, 0)
        Me.Controls.SetChildIndex(Me.cmdSaveAndClose, 0)
        Me.Controls.SetChildIndex(Me.cmdSave, 0)
        Me.Controls.SetChildIndex(Me.cmdExit, 0)
        Me.Controls.SetChildIndex(Me.lblTenKH, 0)
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.MaKH, 0)
        Me.Controls.SetChildIndex(Me.TenKH, 0)
        Me.Controls.SetChildIndex(Me.txtGhiChu, 0)
        Me.Controls.SetChildIndex(Me.DiaChi, 0)
        Me.Controls.SetChildIndex(Me.SDT, 0)
        Me.Controls.SetChildIndex(Me.lblDiaChi, 0)
        Me.Controls.SetChildIndex(Me.lblSDT, 0)
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TenKH.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DiaChi.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SDT.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblMaKH As HTLFW.Label
    Friend WithEvents lblTenKH As HTLFW.Label
    Friend WithEvents Label3 As HTLFW.Label
    Friend WithEvents MaKH As HTLFW.UCTextEdit
    Friend WithEvents TenKH As HTLFW.UCTextEdit
    Friend WithEvents txtGhiChu As HTLFW.UCTextEdit
    Friend WithEvents DiaChi As HTLFW.UCTextEdit
    Friend WithEvents SDT As HTLFW.UCTextEdit
    Friend WithEvents lblDiaChi As HTLFW.Label
    Friend WithEvents lblSDT As HTLFW.Label
End Class
