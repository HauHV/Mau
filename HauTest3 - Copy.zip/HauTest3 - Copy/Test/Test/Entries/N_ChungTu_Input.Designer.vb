﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class N_ChungTu_Input
    Inherits AppRoot.frmBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gcData = New HTLFW.UCGridControl
        Me.gvData = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColMaHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColSoLuong = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColDonGia = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColThanhTien = New DevExpress.XtraGrid.Columns.GridColumn
        Me.cmdDong = New DevExpress.XtraEditors.SimpleButton
        Me.cmdLuuNext = New DevExpress.XtraEditors.SimpleButton
        Me.cmdLuu = New DevExpress.XtraEditors.SimpleButton
        Me.MaKho = New HTLFW.UCGridLookUpEdit
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.GridColumn1 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn2 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.lblMaKho = New HTLFW.Label
        Me.MaKH = New HTLFW.UCGridLookUpEdit
        Me.UcGridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.colColCode = New DevExpress.XtraGrid.Columns.GridColumn
        Me.colColName = New DevExpress.XtraGrid.Columns.GridColumn
        Me.lblMaKH = New HTLFW.Label
        Me.NgayLap = New HTLFW.UCTextEdit
        Me.lblNgayLap = New HTLFW.Label
        Me.Ghichu = New HTLFW.UCTextEdit
        Me.lblGhichu = New HTLFW.Label
        Me.SoChungTu = New HTLFW.UCTextEdit
        Me.lblSoChungTu = New HTLFW.Label
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gcData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NgayLap.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ghichu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SoChungTu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gcData
        '
        Me.gcData.AllowCommandDelete = False
        Me.gcData.AllowCommandModify = False
        Me.gcData.AllowCommandView = False
        Me.gcData.AllowContextMenu = True
        Me.gcData.AutoFocusToNewRow = True
        Me.gcData.EnableCommandDelete = True
        Me.gcData.EnableCommandModify = True
        Me.gcData.EnableCommandView = True
        Me.gcData.Location = New System.Drawing.Point(120, 146)
        Me.gcData.MainView = Me.gvData
        Me.gcData.MyAutoFormat = False
        Me.gcData.MyBoldFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyColorStyle = HTLFW.UCGridControl.eColorStyle.iSale
        Me.gcData.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gcData.MyFocusForeColor = System.Drawing.Color.Black
        Me.gcData.MyItalicFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyMainView = Me.gvData
        Me.gcData.MyNewRowBackColor = System.Drawing.Color.LemonChiffon
        Me.gcData.MyNewRowForeColor = System.Drawing.Color.Black
        Me.gcData.MyNormalFont = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gcData.MyOrdSource = HTLFW.UCGridControl.eOrdSource.RowHandle
        Me.gcData.MyShowDateCreatedColumn = False
        Me.gcData.MyShowDateModifiedColumn = False
        Me.gcData.MyShowDeleteCMD = False
        Me.gcData.MyShowModifyCMD = False
        Me.gcData.MyShowOrderColumn = False
        Me.gcData.MyShowUserCreatedColumn = False
        Me.gcData.MyShowUserModifiedColumn = False
        Me.gcData.MyShowViewCMD = False
        Me.gcData.MyViewType = HTLFW.UCGridControl.eViewType.EditableView
        Me.gcData.Name = "gcData"
        Me.gcData.ShowFilterRow = False
        Me.gcData.ShowFooter = True
        Me.gcData.ShowGroupPanel = False
        Me.gcData.ShowNewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top
        Me.gcData.Size = New System.Drawing.Size(692, 229)
        Me.gcData.TabIndex = 24
        Me.gcData.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.gvData})
        '
        'gvData
        '
        Me.gvData.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.gvData.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.gvData.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.gvData.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.DetailTip.Options.UseFont = True
        Me.gvData.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.Empty.Options.UseFont = True
        Me.gvData.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.EvenRow.Options.UseFont = True
        Me.gvData.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FilterCloseButton.Options.UseFont = True
        Me.gvData.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FilterPanel.Options.UseFont = True
        Me.gvData.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FixedLine.Options.UseFont = True
        Me.gvData.Appearance.FocusedCell.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.gvData.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.FocusedCell.Options.UseBackColor = True
        Me.gvData.Appearance.FocusedCell.Options.UseForeColor = True
        Me.gvData.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.FocusedRow.Options.UseBackColor = True
        Me.gvData.Appearance.FocusedRow.Options.UseForeColor = True
        Me.gvData.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.FooterPanel.Options.UseFont = True
        Me.gvData.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupButton.Options.UseFont = True
        Me.gvData.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupFooter.Options.UseFont = True
        Me.gvData.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupPanel.Options.UseFont = True
        Me.gvData.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.GroupRow.Options.UseFont = True
        Me.gvData.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.HeaderPanel.Options.UseFont = True
        Me.gvData.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.gvData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.gvData.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.gvData.Appearance.HideSelectionRow.Options.UseFont = True
        Me.gvData.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.gvData.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.HorzLine.Options.UseFont = True
        Me.gvData.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.OddRow.Options.UseFont = True
        Me.gvData.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.Preview.Options.UseFont = True
        Me.gvData.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.Row.Options.UseFont = True
        Me.gvData.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.RowSeparator.Options.UseFont = True
        Me.gvData.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.gvData.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.SelectedRow.Options.UseBackColor = True
        Me.gvData.Appearance.SelectedRow.Options.UseFont = True
        Me.gvData.Appearance.SelectedRow.Options.UseForeColor = True
        Me.gvData.Appearance.TopNewRow.BackColor = System.Drawing.Color.LemonChiffon
        Me.gvData.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.TopNewRow.ForeColor = System.Drawing.Color.Black
        Me.gvData.Appearance.TopNewRow.Options.UseBackColor = True
        Me.gvData.Appearance.TopNewRow.Options.UseFont = True
        Me.gvData.Appearance.TopNewRow.Options.UseForeColor = True
        Me.gvData.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.VertLine.Options.UseFont = True
        Me.gvData.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.gvData.Appearance.ViewCaption.Options.UseFont = True
        Me.gvData.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColMaHang, Me.grdColSoLuong, Me.grdColDonGia, Me.grdColThanhTien})
        Me.gvData.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.gvData.GridControl = Me.gcData
        Me.gvData.Name = "gvData"
        Me.gvData.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.[True]
        Me.gvData.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.[False]
        Me.gvData.OptionsBehavior.AllowIncrementalSearch = True
        Me.gvData.OptionsBehavior.AutoExpandAllGroups = True
        Me.gvData.OptionsBehavior.AutoPopulateColumns = False
        Me.gvData.OptionsBehavior.FocusLeaveOnTab = True
        Me.gvData.OptionsCustomization.AllowQuickHideColumns = False
        Me.gvData.OptionsNavigation.AutoFocusNewRow = True
        Me.gvData.OptionsNavigation.EnterMoveNextColumn = True
        Me.gvData.OptionsPrint.AutoWidth = False
        Me.gvData.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.gvData.OptionsView.ColumnAutoWidth = False
        Me.gvData.OptionsView.EnableAppearanceEvenRow = True
        Me.gvData.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Top
        Me.gvData.OptionsView.ShowFooter = True
        Me.gvData.OptionsView.ShowGroupPanel = False
        '
        'grdColMaHang
        '
        Me.grdColMaHang.Caption = "MaHang"
        Me.grdColMaHang.FieldName = "MaHang"
        Me.grdColMaHang.Name = "grdColMaHang"
        Me.grdColMaHang.Visible = True
        Me.grdColMaHang.VisibleIndex = 0
        Me.grdColMaHang.Width = 95
        '
        'grdColSoLuong
        '
        Me.grdColSoLuong.Caption = "SoLuong"
        Me.grdColSoLuong.FieldName = "SoLuong"
        Me.grdColSoLuong.Name = "grdColSoLuong"
        Me.grdColSoLuong.Visible = True
        Me.grdColSoLuong.VisibleIndex = 1
        Me.grdColSoLuong.Width = 102
        '
        'grdColDonGia
        '
        Me.grdColDonGia.Caption = "DonGia"
        Me.grdColDonGia.FieldName = "DonGia"
        Me.grdColDonGia.Name = "grdColDonGia"
        Me.grdColDonGia.Visible = True
        Me.grdColDonGia.VisibleIndex = 2
        Me.grdColDonGia.Width = 132
        '
        'grdColThanhTien
        '
        Me.grdColThanhTien.Caption = "ThanhTien"
        Me.grdColThanhTien.FieldName = "ThanhTien"
        Me.grdColThanhTien.Name = "grdColThanhTien"
        Me.grdColThanhTien.Visible = True
        Me.grdColThanhTien.VisibleIndex = 3
        Me.grdColThanhTien.Width = 208
        '
        'cmdDong
        '
        Me.cmdDong.Location = New System.Drawing.Point(737, 381)
        Me.cmdDong.Name = "cmdDong"
        Me.cmdDong.Size = New System.Drawing.Size(75, 23)
        Me.cmdDong.TabIndex = 21
        Me.cmdDong.Text = "Dong"
        '
        'cmdLuuNext
        '
        Me.cmdLuuNext.Location = New System.Drawing.Point(575, 381)
        Me.cmdLuuNext.Name = "cmdLuuNext"
        Me.cmdLuuNext.Size = New System.Drawing.Size(75, 23)
        Me.cmdLuuNext.TabIndex = 22
        Me.cmdLuuNext.Text = "Luu"
        '
        'cmdLuu
        '
        Me.cmdLuu.Location = New System.Drawing.Point(656, 381)
        Me.cmdLuu.Name = "cmdLuu"
        Me.cmdLuu.Size = New System.Drawing.Size(75, 23)
        Me.cmdLuu.TabIndex = 23
        Me.cmdLuu.Text = "Luu + Dong"
        '
        'MaKho
        '
        Me.MaKho.AllowNoSourceText = True
        Me.MaKho.AllowNULL = True
        Me.MaKho.ColumnWidths = New Integer() {0, -1}
        Me.MaKho.CreateDefaultColCodeColumn = False
        Me.MaKho.CreateDefaultColNameColumn = False
        Me.MaKho.EnterMoveNextControl = True
        Me.MaKho.ForceRelateControlOnLeave = False
        Me.MaKho.HasFilterRow = True
        Me.MaKho.IsChange = False
        Me.MaKho.IsFirstInPair = False
        Me.MaKho.Location = New System.Drawing.Point(200, 92)
        Me.MaKho.MyAutoFormat = False
        Me.MaKho.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKho.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKho.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKho.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKho.MyRelateControl = Nothing
        Me.MaKho.MyTag01 = Nothing
        Me.MaKho.MyTag02 = Nothing
        Me.MaKho.MyTag03 = Nothing
        Me.MaKho.MyTextControl = Nothing
        Me.MaKho.Name = "MaKho"
        Me.MaKho.Properties.AllowNoSourceText = True
        Me.MaKho.Properties.AllowNULL = True
        Me.MaKho.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKho.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.Appearance.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKho.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKho.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKho.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKho.Properties.ColumnWidths = New Integer() {0, -1}
        Me.MaKho.Properties.CreateDefaultColCodeColumn = False
        Me.MaKho.Properties.CreateDefaultColNameColumn = False
        Me.MaKho.Properties.DisplayMember = "ColName"
        Me.MaKho.Properties.EditValue = Nothing
        Me.MaKho.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.HasFilterRow = True
        Me.MaKho.Properties.IsChange = False
        Me.MaKho.Properties.MyAutoFormat = False
        Me.MaKho.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKho.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKho.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKho.Properties.MyTextControl = Nothing
        Me.MaKho.Properties.NullText = ""
        Me.MaKho.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKho.Properties.PopupSizeable = False
        Me.MaKho.Properties.ShowFooter = False
        Me.MaKho.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKho.Properties.ValidateOnEnterKey = True
        Me.MaKho.Properties.ValueMember = "ColCode"
        Me.MaKho.Properties.View = Me.GridView1
        Me.MaKho.Size = New System.Drawing.Size(276, 21)
        Me.MaKho.TabIndex = 19
        '
        'GridView1
        '
        Me.GridView1.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.GridView1.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.GridView1.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.GridView1.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.DetailTip.Options.UseFont = True
        Me.GridView1.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.Empty.Options.UseFont = True
        Me.GridView1.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.EvenRow.Options.UseFont = True
        Me.GridView1.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FilterCloseButton.Options.UseFont = True
        Me.GridView1.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FilterPanel.Options.UseFont = True
        Me.GridView1.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FixedLine.Options.UseFont = True
        Me.GridView1.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView1.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView1.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView1.Appearance.FocusedRow.Options.UseBackColor = True
        Me.GridView1.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView1.Appearance.FocusedRow.Options.UseForeColor = True
        Me.GridView1.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FooterPanel.Options.UseFont = True
        Me.GridView1.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.GroupButton.Options.UseFont = True
        Me.GridView1.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.GroupFooter.Options.UseFont = True
        Me.GridView1.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.GroupPanel.Options.UseFont = True
        Me.GridView1.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.GroupRow.Options.UseFont = True
        Me.GridView1.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView1.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView1.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.GridView1.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.GridView1.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView1.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.GridView1.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.HorzLine.Options.UseFont = True
        Me.GridView1.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.OddRow.Options.UseFont = True
        Me.GridView1.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.Preview.Options.UseFont = True
        Me.GridView1.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.Row.Options.UseFont = True
        Me.GridView1.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView1.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.GridView1.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.GridView1.Appearance.SelectedRow.Options.UseBackColor = True
        Me.GridView1.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView1.Appearance.SelectedRow.Options.UseForeColor = True
        Me.GridView1.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.TopNewRow.Options.UseFont = True
        Me.GridView1.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.VertLine.Options.UseFont = True
        Me.GridView1.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.ViewCaption.Options.UseFont = True
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn1, Me.GridColumn2})
        Me.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        Me.GridView1.OptionsCustomization.AllowColumnMoving = False
        Me.GridView1.OptionsCustomization.AllowColumnResizing = False
        Me.GridView1.OptionsCustomization.AllowGroup = False
        Me.GridView1.OptionsCustomization.AllowQuickHideColumns = False
        Me.GridView1.OptionsMenu.EnableColumnMenu = False
        Me.GridView1.OptionsMenu.EnableFooterMenu = False
        Me.GridView1.OptionsMenu.EnableGroupPanelMenu = False
        Me.GridView1.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView1.OptionsSelection.EnableAppearanceHideSelection = False
        Me.GridView1.OptionsView.ColumnAutoWidth = False
        Me.GridView1.OptionsView.ShowAutoFilterRow = True
        Me.GridView1.OptionsView.ShowColumnHeaders = False
        Me.GridView1.OptionsView.ShowGroupPanel = False
        Me.GridView1.OptionsView.ShowIndicator = False
        Me.GridView1.SortInfo.AddRange(New DevExpress.XtraGrid.Columns.GridColumnSortInfo() {New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.GridColumn1, DevExpress.Data.ColumnSortOrder.Ascending)})
        '
        'GridColumn1
        '
        Me.GridColumn1.FieldName = "ColCode"
        Me.GridColumn1.Name = "GridColumn1"
        Me.GridColumn1.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.GridColumn1.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.GridColumn1.Visible = True
        Me.GridColumn1.VisibleIndex = 0
        '
        'GridColumn2
        '
        Me.GridColumn2.FieldName = "ColName"
        Me.GridColumn2.Name = "GridColumn2"
        Me.GridColumn2.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.GridColumn2.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.GridColumn2.Visible = True
        Me.GridColumn2.VisibleIndex = 1
        '
        'lblMaKho
        '
        Me.lblMaKho.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblMaKho.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.lblMaKho.AutoSetTextToToolTip = False
        Me.lblMaKho.Location = New System.Drawing.Point(156, 95)
        Me.lblMaKho.MyNextControl = Me.MaKho
        Me.lblMaKho.MyTag01 = Nothing
        Me.lblMaKho.MyTag02 = Nothing
        Me.lblMaKho.MyTag03 = Nothing
        Me.lblMaKho.Name = "lblMaKho"
        Me.lblMaKho.Size = New System.Drawing.Size(38, 15)
        Me.lblMaKho.TabIndex = 18
        Me.lblMaKho.TagEN = Nothing
        Me.lblMaKho.Text = "MaKho"
        '
        'MaKH
        '
        Me.MaKH.AllowNoSourceText = True
        Me.MaKH.AllowNULL = True
        Me.MaKH.ColumnWidths = New Integer() {0, -1}
        Me.MaKH.CreateDefaultColCodeColumn = False
        Me.MaKH.CreateDefaultColNameColumn = False
        Me.MaKH.EnterMoveNextControl = True
        Me.MaKH.ForceRelateControlOnLeave = False
        Me.MaKH.HasFilterRow = True
        Me.MaKH.IsChange = False
        Me.MaKH.IsFirstInPair = False
        Me.MaKH.Location = New System.Drawing.Point(200, 65)
        Me.MaKH.MyAutoFormat = False
        Me.MaKH.MyColorStyle = HTLFW.eColorStyle.iSale
        Me.MaKH.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKH.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKH.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKH.MyRelateControl = Nothing
        Me.MaKH.MyTag01 = Nothing
        Me.MaKH.MyTag02 = Nothing
        Me.MaKH.MyTag03 = Nothing
        Me.MaKH.MyTextControl = Nothing
        Me.MaKH.Name = "MaKH"
        Me.MaKH.Properties.AllowNoSourceText = True
        Me.MaKH.Properties.AllowNULL = True
        Me.MaKH.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.MaKH.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.Appearance.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKH.Properties.AppearanceDropDown.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceDropDown.Options.UseFont = True
        Me.MaKH.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKH.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKH.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.MaKH.Properties.ColumnWidths = New Integer() {0, -1}
        Me.MaKH.Properties.CreateDefaultColCodeColumn = False
        Me.MaKH.Properties.CreateDefaultColNameColumn = False
        Me.MaKH.Properties.DisplayMember = "ColName"
        Me.MaKH.Properties.EditValue = Nothing
        Me.MaKH.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKH.Properties.HasFilterRow = True
        Me.MaKH.Properties.IsChange = False
        Me.MaKH.Properties.MyAutoFormat = False
        Me.MaKH.Properties.MyColorStyle = HTLFW.eColorStyle.Custom
        Me.MaKH.Properties.MyFocusBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.MaKH.Properties.MyFocusForeColor = System.Drawing.Color.Black
        Me.MaKH.Properties.MyTextControl = Nothing
        Me.MaKH.Properties.NullText = ""
        Me.MaKH.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.MaKH.Properties.PopupSizeable = False
        Me.MaKH.Properties.ShowFooter = False
        Me.MaKH.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
        Me.MaKH.Properties.ValidateOnEnterKey = True
        Me.MaKH.Properties.ValueMember = "ColCode"
        Me.MaKH.Properties.View = Me.UcGridLookUpEdit1View
        Me.MaKH.Size = New System.Drawing.Size(276, 21)
        Me.MaKH.TabIndex = 20
        '
        'UcGridLookUpEdit1View
        '
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButtonActive.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ColumnFilterButtonActive.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.CustomizationFormHint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.CustomizationFormHint.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.DetailTip.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.DetailTip.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Empty.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Empty.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.EvenRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FilterCloseButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FilterCloseButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FilterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FilterPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FixedLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FixedLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FocusedCell.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.FocusedRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.FooterPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.FooterPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupButton.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupFooter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupFooter.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.GroupRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.GroupRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.UcGridLookUpEdit1View.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.HideSelectionRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.HorzLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.OddRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Preview.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Preview.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.Row.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.RowSeparator.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(236, Byte), Integer))
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseBackColor = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.SelectedRow.Options.UseForeColor = True
        Me.UcGridLookUpEdit1View.Appearance.TopNewRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.TopNewRow.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.VertLine.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Appearance.ViewCaption.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.UcGridLookUpEdit1View.Appearance.ViewCaption.Options.UseFont = True
        Me.UcGridLookUpEdit1View.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.colColCode, Me.colColName})
        Me.UcGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.UcGridLookUpEdit1View.Name = "UcGridLookUpEdit1View"
        Me.UcGridLookUpEdit1View.OptionsBehavior.Editable = False
        Me.UcGridLookUpEdit1View.OptionsBehavior.ReadOnly = True
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowColumnMoving = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowColumnResizing = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowGroup = False
        Me.UcGridLookUpEdit1View.OptionsCustomization.AllowQuickHideColumns = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableColumnMenu = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableFooterMenu = False
        Me.UcGridLookUpEdit1View.OptionsMenu.EnableGroupPanelMenu = False
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.UcGridLookUpEdit1View.OptionsSelection.EnableAppearanceHideSelection = False
        Me.UcGridLookUpEdit1View.OptionsView.ColumnAutoWidth = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowAutoFilterRow = True
        Me.UcGridLookUpEdit1View.OptionsView.ShowColumnHeaders = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        Me.UcGridLookUpEdit1View.OptionsView.ShowIndicator = False
        Me.UcGridLookUpEdit1View.SortInfo.AddRange(New DevExpress.XtraGrid.Columns.GridColumnSortInfo() {New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.colColCode, DevExpress.Data.ColumnSortOrder.Ascending)})
        '
        'colColCode
        '
        Me.colColCode.FieldName = "ColCode"
        Me.colColCode.Name = "colColCode"
        Me.colColCode.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.colColCode.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.colColCode.Visible = True
        Me.colColCode.VisibleIndex = 0
        '
        'colColName
        '
        Me.colColName.FieldName = "ColName"
        Me.colColName.Name = "colColName"
        Me.colColName.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.colColName.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.colColName.Visible = True
        Me.colColName.VisibleIndex = 1
        '
        'lblMaKH
        '
        Me.lblMaKH.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblMaKH.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.lblMaKH.AutoSetTextToToolTip = False
        Me.lblMaKH.Location = New System.Drawing.Point(161, 68)
        Me.lblMaKH.MyNextControl = Me.MaKH
        Me.lblMaKH.MyTag01 = Nothing
        Me.lblMaKH.MyTag02 = Nothing
        Me.lblMaKH.MyTag03 = Nothing
        Me.lblMaKH.Name = "lblMaKH"
        Me.lblMaKH.Size = New System.Drawing.Size(33, 15)
        Me.lblMaKH.TabIndex = 17
        Me.lblMaKH.TagEN = Nothing
        Me.lblMaKH.Text = "MaKH"
        '
        'NgayLap
        '
        Me.NgayLap.EnterMoveNextControl = True
        Me.NgayLap.ForceRelateControlOnLeave = True
        Me.NgayLap.IsFirstInPair = False
        Me.NgayLap.Location = New System.Drawing.Point(376, 38)
        Me.NgayLap.MyAutoFormat = False
        Me.NgayLap.MyDataType = HTLFW.eValidDataRange.StringType
        Me.NgayLap.MyMaxLength = 0
        Me.NgayLap.MyRelateControl = Nothing
        Me.NgayLap.MyTag01 = Nothing
        Me.NgayLap.MyTag02 = Nothing
        Me.NgayLap.MyTag03 = Nothing
        Me.NgayLap.Name = "NgayLap"
        Me.NgayLap.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.Appearance.Options.UseFont = True
        Me.NgayLap.Properties.Appearance.Options.UseTextOptions = True
        Me.NgayLap.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.NgayLap.Properties.EditValue = Nothing
        Me.NgayLap.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.NgayLap.Properties.Mask.EditMask = "dd/MM/yyyy"
        Me.NgayLap.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret
        Me.NgayLap.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.NgayLap.Properties.MyAutoFormat = False
        Me.NgayLap.Size = New System.Drawing.Size(100, 21)
        Me.NgayLap.TabIndex = 16
        '
        'lblNgayLap
        '
        Me.lblNgayLap.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblNgayLap.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.lblNgayLap.AutoSetTextToToolTip = False
        Me.lblNgayLap.Location = New System.Drawing.Point(321, 41)
        Me.lblNgayLap.MyNextControl = Me.NgayLap
        Me.lblNgayLap.MyTag01 = Nothing
        Me.lblNgayLap.MyTag02 = Nothing
        Me.lblNgayLap.MyTag03 = Nothing
        Me.lblNgayLap.Name = "lblNgayLap"
        Me.lblNgayLap.Size = New System.Drawing.Size(49, 15)
        Me.lblNgayLap.TabIndex = 15
        Me.lblNgayLap.TagEN = Nothing
        Me.lblNgayLap.Text = "NgayLap"
        '
        'Ghichu
        '
        Me.Ghichu.EnterMoveNextControl = True
        Me.Ghichu.ForceRelateControlOnLeave = True
        Me.Ghichu.IsFirstInPair = False
        Me.Ghichu.Location = New System.Drawing.Point(200, 119)
        Me.Ghichu.MyAutoFormat = False
        Me.Ghichu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.Ghichu.MyMaxLength = 50
        Me.Ghichu.MyRelateControl = Nothing
        Me.Ghichu.MyTag01 = Nothing
        Me.Ghichu.MyTag02 = Nothing
        Me.Ghichu.MyTag03 = Nothing
        Me.Ghichu.Name = "Ghichu"
        Me.Ghichu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Ghichu.Properties.Appearance.Options.UseFont = True
        Me.Ghichu.Properties.EditValue = Nothing
        Me.Ghichu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Ghichu.Properties.MaxLength = 50
        Me.Ghichu.Properties.MyAutoFormat = False
        Me.Ghichu.Size = New System.Drawing.Size(276, 21)
        Me.Ghichu.TabIndex = 13
        '
        'lblGhichu
        '
        Me.lblGhichu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblGhichu.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.lblGhichu.AutoSetTextToToolTip = False
        Me.lblGhichu.Location = New System.Drawing.Point(156, 122)
        Me.lblGhichu.MyNextControl = Me.Ghichu
        Me.lblGhichu.MyTag01 = Nothing
        Me.lblGhichu.MyTag02 = Nothing
        Me.lblGhichu.MyTag03 = Nothing
        Me.lblGhichu.Name = "lblGhichu"
        Me.lblGhichu.Size = New System.Drawing.Size(39, 15)
        Me.lblGhichu.TabIndex = 11
        Me.lblGhichu.TagEN = Nothing
        Me.lblGhichu.Text = "Ghichu"
        '
        'SoChungTu
        '
        Me.SoChungTu.EnterMoveNextControl = True
        Me.SoChungTu.ForceRelateControlOnLeave = True
        Me.SoChungTu.IsFirstInPair = False
        Me.SoChungTu.Location = New System.Drawing.Point(200, 38)
        Me.SoChungTu.MyAutoFormat = False
        Me.SoChungTu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.SoChungTu.MyMaxLength = 50
        Me.SoChungTu.MyRelateControl = Nothing
        Me.SoChungTu.MyTag01 = Nothing
        Me.SoChungTu.MyTag02 = Nothing
        Me.SoChungTu.MyTag03 = Nothing
        Me.SoChungTu.Name = "SoChungTu"
        Me.SoChungTu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.Appearance.Options.UseFont = True
        Me.SoChungTu.Properties.EditValue = Nothing
        Me.SoChungTu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SoChungTu.Properties.MaxLength = 50
        Me.SoChungTu.Properties.MyAutoFormat = False
        Me.SoChungTu.Size = New System.Drawing.Size(100, 21)
        Me.SoChungTu.TabIndex = 14
        '
        'lblSoChungTu
        '
        Me.lblSoChungTu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblSoChungTu.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
        Me.lblSoChungTu.AutoSetTextToToolTip = False
        Me.lblSoChungTu.Location = New System.Drawing.Point(128, 41)
        Me.lblSoChungTu.MyNextControl = Me.SoChungTu
        Me.lblSoChungTu.MyTag01 = Nothing
        Me.lblSoChungTu.MyTag02 = Nothing
        Me.lblSoChungTu.MyTag03 = Nothing
        Me.lblSoChungTu.Name = "lblSoChungTu"
        Me.lblSoChungTu.Size = New System.Drawing.Size(66, 15)
        Me.lblSoChungTu.TabIndex = 12
        Me.lblSoChungTu.TagEN = Nothing
        Me.lblSoChungTu.Text = "SoChungTu"
        '
        'N_ChungTu_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(933, 443)
        Me.Controls.Add(Me.gcData)
        Me.Controls.Add(Me.cmdDong)
        Me.Controls.Add(Me.cmdLuuNext)
        Me.Controls.Add(Me.cmdLuu)
        Me.Controls.Add(Me.MaKho)
        Me.Controls.Add(Me.lblMaKho)
        Me.Controls.Add(Me.MaKH)
        Me.Controls.Add(Me.lblMaKH)
        Me.Controls.Add(Me.NgayLap)
        Me.Controls.Add(Me.lblNgayLap)
        Me.Controls.Add(Me.Ghichu)
        Me.Controls.Add(Me.lblGhichu)
        Me.Controls.Add(Me.SoChungTu)
        Me.Controls.Add(Me.lblSoChungTu)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "N_ChungTu_Input"
        Me.HelpProvider.SetShowHelp(Me, False)
        Me.Text = "N_ChungTu_Input"
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gcData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKH.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UcGridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NgayLap.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ghichu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SoChungTu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gcData As HTLFW.UCGridControl
    Friend WithEvents gvData As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents grdColMaHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColSoLuong As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColDonGia As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColThanhTien As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents cmdDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents cmdLuuNext As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents cmdLuu As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents MaKho As HTLFW.UCGridLookUpEdit
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn1 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn2 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents lblMaKho As HTLFW.Label
    Friend WithEvents MaKH As HTLFW.UCGridLookUpEdit
    Friend WithEvents UcGridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents colColCode As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents colColName As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents lblMaKH As HTLFW.Label
    Friend WithEvents NgayLap As HTLFW.UCTextEdit
    Friend WithEvents lblNgayLap As HTLFW.Label
    Friend WithEvents Ghichu As HTLFW.UCTextEdit
    Friend WithEvents lblGhichu As HTLFW.Label
    Friend WithEvents SoChungTu As HTLFW.UCTextEdit
    Friend WithEvents lblSoChungTu As HTLFW.Label
End Class
