﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmENT_Kho_Input
    Inherits AppRoot.frmBaseListInput

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMaKho = New HTLFW.Label
        Me.MaKho = New HTLFW.UCTextEdit
        Me.lblTenKho = New HTLFW.Label
        Me.TenKho = New HTLFW.UCTextEdit
        Me.Label3 = New HTLFW.Label
        Me.txtGhiChu = New HTLFW.UCTextEdit
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TenKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdSaveAndClose
        '
        Me.cmdSaveAndClose.Location = New System.Drawing.Point(269, 309)
        Me.HelpProvider.SetShowHelp(Me.cmdSaveAndClose, True)
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(188, 309)
        Me.HelpProvider.SetShowHelp(Me.cmdSave, True)
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(376, 309)
        Me.HelpProvider.SetShowHelp(Me.cmdExit, True)
        '
        'grUpdateInfor
        '
        Me.grUpdateInfor.AppearanceCaption.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.grUpdateInfor.AppearanceCaption.Options.UseFont = True
        Me.grUpdateInfor.Location = New System.Drawing.Point(39, 166)
        Me.HelpProvider.SetShowHelp(Me.grUpdateInfor, True)
        '
        'lblMaKho
        '
        Me.lblMaKho.AllowHtmlString = True
        Me.lblMaKho.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblMaKho.AutoSetTextToToolTip = False
        Me.lblMaKho.Location = New System.Drawing.Point(44, 54)
        Me.lblMaKho.MyNextControl = Me.MaKho
        Me.lblMaKho.MyTag01 = Nothing
        Me.lblMaKho.MyTag02 = Nothing
        Me.lblMaKho.MyTag03 = Nothing
        Me.lblMaKho.Name = "lblMaKho"
        Me.lblMaKho.Size = New System.Drawing.Size(44, 15)
        Me.lblMaKho.TabIndex = 18
        Me.lblMaKho.TagEN = Nothing
        Me.lblMaKho.Text = "Mã kho<b><Color=Red>*</Color></b>"
        '
        'MaKho
        '
        Me.MaKho.ForceRelateControlOnLeave = True
        Me.MaKho.IsFirstInPair = False
        Me.MaKho.Location = New System.Drawing.Point(89, 54)
        Me.MaKho.MyAutoFormat = False
        Me.MaKho.MyDataType = HTLFW.eValidDataRange.StringType
        Me.MaKho.MyMaxLength = 0
        Me.MaKho.MyRelateControl = Nothing
        Me.MaKho.MyTag01 = Nothing
        Me.MaKho.MyTag02 = Nothing
        Me.MaKho.MyTag03 = Nothing
        Me.MaKho.Name = "MaKho"
        Me.MaKho.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.Appearance.Options.UseFont = True
        Me.MaKho.Properties.AppearanceDisabled.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceDisabled.Options.UseFont = True
        Me.MaKho.Properties.AppearanceFocused.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceFocused.Options.UseFont = True
        Me.MaKho.Properties.AppearanceReadOnly.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.AppearanceReadOnly.Options.UseFont = True
        Me.MaKho.Properties.EditValue = Nothing
        Me.MaKho.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.MaKho.Properties.MyAutoFormat = False
        Me.MaKho.Size = New System.Drawing.Size(344, 21)
        Me.MaKho.TabIndex = 24
        '
        'lblTenKho
        '
        Me.lblTenKho.AllowHtmlString = True
        Me.lblTenKho.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.lblTenKho.AutoSetTextToToolTip = False
        Me.lblTenKho.Location = New System.Drawing.Point(39, 85)
        Me.lblTenKho.MyNextControl = Me.TenKho
        Me.lblTenKho.MyTag01 = Nothing
        Me.lblTenKho.MyTag02 = Nothing
        Me.lblTenKho.MyTag03 = Nothing
        Me.lblTenKho.Name = "lblTenKho"
        Me.lblTenKho.Size = New System.Drawing.Size(49, 15)
        Me.lblTenKho.TabIndex = 19
        Me.lblTenKho.TagEN = Nothing
        Me.lblTenKho.Text = "Tên kho<b><Color=Red>*</Color></b>"
        '
        'TenKho
        '
        Me.TenKho.ForceRelateControlOnLeave = True
        Me.TenKho.IsFirstInPair = False
        Me.TenKho.Location = New System.Drawing.Point(89, 85)
        Me.TenKho.MyAutoFormat = False
        Me.TenKho.MyDataType = HTLFW.eValidDataRange.StringType
        Me.TenKho.MyMaxLength = 0
        Me.TenKho.MyRelateControl = Nothing
        Me.TenKho.MyTag01 = Nothing
        Me.TenKho.MyTag02 = Nothing
        Me.TenKho.MyTag03 = Nothing
        Me.TenKho.Name = "TenKho"
        Me.TenKho.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TenKho.Properties.Appearance.Options.UseFont = True
        Me.TenKho.Properties.EditValue = Nothing
        Me.TenKho.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.TenKho.Properties.MyAutoFormat = False
        Me.TenKho.Size = New System.Drawing.Size(344, 21)
        Me.TenKho.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Label3.AutoSetTextToToolTip = False
        Me.Label3.Location = New System.Drawing.Point(41, 116)
        Me.Label3.MyNextControl = Me.txtGhiChu
        Me.Label3.MyTag01 = Nothing
        Me.Label3.MyTag02 = Nothing
        Me.Label3.MyTag03 = Nothing
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 15)
        Me.Label3.TabIndex = 20
        Me.Label3.TagEN = Nothing
        Me.Label3.Text = "Ghi chú"
        '
        'txtGhiChu
        '
        Me.txtGhiChu.ForceRelateControlOnLeave = True
        Me.txtGhiChu.IsFirstInPair = False
        Me.txtGhiChu.Location = New System.Drawing.Point(89, 113)
        Me.txtGhiChu.MyAutoFormat = False
        Me.txtGhiChu.MyDataType = HTLFW.eValidDataRange.StringType
        Me.txtGhiChu.MyMaxLength = 0
        Me.txtGhiChu.MyRelateControl = Nothing
        Me.txtGhiChu.MyTag01 = Nothing
        Me.txtGhiChu.MyTag02 = Nothing
        Me.txtGhiChu.MyTag03 = Nothing
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.Appearance.Options.UseFont = True
        Me.txtGhiChu.Properties.EditValue = Nothing
        Me.txtGhiChu.Properties.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Properties.MyAutoFormat = False
        Me.txtGhiChu.Size = New System.Drawing.Size(344, 21)
        Me.txtGhiChu.TabIndex = 26
        '
        'frmENT_Kho_Input
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 369)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.TenKho)
        Me.Controls.Add(Me.MaKho)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblTenKho)
        Me.Controls.Add(Me.lblMaKho)
        Me.HelpProvider.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.Name = "frmENT_Kho_Input"
        Me.HelpProvider.SetShowHelp(Me, True)
        Me.Text = "frmENT_Kho_Input"
        Me.Controls.SetChildIndex(Me.lblMaKho, 0)
        Me.Controls.SetChildIndex(Me.grUpdateInfor, 0)
        Me.Controls.SetChildIndex(Me.cmdSaveAndClose, 0)
        Me.Controls.SetChildIndex(Me.cmdSave, 0)
        Me.Controls.SetChildIndex(Me.cmdExit, 0)
        Me.Controls.SetChildIndex(Me.lblTenKho, 0)
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.MaKho, 0)
        Me.Controls.SetChildIndex(Me.TenKho, 0)
        Me.Controls.SetChildIndex(Me.txtGhiChu, 0)
        CType(Me.grUpdateInfor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxError, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TenKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblMaKho As HTLFW.Label
    Friend WithEvents lblTenKho As HTLFW.Label
    Friend WithEvents Label3 As HTLFW.Label
    Friend WithEvents MaKho As HTLFW.UCTextEdit
    Friend WithEvents TenKho As HTLFW.UCTextEdit
    Friend WithEvents txtGhiChu As HTLFW.UCTextEdit
End Class
