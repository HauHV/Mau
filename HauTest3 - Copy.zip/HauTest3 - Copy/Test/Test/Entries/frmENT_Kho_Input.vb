﻿#Region "References"

Imports HTLFW
Imports HTLFW.HTLLib
Imports HTLFW.HTLLib.HTLComFuncs
Imports HTLFW.HTLLib.HTLStringFuncs
Imports HTLFW.HTLLib.HTLLayoutDefinition
Imports DBs

#End Region
Public Class frmENT_Kho_Input
#Region "Declares"

    Private _NewCodeValue As String = Nothing
    Private DataSourceTableName As String = "Kho"
    'Private AutoRefObjectDefined As Boolean = True
    Private MyMaKho As String

#End Region
#Region "Properties"

    Public Overrides Property FormMode() As HTLFW.eFormMode
        Get
            Return MyBase.FormMode
        End Get
        Set(ByVal value As HTLFW.eFormMode)
            MyBase.FormMode = value
            If IsAllVIEWMode() Then
                MaKho.Properties.ReadOnly = True
                MaKho.Enabled = False
                TenKho.Properties.ReadOnly = True
                TenKho.Enabled = False
                txtGhiChu.Properties.ReadOnly = True
                txtGhiChu.Enabled = False
            End If
        End Set
    End Property

#End Region

#Region "Constructors"

    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pMaKho As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        MyMaKho = pMaKho
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pPrimaryKey As ListKeyValues, ByVal pAllowCodeChange As Boolean, ByVal pMaKho As String)
        InitializeComponent()
        FormMode = pFormMode
        PrimaryKey.GetValues(pPrimaryKey)
        AllowCodeChange = pAllowCodeChange
        MyMaKho = pMaKho
    End Sub

    Private Sub Me_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        ReleaseMemory()
    End Sub

    Private Sub Me_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub


#End Region

#Region "Override"

    Public Overrides Function LoadData() As Boolean
        Try
            Select Case FormMode
                Case eFormMode.Modify, eFormMode.View, eFormMode.ModifyAndy, eFormMode.ViewAny
                    Dim mCurrObject = DBContext.Khos.FirstOrDefault(Function(pp) pp.MaKho.Equals(PrimaryKey.KeyValue("MaKho")))
                    If mCurrObject Is Nothing Then
                        ResetControls()
                        Return False
                    Else
                        With mCurrObject

                            MaKho.EditValue = .MaKho
                            TenKho.EditValue = .TenKho
                            txtGhiChu.EditValue = .GhiChu

                        End With
                    End If
                    mCurrObject = Nothing
                    Return True
                Case Else
                    ResetControls()
                    Return True
            End Select
        Catch ex As Exception
            ShowErrorStop(ex.Message)
            Return False
        End Try

    End Function

    Public Overrides Function InsertData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()
        mDBContext.TransactionStart()

        Dim mNewObject = New Kho
        With mNewObject

            .MaKho = Nz(MaKho.EditValue, Nothing)
            .TenKho = Nz(TenKho.EditValue, Nothing)
            .GhiChu = Nz(txtGhiChu.EditValue, Nothing)
            
        End With
        Try
            mDBContext.Khos.InsertOnSubmit(mNewObject)
            mDBContext.SubmitChanges()
        Catch ex As Exception
            mDBContext.TransactionRollback()
            mDBContext.Release()
            mNewObject = Nothing
            ShowUnknownError(ex.Message)
            Return False
        End Try

        mDBContext.AppendToAppHistory("ADDNEW " + DataSourceTableName, "MaKho=[" + mNewObject.MaKho + "] | TenKho=[" + Nz(mNewObject.TenKho, "") + "] | GhiChu=[" + Nz(mNewObject.GhiChu, ""))

        mDBContext.TransactionCommit()
        mDBContext.Release()

        PrimaryKey.KeyValue("MaKho") = mNewObject.MaKho

        mNewObject = Nothing

        ResetControls()

        FillCombosData()

        Return True
    End Function

    Public Overrides Function SaveData() As Boolean
        If Not DataIsOK() Then Return False

        Dim mDBContext = DBContext()

        mDBContext.TransactionStart()

        Dim mModifyObject = mDBContext.Khos.FirstOrDefault(Function(pp) pp.MaKho.Equals(MaKho.EditValue))
        If mModifyObject Is Nothing Then
            mDBContext.TransactionRollback()
            mDBContext.Release()
            ShowErrorStop(HTLFW.My.Resources.MessageContent.infoErrorSaveFailedMissing)
            Return False
        Else
            With mModifyObject

                .MaKho = Nz(MaKho.EditValue, Nothing)
                .TenKho = Nz(TenKho.EditValue, Nothing)
                .GhiChu = Nz(txtGhiChu.EditValue, Nothing)
            End With
            Try
                mDBContext.SubmitChanges()
            Catch ex As Exception
                mDBContext.TransactionRollback()
                mDBContext.Release()
                mModifyObject = Nothing
                ShowUnknownError(ex.Message)
                Return False
            End Try

            mDBContext.AppendToAppHistory("MODIFY " + DataSourceTableName, "MaKho=[" + PrimaryKey.KeyValue("MaKho") + "]->[" + mModifyObject.MaKho + "] | TenKho=[" + Nz(PrimaryKey.KeyValue("TenKho"), "") + "]->[" + Nz(mModifyObject.TenKho, ""))

            PrimaryKey.KeyValue("MaKho") = mModifyObject.MaKho

            mDBContext.TransactionCommit()
            mDBContext.Release()
            mModifyObject = Nothing

            Return True
        End If

    End Function

    'Public Overrides Sub FillCombosData()
    '    FillCombosData_MaKho()
    '    FillCombosData_TenKho()
    'End Sub

#End Region

#Region "ValidData"

    Private Function DataIsOK() As Boolean
        RefreshErrors()
        Dim mTam As String = ""
        For Each mControl As DevExpress.XtraEditors.BaseEdit In Me.Controls.OfType(Of DevExpress.XtraEditors.BaseEdit)().OrderBy(Function(pp) pp.TabIndex).ToList
            mTam = DxError.GetError(mControl)
            If mTam <> "" Then
                ShowErrorStop(mTam)
                mControl.Focus()
                Return False
            End If
        Next
        Return True
    End Function
    Private Sub ResetErrors()
        For Each mControl In Me.Controls
            DxError.SetError(mControl, "")
        Next
    End Sub
    Private Sub RefreshErrors()
        ResetErrors()
        If IsNoValue(MaKho.EditValue) Then
            DxError.SetError(MaKho, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblMaKho.UniText}))
        End If
        If IsNoValue(TenKho.EditValue) Then
            DxError.SetError(TenKho, TranslateResource(HTLFW.My.Resources.MessageContent.infoErrorDataEmpty, New String() {lblTenKho.UniText}))
        End If
       
    End Sub

#End Region

#Region "Subs"

    Private Sub ResetControls()
       
        MaKho.EditValue = Nothing
        TenKho.EditValue = Nothing
        txtGhiChu.EditValue = Nothing

        MaKho.Focus()
    End Sub

#End Region

#Region "Controls Events"

    '    Private Sub ControlEditValueChanging(ByVal sender As System.Object, ByVal e As DevExpress.XtraEditors.Controls.ChangingEventArgs) Handles Comment.EditValueChanging, EMID.EditValueChanging, MaBangCap.EditValueChanging, LoaiBangCap.EditValueChanging, NgayCap.EditValueChanging, MaDonViCap.EditValueChanging
    '        DxError.SetError(sender, "")
    '    End Sub

    '    Private Sub NgayCap_AfterUpdate() Handles NgayCap.AfterUpdate
    '        If Not CheckIsNoValue(NgayCap.EditValue) AndAlso (NgayCap.ToDate < NgayHienHanh.AddYears(-100) OrElse NgayCap.ToDate > NgayHienHanh.AddYears(100)) Then
    '            NgayCap.EditValue = NgayHienHanh()
    '        End If
    '    End Sub

    '    Private Sub cmdEMID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEMID.Click
    '        AppDevWaitingForm.Show()
    '        Using mForm As New AppRoot.frmTOL_Employee_Search(NgayHienHanh, AppRoot.frmTOL_Employee_Search.eIncludeNoWork.TatCa, EMID.EditValue)
    '            AddHandler mForm.EMIDPicked, AddressOf ProcessEMIDPicked
    '            mForm.ShowDialog(Me)
    '            mForm.Release()
    '        End Using
    '        AppDevWaitingForm.Hide()
    '    End Sub
    '    Private Sub ProcessEMIDPicked(ByVal pEMID As String)
    '        If IsEditableMode() Then EMID.EditValue = pEMID
    '    End Sub

    '#Region "MaBangCap"

    '    Private MaBangCap_Permission As AppRoot.AppUserPermissions.AppUserPermission
    '    Private Sub cmdMaBangCap_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMaBangCap.Click
    '        If MaBangCap_Permission Is Nothing Then
    '            MaBangCap_Permission = GetAppPermission(DBs.SystemValues.OFUNC_hrmList_DanhMucChung_BangCap)
    '        End If
    '        If MaBangCap_Permission.AllowADD Then
    '            AppDevWaitingForm.Show()
    '            Dim mKey = New ListKeyValues(New ListKeyValues.KeyValueObj("ObjectCode"))
    '            Using mForm As New ListFuncs.frmLST_Common_Input("BANGCAP", eFormMode.AddAnyRangeItem, mKey)
    '                mForm.FunctionID = DBs.SystemValues.OFUNC_hrmList_DanhMucChung_BangCap
    '                AddHandler mForm.DataAnyInserted, AddressOf ProcessNewMaBangCap
    '                mForm.ShowDialog(Me)
    '                mForm.Release()
    '            End Using
    '            AppDevWaitingForm.Hide()
    '        End If
    '    End Sub
    '    Private Sub ProcessNewMaBangCap(ByVal pKey As ListKeyValues)
    '        FillCombosData_MaDonViCap()
    '        MaBangCap.EditValue = pKey.KeyValue("ObjectCode")
    '    End Sub

    '#End Region

    '#Region "LoaiBangCap"

    '    Private LoaiBangCap_Permission As AppRoot.AppUserPermissions.AppUserPermission
    '    Private Sub cmdLoaiBangCap_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLoaiBangCap.Click
    '        If LoaiBangCap_Permission Is Nothing Then
    '            LoaiBangCap_Permission = GetAppPermission(DBs.SystemValues.OFUNC_hrmList_DanhMucChung_PhanLoaiBangCap)
    '        End If
    '        If LoaiBangCap_Permission.AllowADD Then
    '            AppDevWaitingForm.Show()
    '            Dim mKey = New ListKeyValues(New ListKeyValues.KeyValueObj("ObjectCode"))
    '            Using mForm As New ListFuncs.frmLST_Common_Input("PHANLOAIBANGCAP", eFormMode.AddAnyRangeItem, mKey)
    '                mForm.FunctionID = DBs.SystemValues.OFUNC_hrmList_DanhMucChung_PhanLoaiBangCap
    '                AddHandler mForm.DataAnyInserted, AddressOf ProcessNewLoaiBangCap
    '                mForm.ShowDialog(Me)
    '                mForm.Release()
    '            End Using
    '            AppDevWaitingForm.Hide()
    '        End If
    '    End Sub
    '    Private Sub ProcessNewLoaiBangCap(ByVal pKey As ListKeyValues)
    '        FillCombosData_MaDonViCap()
    '        LoaiBangCap.EditValue = pKey.KeyValue("ObjectCode")
    '    End Sub

    '#End Region

    '#Region "MaDonViCap"

    '    Private MaDonViCap_Permission As AppRoot.AppUserPermissions.AppUserPermission
    '    Private Sub cmdMaDonViCap_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMaDonViCap.Click
    '        If MaDonViCap_Permission Is Nothing Then
    '            MaDonViCap_Permission = GetAppPermission(DBs.SystemValues.OFUNC_hrmList_DanhMucChung_ToChucDaoTao)
    '        End If
    '        If MaDonViCap_Permission.AllowADD Then
    '            AppDevWaitingForm.Show()
    '            Dim mKey = New ListKeyValues(New ListKeyValues.KeyValueObj("OrgTrainID"))
    '            Using mForm As New ListFuncs.frmLST_OrgTraining_Input(eFormMode.AddAnyRangeItem, mKey)
    '                mForm.FunctionID = DBs.SystemValues.OFUNC_hrmList_DanhMucChung_ToChucDaoTao
    '                AddHandler mForm.DataAnyInserted, AddressOf ProcessNewMaDonViCap
    '                mForm.ShowDialog(Me)
    '                mForm.Release()
    '            End Using
    '            AppDevWaitingForm.Hide()
    '        End If
    '    End Sub
    '    Private Sub ProcessNewMaDonViCap(ByVal pKey As ListKeyValues)
    '        FillCombosData_MaDonViCap()
    '        MaDonViCap.EditValue = pKey.KeyValue("OrgTrainID")
    '    End Sub

    '#End Region

#End Region
End Class