﻿Module StartApp

    Sub Main()

        HTLFW.AppBase.AppTitle = "Quản lý Nhân sự - Tiền Lương (THV Solution)"

        'If My.Application.CommandLineArgs.ToArray.Count = 0 Then
        '    If MsgBox("Bạn không chạy đúng tập tin khởi động của chương trình!" & vbNewLine & vbNewLine & "Bạn có muốn chương trình khởi động lại không?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, HTLFW.AppBase.AppTitle) = MsgBoxResult.Yes Then
        '        Process.Start(HTLFW.AppBase.AppPath & "\HTLStarter.exe")
        '    End If
        '    End
        'End If
        'HTLFW.AppBase.AppApplyHolidayTheme = False

        HTLFW.AppBase.AppNeedServerSync = False

        'HTLFW.AppBase.AppIcon = My.Resources.THV_HRPM
        HTLFW.AppBase.AppTypeOfResource = HTLResource.My.Resources.ResourceManager
        HTLFW.AppBase.AppAllowLanguage = False
        HTLFW.AppBase.AppPublicKey = "-THVSolution-"
        HTLFW.AppBase.AppLayoutLanguage = HTLFW.eAppLanguage.Vietnamese
        HTLFW.AppBase.AppRegisterFilePath = HTLFW.AppBase.AppPath + "\HRPMTHV.htlreg"
        HTLFW.AppBase.AppConfigFilePath = HTLFW.AppBase.AppPath + "\AppConfig.ini"
        HTLFW.AppBase.AppUserFilePath = HTLFW.AppBase.AppPath + "\User.dat"
        HTLFW.AppBase.AppSystemFilePath = HTLFW.AppBase.AppPath + "\System.dat"
        HTLFW.AppBase.AppDataFilePath = HTLFW.AppBase.AppPath + "\AppData.dat"
        HTLFW.AppBase.AppAssemblyFullFile = Application.ExecutablePath
        HTLFW.AppBase.AppHelpFilePath = HTLFW.AppBase.AppPath + "\HRPMTHV.chm"
        'HTLFW.AppBase.AppUserGuideFilePath = HTLFW.AppBase.AppPath + "\HRPMTHVUserGuide.chm"
        HTLFW.AppBase.AppPreffixDBName = "CSDL" ' "HRPMTHV"
        HTLFW.AppBase.AppIdentity = "HRPMTHV"
        HTLFW.AppBase.AppDBTemplateFile = "HRPMTHV.DAT"
        HTLFW.AppBase.AppStartDBName = "CSDL"
        HTLFW.AppBase.AppStartDBNameAutoCreate = False

        HTLFW.AppBase.AppSingleInstance = True

        HTLFW.AppBase.AppUseLoginWithDB = True

        HTLFW.AppBase.AppShowHelpButton = False

        HTLFW.AppBase.AppShowMainMenu = True
        HTLFW.AppBase.AppShowMainToolbar = True
        HTLFW.AppBase.AppAllowShowFunctionTree = False
        HTLFW.AppBase.AppShowFunctionTree = False
        HTLFW.AppBase.AppShowFunctionTreeType = HTLFW.eFunctionTreeType.None
        HTLFW.AppBase.AppAllowSingleAppID = True

        'HTLFW.AppBase.AppTypeOfMainBGCtrl = GetType(UCBG)

        'HTLFW.AppBase.AppShowUserGuideButton = True

        HTLFW.AppBase.AppFormLoginWithDB_KeywordIndex = "99999001"
        HTLFW.AppBase.AppFormMain_KeywordIndex = "99999003"
        HTLFW.AppBase.AppFormQConfig_KeywordIndex = "99999002"

        HTLFW.AppBase.AppMinSize = New Point(800, HTLFW.AppBase.AppMinSize.Height)

        'AppRoot.AppComFuncs.GetAppMachineInfor()

        HTLFW.AppBase.AppStart(My.Application.CommandLineArgs.ToArray)
        While HTLFW.AppBase.AppStatus <> HTLFW.eAppStatus.EndProgram
            If HTLFW.AppBase.AppStatus = HTLFW.eAppStatus.ConnectionBroken OrElse HTLFW.AppBase.AppStatus = HTLFW.eAppStatus.LoginFailed Then
                If Not HTLFW.AppBase.AppCommClient Is Nothing Then HTLFW.AppBase.AppCommClient.StopRunning()
                Application.Restart()
                Exit Sub
            End If
        End While
        End

    End Sub

End Module
